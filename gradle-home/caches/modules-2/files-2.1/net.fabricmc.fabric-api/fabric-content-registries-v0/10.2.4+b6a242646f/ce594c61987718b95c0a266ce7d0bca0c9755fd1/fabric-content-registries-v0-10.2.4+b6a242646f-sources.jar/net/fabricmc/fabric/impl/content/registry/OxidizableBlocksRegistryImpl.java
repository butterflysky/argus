/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.content.registry;

import java.util.Objects;
import net.minecraft.class_11710;
import net.minecraft.class_2248;
import net.minecraft.class_5953;
import net.minecraft.class_5955;

public final class OxidizableBlocksRegistryImpl {
	private OxidizableBlocksRegistryImpl() {
	}

	public static void registerOxidizableBlockPair(class_2248 less, class_2248 more) {
		Objects.requireNonNull(less, "Oxidizable block cannot be null!");
		Objects.requireNonNull(more, "Oxidizable block cannot be null!");
		class_5955.field_29564.get().put(less, more);
		// Fix #4371
		refreshRandomTickCache(less);
		refreshRandomTickCache(more);
	}

	public static void registerWaxableBlockPair(class_2248 unwaxed, class_2248 waxed) {
		Objects.requireNonNull(unwaxed, "Unwaxed block cannot be null!");
		Objects.requireNonNull(waxed, "Waxed block cannot be null!");
		class_5953.field_29560.get().put(unwaxed, waxed);
	}

	public static void registerCopperBlockSet(class_11710 blockSet) {
		Objects.requireNonNull(blockSet, "blockSet cannot be null!");
		blockSet.method_73122().forEach(OxidizableBlocksRegistryImpl::registerOxidizableBlockPair);
		blockSet.method_73126().forEach(OxidizableBlocksRegistryImpl::registerWaxableBlockPair);
	}

	private static void refreshRandomTickCache(class_2248 block) {
		block.method_9595().method_11662().forEach(state -> ((RandomTickCacheRefresher) state).fabric_api$refreshRandomTickCache());
	}

	public interface RandomTickCacheRefresher {
		void fabric_api$refreshRandomTickCache();
	}
}
