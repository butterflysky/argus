/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.datagen;

import java.util.function.Predicate;
import net.minecraft.class_2960;
import net.minecraft.class_3497;

public class ForcedTagEntry extends class_3497 {
	public ForcedTagEntry(class_2960 id) {
		super(id, true, true); // if it's optional, then no need to force
	}

	@Override
	public boolean method_32832(Predicate<class_2960> objectExistsTest, Predicate<class_2960> tagExistsTest) {
		return true;
	}
}
