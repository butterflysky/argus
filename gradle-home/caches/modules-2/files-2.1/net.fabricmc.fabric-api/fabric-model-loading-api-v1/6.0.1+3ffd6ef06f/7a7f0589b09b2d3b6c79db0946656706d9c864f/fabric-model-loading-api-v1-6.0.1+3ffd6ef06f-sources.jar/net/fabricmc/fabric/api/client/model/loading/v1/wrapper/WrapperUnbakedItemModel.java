/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.client.model.loading.v1.wrapper;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10439;

/**
 * A simple implementation of {@link class_10439.class_10441} that delegates all method calls to the {@link #wrapped} field.
 * Implementations must set the {@link #wrapped} field somehow.
 */
public abstract class WrapperUnbakedItemModel implements class_10439.class_10441 {
	protected class_10439.class_10441 wrapped;

	protected WrapperUnbakedItemModel() {
	}

	protected WrapperUnbakedItemModel(class_10439.class_10441 wrapped) {
		this.wrapped = wrapped;
	}

	@Override
	public void method_62326(class_10103 resolver) {
		wrapped.method_62326(resolver);
	}

	@Override
	public MapCodec<? extends class_10439.class_10441> method_65585() {
		return wrapped.method_65585();
	}

	@Override
	public class_10439 method_65587(class_10439.class_10440 context) {
		return wrapped.method_65587(context);
	}
}
