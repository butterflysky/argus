/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.client.model.loading.v1.wrapper;

import net.minecraft.class_10419;
import net.minecraft.class_10820;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_809;
import org.jetbrains.annotations.Nullable;

/**
 * A simple implementation of {@link class_1100} that delegates all method calls to the {@link #wrapped} field.
 * Implementations must set the {@link #wrapped} field somehow.
 */
public abstract class WrapperUnbakedModel implements class_1100 {
	protected class_1100 wrapped;

	protected WrapperUnbakedModel() {
	}

	protected WrapperUnbakedModel(class_1100 wrapped) {
		this.wrapped = wrapped;
	}

	@Override
	@Nullable
	public Boolean comp_3741() {
		return wrapped.comp_3741();
	}

	@Override
	@Nullable
	public class_4751 comp_3740() {
		return wrapped.comp_3740();
	}

	@Override
	@Nullable
	public class_809 comp_3742() {
		return wrapped.comp_3742();
	}

	@Override
	public class_10419.class_10420 comp_3743() {
		return wrapped.comp_3743();
	}

	@Override
	@Nullable
	public class_10820 comp_3739() {
		return wrapped.comp_3739();
	}

	@Override
	@Nullable
	public class_2960 comp_3744() {
		return wrapped.comp_3744();
	}
}
