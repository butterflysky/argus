/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.api.renderer.v1.model;

import java.util.function.Predicate;

import org.jetbrains.annotations.ApiStatus;
import net.fabricmc.fabric.api.renderer.v1.mesh.MutableQuadView;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadEmitter;
import net.fabricmc.fabric.api.renderer.v1.mesh.QuadView;
import net.fabricmc.fabric.api.renderer.v1.sprite.FabricErrorCollectingSpriteGetter;
import net.fabricmc.fabric.api.renderer.v1.sprite.FabricSpriteAtlasTexture;
import net.fabricmc.fabric.api.renderer.v1.sprite.FabricStitchResult;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2960;
import net.minecraft.class_5819;
import net.minecraft.class_9826;

/**
 * Indexes a texture atlas to allow fast lookup of {@link class_1058}s from baked texture coordinates.
 *
 * <p>Example use cases include interpolating the textures of a submodel's quads in
 * {@link FabricBlockStateModel#emitQuads(QuadEmitter, class_1920, class_2338, class_2680, class_5819, Predicate)} or
 * finding the sprite for use in {@link QuadView#toBakedQuad(class_1058)}.
 *
 * <p>A sprite finder can be retrieved from various vanilla objects. Always use
 * {@link FabricErrorCollectingSpriteGetter#spriteFinder(class_2960)} or {@link FabricStitchResult#spriteFinder()}
 * whenever an applicable instance is available. For example, model baking is supplied with a
 * {@link class_9826}, so it should be used to retrieve the sprite finder. In most other cases, it is
 * safe to use {@link FabricSpriteAtlasTexture#spriteFinder()}.
 */
@ApiStatus.NonExtendable
public interface SpriteFinder {
	/**
	 * Finds the atlas sprite containing the vertex centroid of the quad.
	 * Vertex centroid is essentially the mean u,v coordinate - the intent being
	 * to find a point that is unambiguously inside the sprite (vs on an edge.)
	 *
	 * <p>Should be reliable for any convex quad or triangle. May fail for non-convex quads.
	 * Note that all the above refers to u,v coordinates. Geometric vertex does not matter,
	 * except to the extent it was used to determine u,v.
	 */
	class_1058 find(QuadView quad);

	/**
	 * Alternative to {@link #find(QuadView, int)} when vertex centroid is already
	 * known or unsuitable.  Expects normalized (0-1) coordinates on the atlas texture,
	 * which should already be the case for u,v values in vanilla baked quads and in
	 * {@link QuadView} after calling {@link MutableQuadView#spriteBake(class_1058, int)}.
	 *
	 * <p>Coordinates must be in the sprite interior for reliable results. Generally will
	 * be easier to use {@link #find(QuadView, int)} unless you know the vertex
	 * centroid will somehow not be in the quad interior. This method will be slightly
	 * faster if you already have the centroid or another appropriate value.
	 */
	class_1058 find(float u, float v);

	/**
	 * @deprecated Use {@link FabricSpriteAtlasTexture#spriteFinder()} instead.
	 */
	@Deprecated
	static SpriteFinder get(class_1059 atlas) {
		return atlas.spriteFinder();
	}

	/**
	 * @deprecated Use {@link #find(QuadView)} instead.
	 */
	@Deprecated
	default class_1058 find(QuadView quad, int textureIndex) {
		return find(quad);
	}
}
