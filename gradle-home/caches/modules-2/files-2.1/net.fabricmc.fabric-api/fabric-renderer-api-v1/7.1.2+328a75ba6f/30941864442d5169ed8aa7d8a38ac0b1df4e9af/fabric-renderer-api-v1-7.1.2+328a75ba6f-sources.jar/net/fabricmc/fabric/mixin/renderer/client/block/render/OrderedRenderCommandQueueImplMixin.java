/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.renderer.client.block.render;

import java.util.function.Function;
import net.minecraft.class_1087;
import net.minecraft.class_11515;
import net.minecraft.class_11659;
import net.minecraft.class_11661;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import org.spongepowered.asm.mixin.Mixin;

@Mixin(class_11661.class)
abstract class OrderedRenderCommandQueueImplMixin implements class_11659 {
	@Override
	public void submitBlock(class_4587 matrices, class_2680 state, int light, int overlay, int outlineColor, class_1920 blockView, class_2338 pos) {
		method_73529(0).submitBlock(matrices, state, light, overlay, outlineColor, blockView, pos);
	}

	@Override
	public void submitBlockStateModel(class_4587 matrices, Function<class_11515, class_1921> renderLayerFunction, class_1087 model, float r, float g, float b, int light, int overlay, int outlineColor, class_1920 blockView, class_2338 pos, class_2680 state) {
		method_73529(0).submitBlockStateModel(matrices, renderLayerFunction, model, r, g, b, light, overlay, outlineColor, blockView, pos, state);
	}
}
