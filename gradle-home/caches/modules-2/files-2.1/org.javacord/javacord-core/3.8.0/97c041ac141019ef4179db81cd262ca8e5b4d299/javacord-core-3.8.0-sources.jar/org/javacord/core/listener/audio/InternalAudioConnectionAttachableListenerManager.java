package org.javacord.core.listener.audio;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.audio.AudioConnection;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.audio.AudioConnectionAttachableListener;
import org.javacord.api.listener.audio.AudioConnectionAttachableListenerManager;
import org.javacord.api.listener.audio.AudioSourceFinishedListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code AudioConnectionAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalAudioConnectionAttachableListenerManager extends AudioConnectionAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<AudioSourceFinishedListener> addAudioSourceFinishedListener(AudioSourceFinishedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(AudioConnection.class,
                                                             getId(),
                                                             AudioSourceFinishedListener.class,
                                                             listener);
    }

    @Override
    default List<AudioSourceFinishedListener> getAudioSourceFinishedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(AudioConnection.class,
                                                              getId(),
                                                              AudioSourceFinishedListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends AudioConnectionAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addAudioConnectionAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(AudioConnectionAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(AudioConnection.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends AudioConnectionAttachableListener & ObjectAttachableListener> void removeAudioConnectionAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(AudioConnectionAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(AudioConnection.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends AudioConnectionAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getAudioConnectionAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(AudioConnection.class,
                                                              getId());
    }

    @Override
    default <T extends AudioConnectionAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(AudioConnection.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
