package org.javacord.core.listener.audio;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.audio.AudioSource;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.audio.AudioSourceAttachableListener;
import org.javacord.api.listener.audio.AudioSourceAttachableListenerManager;
import org.javacord.api.listener.audio.AudioSourceFinishedListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code AudioSourceAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalAudioSourceAttachableListenerManager extends AudioSourceAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<AudioSourceFinishedListener> addAudioSourceFinishedListener(AudioSourceFinishedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(AudioSource.class,
                                                             getId(),
                                                             AudioSourceFinishedListener.class,
                                                             listener);
    }

    @Override
    default List<AudioSourceFinishedListener> getAudioSourceFinishedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(AudioSource.class,
                                                              getId(),
                                                              AudioSourceFinishedListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends AudioSourceAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addAudioSourceAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(AudioSourceAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(AudioSource.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends AudioSourceAttachableListener & ObjectAttachableListener> void removeAudioSourceAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(AudioSourceAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(AudioSource.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends AudioSourceAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getAudioSourceAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(AudioSource.class,
                                                              getId());
    }

    @Override
    default <T extends AudioSourceAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(AudioSource.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
