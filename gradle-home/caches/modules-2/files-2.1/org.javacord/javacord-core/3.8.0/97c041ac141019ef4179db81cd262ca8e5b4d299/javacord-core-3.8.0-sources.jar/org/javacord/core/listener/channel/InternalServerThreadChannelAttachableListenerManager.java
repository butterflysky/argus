package org.javacord.core.listener.channel;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ServerThreadChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ServerThreadChannelAttachableListener;
import org.javacord.api.listener.channel.ServerThreadChannelAttachableListenerManager;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelCreateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelDeleteListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelMembersUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelUpdateListener;
import org.javacord.api.listener.server.thread.ServerPrivateThreadJoinListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeArchiveTimestampListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeArchivedListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeAutoArchiveDurationListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeInvitableListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeLastMessageIdListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeLockedListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeMemberCountListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeMessageCountListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeRateLimitPerUserListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeTotalMessageSentListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerThreadChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerThreadChannelAttachableListenerManager extends ServerThreadChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<ServerThreadChannelChangeLastMessageIdListener> addServerThreadChannelChangeLastMessageIdListener(ServerThreadChannelChangeLastMessageIdListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeLastMessageIdListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeLastMessageIdListener> getServerThreadChannelChangeLastMessageIdListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeLastMessageIdListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeArchivedListener> addServerThreadChannelChangeArchivedListener(ServerThreadChannelChangeArchivedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeArchivedListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeArchivedListener> getServerThreadChannelChangeArchivedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeArchivedListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeMemberCountListener> addServerThreadChannelChangeMemberCountListener(ServerThreadChannelChangeMemberCountListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeMemberCountListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeMemberCountListener> getServerThreadChannelChangeMemberCountListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeMemberCountListener.class);
    }

    @Override
    default ListenerManager<ServerPrivateThreadJoinListener> addServerPrivateThreadJoinListener(ServerPrivateThreadJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerPrivateThreadJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerPrivateThreadJoinListener> getServerPrivateThreadJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerPrivateThreadJoinListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeInvitableListener> addServerThreadChannelChangeInvitableListener(ServerThreadChannelChangeInvitableListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeInvitableListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeInvitableListener> getServerThreadChannelChangeInvitableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeInvitableListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeAutoArchiveDurationListener> addServerThreadChannelChangeAutoArchiveDurationListener(ServerThreadChannelChangeAutoArchiveDurationListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeAutoArchiveDurationListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeAutoArchiveDurationListener> getServerThreadChannelChangeAutoArchiveDurationListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeAutoArchiveDurationListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeRateLimitPerUserListener> addServerThreadChannelChangeRateLimitPerUserListener(ServerThreadChannelChangeRateLimitPerUserListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeRateLimitPerUserListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeRateLimitPerUserListener> getServerThreadChannelChangeRateLimitPerUserListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeRateLimitPerUserListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeLockedListener> addServerThreadChannelChangeLockedListener(ServerThreadChannelChangeLockedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeLockedListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeLockedListener> getServerThreadChannelChangeLockedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeLockedListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeArchiveTimestampListener> addServerThreadChannelChangeArchiveTimestampListener(ServerThreadChannelChangeArchiveTimestampListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeArchiveTimestampListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeArchiveTimestampListener> getServerThreadChannelChangeArchiveTimestampListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeArchiveTimestampListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeTotalMessageSentListener> addServerThreadChannelChangeTotalMessageSentListener(ServerThreadChannelChangeTotalMessageSentListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeTotalMessageSentListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeTotalMessageSentListener> getServerThreadChannelChangeTotalMessageSentListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeTotalMessageSentListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeMessageCountListener> addServerThreadChannelChangeMessageCountListener(ServerThreadChannelChangeMessageCountListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelChangeMessageCountListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeMessageCountListener> getServerThreadChannelChangeMessageCountListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelChangeMessageCountListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelUpdateListener> addServerThreadChannelUpdateListener(ServerThreadChannelUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelUpdateListener> getServerThreadChannelUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelMembersUpdateListener> addServerThreadChannelMembersUpdateListener(ServerThreadChannelMembersUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelMembersUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelMembersUpdateListener> getServerThreadChannelMembersUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelMembersUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelCreateListener> addServerThreadChannelCreateListener(ServerThreadChannelCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelCreateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelCreateListener> getServerThreadChannelCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelCreateListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelDeleteListener> addServerThreadChannelDeleteListener(ServerThreadChannelDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                             getId(),
                                                             ServerThreadChannelDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelDeleteListener> getServerThreadChannelDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId(),
                                                              ServerThreadChannelDeleteListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerThreadChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addServerThreadChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerThreadChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(ServerThreadChannel.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerThreadChannelAttachableListener & ObjectAttachableListener> void removeServerThreadChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerThreadChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(ServerThreadChannel.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends ServerThreadChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerThreadChannelAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerThreadChannel.class,
                                                              getId());
    }

    @Override
    default <T extends ServerThreadChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ServerThreadChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
