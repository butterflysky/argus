package org.javacord.core.listener.channel;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.TextChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ChannelAttachableListener;
import org.javacord.api.listener.channel.ServerThreadChannelAttachableListener;
import org.javacord.api.listener.channel.TextChannelAttachableListener;
import org.javacord.api.listener.channel.TextChannelAttachableListenerManager;
import org.javacord.api.listener.interaction.AutocompleteCreateListener;
import org.javacord.api.listener.interaction.ButtonClickListener;
import org.javacord.api.listener.interaction.InteractionCreateListener;
import org.javacord.api.listener.interaction.MessageComponentCreateListener;
import org.javacord.api.listener.interaction.MessageContextMenuCommandListener;
import org.javacord.api.listener.interaction.ModalSubmitListener;
import org.javacord.api.listener.interaction.SelectMenuChooseListener;
import org.javacord.api.listener.interaction.SlashCommandCreateListener;
import org.javacord.api.listener.interaction.UserContextMenuCommandListener;
import org.javacord.api.listener.message.CachedMessagePinListener;
import org.javacord.api.listener.message.CachedMessageUnpinListener;
import org.javacord.api.listener.message.ChannelPinsUpdateListener;
import org.javacord.api.listener.message.MessageCreateListener;
import org.javacord.api.listener.message.MessageDeleteListener;
import org.javacord.api.listener.message.MessageEditListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.message.reaction.ReactionAddListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveAllListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveListener;
import org.javacord.api.listener.user.UserStartTypingListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code TextChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalTextChannelAttachableListenerManager extends TextChannelAttachableListenerManager, InternalServerThreadChannelAttachableListenerManager, InternalChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<InteractionCreateListener> addInteractionCreateListener(InteractionCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             InteractionCreateListener.class,
                                                             listener);
    }

    @Override
    default List<InteractionCreateListener> getInteractionCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              InteractionCreateListener.class);
    }

    @Override
    default ListenerManager<SlashCommandCreateListener> addSlashCommandCreateListener(SlashCommandCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             SlashCommandCreateListener.class,
                                                             listener);
    }

    @Override
    default List<SlashCommandCreateListener> getSlashCommandCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              SlashCommandCreateListener.class);
    }

    @Override
    default ListenerManager<AutocompleteCreateListener> addAutocompleteCreateListener(AutocompleteCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             AutocompleteCreateListener.class,
                                                             listener);
    }

    @Override
    default List<AutocompleteCreateListener> getAutocompleteCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              AutocompleteCreateListener.class);
    }

    @Override
    default ListenerManager<ModalSubmitListener> addModalSubmitListener(ModalSubmitListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             ModalSubmitListener.class,
                                                             listener);
    }

    @Override
    default List<ModalSubmitListener> getModalSubmitListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              ModalSubmitListener.class);
    }

    @Override
    default ListenerManager<MessageContextMenuCommandListener> addMessageContextMenuCommandListener(MessageContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             MessageContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<MessageContextMenuCommandListener> getMessageContextMenuCommandListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              MessageContextMenuCommandListener.class);
    }

    @Override
    default ListenerManager<MessageComponentCreateListener> addMessageComponentCreateListener(MessageComponentCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             MessageComponentCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageComponentCreateListener> getMessageComponentCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              MessageComponentCreateListener.class);
    }

    @Override
    default ListenerManager<UserContextMenuCommandListener> addUserContextMenuCommandListener(UserContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             UserContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<UserContextMenuCommandListener> getUserContextMenuCommandListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              UserContextMenuCommandListener.class);
    }

    @Override
    default ListenerManager<SelectMenuChooseListener> addSelectMenuChooseListener(SelectMenuChooseListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             SelectMenuChooseListener.class,
                                                             listener);
    }

    @Override
    default List<SelectMenuChooseListener> getSelectMenuChooseListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              SelectMenuChooseListener.class);
    }

    @Override
    default ListenerManager<ButtonClickListener> addButtonClickListener(ButtonClickListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             ButtonClickListener.class,
                                                             listener);
    }

    @Override
    default List<ButtonClickListener> getButtonClickListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              ButtonClickListener.class);
    }

    @Override
    default ListenerManager<UserStartTypingListener> addUserStartTypingListener(UserStartTypingListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             UserStartTypingListener.class,
                                                             listener);
    }

    @Override
    default List<UserStartTypingListener> getUserStartTypingListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              UserStartTypingListener.class);
    }

    @Override
    default ListenerManager<MessageEditListener> addMessageEditListener(MessageEditListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             MessageEditListener.class,
                                                             listener);
    }

    @Override
    default List<MessageEditListener> getMessageEditListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              MessageEditListener.class);
    }

    @Override
    default ListenerManager<ChannelPinsUpdateListener> addChannelPinsUpdateListener(ChannelPinsUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             ChannelPinsUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ChannelPinsUpdateListener> getChannelPinsUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              ChannelPinsUpdateListener.class);
    }

    @Override
    default ListenerManager<ReactionRemoveListener> addReactionRemoveListener(ReactionRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             ReactionRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveListener> getReactionRemoveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              ReactionRemoveListener.class);
    }

    @Override
    default ListenerManager<ReactionAddListener> addReactionAddListener(ReactionAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             ReactionAddListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionAddListener> getReactionAddListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              ReactionAddListener.class);
    }

    @Override
    default ListenerManager<ReactionRemoveAllListener> addReactionRemoveAllListener(ReactionRemoveAllListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             ReactionRemoveAllListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveAllListener> getReactionRemoveAllListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              ReactionRemoveAllListener.class);
    }

    @Override
    default ListenerManager<MessageCreateListener> addMessageCreateListener(MessageCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             MessageCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageCreateListener> getMessageCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              MessageCreateListener.class);
    }

    @Override
    default ListenerManager<CachedMessageUnpinListener> addCachedMessageUnpinListener(CachedMessageUnpinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             CachedMessageUnpinListener.class,
                                                             listener);
    }

    @Override
    default List<CachedMessageUnpinListener> getCachedMessageUnpinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              CachedMessageUnpinListener.class);
    }

    @Override
    default ListenerManager<CachedMessagePinListener> addCachedMessagePinListener(CachedMessagePinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             CachedMessagePinListener.class,
                                                             listener);
    }

    @Override
    default List<CachedMessagePinListener> getCachedMessagePinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              CachedMessagePinListener.class);
    }

    @Override
    default ListenerManager<MessageReplyListener> addMessageReplyListener(MessageReplyListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             MessageReplyListener.class,
                                                             listener);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              MessageReplyListener.class);
    }

    @Override
    default ListenerManager<MessageDeleteListener> addMessageDeleteListener(MessageDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                             getId(),
                                                             MessageDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<MessageDeleteListener> getMessageDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                              getId(),
                                                              MessageDeleteListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends TextChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<? extends TextChannelAttachableListener>> addTextChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(TextChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .flatMap(listenerClass -> {
                              if (ServerThreadChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addServerThreadChannelAttachableListener((ServerThreadChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else {
                                  return Stream.of(((DiscordApiImpl) getApi()).addObjectListener(TextChannel.class,
                                                                                                 getId(),
                                                                                                 listenerClass,
                                                                                                 listener));
                              }
                          })
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends TextChannelAttachableListener & ObjectAttachableListener> void removeTextChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(TextChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> {
                       if (ServerThreadChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeServerThreadChannelAttachableListener((ServerThreadChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener);
                       } else {
                           ((DiscordApiImpl) getApi()).removeObjectListener(TextChannel.class,
                                                                            getId(),
                                                                            listenerClass,
                                                                            listener);
                       }
                   });
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends TextChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getTextChannelAttachableListeners() {
        Map<T, List<Class<T>>> listeners = ((DiscordApiImpl) getApi()).getObjectListeners(TextChannel.class,
                                                                                          getId());
        getChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                               (List<Class<T>>) (Object) listenerClasses,
                                                                                               (listenerClasses1, listenerClasses2) -> {
                                                                                                   listenerClasses1.addAll(listenerClasses2);
                                                                                                   return listenerClasses1;
                                                                                               }));
        getServerThreadChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                           (List<Class<T>>) (Object) listenerClasses,
                                                                                                           (listenerClasses1, listenerClasses2) -> {
                                                                                                               listenerClasses1.addAll(listenerClasses2);
                                                                                                               return listenerClasses1;
                                                                                                           }));
        return listeners;
    }

    @Override
    default <T extends TextChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(TextChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
