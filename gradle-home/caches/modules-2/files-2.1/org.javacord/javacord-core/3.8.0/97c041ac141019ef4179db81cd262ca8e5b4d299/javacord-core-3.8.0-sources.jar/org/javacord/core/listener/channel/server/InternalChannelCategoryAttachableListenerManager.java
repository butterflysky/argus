package org.javacord.core.listener.channel.server;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ChannelCategory;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ChannelAttachableListener;
import org.javacord.api.listener.channel.server.ChannelCategoryAttachableListener;
import org.javacord.api.listener.channel.server.ChannelCategoryAttachableListenerManager;
import org.javacord.api.listener.channel.server.ServerChannelAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeNsfwFlagListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ChannelCategoryAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalChannelCategoryAttachableListenerManager extends ChannelCategoryAttachableListenerManager, InternalServerChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<ServerChannelChangeNsfwFlagListener> addServerChannelChangeNsfwFlagListener(ServerChannelChangeNsfwFlagListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ChannelCategory.class,
                                                             getId(),
                                                             ServerChannelChangeNsfwFlagListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeNsfwFlagListener> getServerChannelChangeNsfwFlagListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ChannelCategory.class,
                                                              getId(),
                                                              ServerChannelChangeNsfwFlagListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ChannelCategoryAttachableListener & ObjectAttachableListener> Collection<ListenerManager<? extends ChannelCategoryAttachableListener>> addChannelCategoryAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ChannelCategoryAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .flatMap(listenerClass -> {
                              if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (ServerChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addServerChannelAttachableListener((ServerChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else {
                                  return Stream.of(((DiscordApiImpl) getApi()).addObjectListener(ChannelCategory.class,
                                                                                                 getId(),
                                                                                                 listenerClass,
                                                                                                 listener));
                              }
                          })
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ChannelCategoryAttachableListener & ObjectAttachableListener> void removeChannelCategoryAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ChannelCategoryAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> {
                       if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (ServerChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeServerChannelAttachableListener((ServerChannelAttachableListener & ObjectAttachableListener) listener);
                       } else {
                           ((DiscordApiImpl) getApi()).removeObjectListener(ChannelCategory.class,
                                                                            getId(),
                                                                            listenerClass,
                                                                            listener);
                       }
                   });
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ChannelCategoryAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getChannelCategoryAttachableListeners() {
        Map<T, List<Class<T>>> listeners = ((DiscordApiImpl) getApi()).getObjectListeners(ChannelCategory.class,
                                                                                          getId());
        getServerChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                     (List<Class<T>>) (Object) listenerClasses,
                                                                                                     (listenerClasses1, listenerClasses2) -> {
                                                                                                         listenerClasses1.addAll(listenerClasses2);
                                                                                                         return listenerClasses1;
                                                                                                     }));
        getChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                               (List<Class<T>>) (Object) listenerClasses,
                                                                                               (listenerClasses1, listenerClasses2) -> {
                                                                                                   listenerClasses1.addAll(listenerClasses2);
                                                                                                   return listenerClasses1;
                                                                                               }));
        return listeners;
    }

    @Override
    default <T extends ChannelCategoryAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ChannelCategory.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
