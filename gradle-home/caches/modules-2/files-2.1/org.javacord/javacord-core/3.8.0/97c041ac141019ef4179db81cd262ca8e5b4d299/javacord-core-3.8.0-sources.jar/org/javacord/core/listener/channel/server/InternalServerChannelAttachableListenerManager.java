package org.javacord.core.listener.channel.server;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ServerChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ChannelAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelAttachableListenerManager;
import org.javacord.api.listener.channel.server.ServerChannelChangeNameListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeOverwrittenPermissionsListener;
import org.javacord.api.listener.channel.server.ServerChannelChangePositionListener;
import org.javacord.api.listener.channel.server.ServerChannelDeleteListener;
import org.javacord.api.listener.server.VoiceStateUpdateListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.listener.channel.InternalChannelAttachableListenerManager;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerChannelAttachableListenerManager extends ServerChannelAttachableListenerManager, InternalChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<VoiceStateUpdateListener> addVoiceStateUpdateListener(VoiceStateUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerChannel.class,
                                                             getId(),
                                                             VoiceStateUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<VoiceStateUpdateListener> getVoiceStateUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerChannel.class,
                                                              getId(),
                                                              VoiceStateUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangePositionListener> addServerChannelChangePositionListener(ServerChannelChangePositionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerChannel.class,
                                                             getId(),
                                                             ServerChannelChangePositionListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangePositionListener> getServerChannelChangePositionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerChannel.class,
                                                              getId(),
                                                              ServerChannelChangePositionListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeOverwrittenPermissionsListener> addServerChannelChangeOverwrittenPermissionsListener(ServerChannelChangeOverwrittenPermissionsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerChannel.class,
                                                             getId(),
                                                             ServerChannelChangeOverwrittenPermissionsListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeOverwrittenPermissionsListener> getServerChannelChangeOverwrittenPermissionsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerChannel.class,
                                                              getId(),
                                                              ServerChannelChangeOverwrittenPermissionsListener.class);
    }

    @Override
    default ListenerManager<ServerChannelDeleteListener> addServerChannelDeleteListener(ServerChannelDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerChannel.class,
                                                             getId(),
                                                             ServerChannelDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelDeleteListener> getServerChannelDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerChannel.class,
                                                              getId(),
                                                              ServerChannelDeleteListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeNameListener> addServerChannelChangeNameListener(ServerChannelChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerChannel.class,
                                                             getId(),
                                                             ServerChannelChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeNameListener> getServerChannelChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerChannel.class,
                                                              getId(),
                                                              ServerChannelChangeNameListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<? extends ServerChannelAttachableListener>> addServerChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .flatMap(listenerClass -> {
                              if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else {
                                  return Stream.of(((DiscordApiImpl) getApi()).addObjectListener(ServerChannel.class,
                                                                                                 getId(),
                                                                                                 listenerClass,
                                                                                                 listener));
                              }
                          })
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerChannelAttachableListener & ObjectAttachableListener> void removeServerChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> {
                       if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener);
                       } else {
                           ((DiscordApiImpl) getApi()).removeObjectListener(ServerChannel.class,
                                                                            getId(),
                                                                            listenerClass,
                                                                            listener);
                       }
                   });
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerChannelAttachableListeners() {
        Map<T, List<Class<T>>> listeners = ((DiscordApiImpl) getApi()).getObjectListeners(ServerChannel.class,
                                                                                          getId());
        getChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                               (List<Class<T>>) (Object) listenerClasses,
                                                                                               (listenerClasses1, listenerClasses2) -> {
                                                                                                   listenerClasses1.addAll(listenerClasses2);
                                                                                                   return listenerClasses1;
                                                                                               }));
        return listeners;
    }

    @Override
    default <T extends ServerChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ServerChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
