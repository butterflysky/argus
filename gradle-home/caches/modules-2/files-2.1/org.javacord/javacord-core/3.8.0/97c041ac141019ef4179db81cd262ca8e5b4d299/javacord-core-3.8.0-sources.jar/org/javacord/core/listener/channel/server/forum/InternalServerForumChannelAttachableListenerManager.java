package org.javacord.core.listener.channel.server.forum;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ServerForumChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.server.forum.ServerForumChannelAttachableListener;
import org.javacord.api.listener.channel.server.forum.ServerForumChannelAttachableListenerManager;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerForumChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerForumChannelAttachableListenerManager extends ServerForumChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerForumChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addServerForumChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerForumChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(ServerForumChannel.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerForumChannelAttachableListener & ObjectAttachableListener> void removeServerForumChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerForumChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(ServerForumChannel.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends ServerForumChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerForumChannelAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerForumChannel.class,
                                                              getId());
    }

    @Override
    default <T extends ServerForumChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ServerForumChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
