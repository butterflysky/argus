package org.javacord.core.listener.channel.server.text;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ServerTextChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ChannelAttachableListener;
import org.javacord.api.listener.channel.ServerThreadChannelAttachableListener;
import org.javacord.api.listener.channel.TextChannelAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeNsfwFlagListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelAttachableListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelAttachableListenerManager;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeDefaultAutoArchiveDurationListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeSlowmodeListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeTopicListener;
import org.javacord.api.listener.channel.server.text.WebhooksUpdateListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.listener.channel.InternalTextChannelAttachableListenerManager;
import org.javacord.core.listener.channel.server.InternalServerChannelAttachableListenerManager;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerTextChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerTextChannelAttachableListenerManager extends ServerTextChannelAttachableListenerManager, InternalTextChannelAttachableListenerManager, InternalServerChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<WebhooksUpdateListener> addWebhooksUpdateListener(WebhooksUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerTextChannel.class,
                                                             getId(),
                                                             WebhooksUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<WebhooksUpdateListener> getWebhooksUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerTextChannel.class,
                                                              getId(),
                                                              WebhooksUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerTextChannelChangeDefaultAutoArchiveDurationListener> addServerTextChannelChangeDefaultAutoArchiveDurationListener(ServerTextChannelChangeDefaultAutoArchiveDurationListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerTextChannel.class,
                                                             getId(),
                                                             ServerTextChannelChangeDefaultAutoArchiveDurationListener.class,
                                                             listener);
    }

    @Override
    default List<ServerTextChannelChangeDefaultAutoArchiveDurationListener> getServerTextChannelChangeDefaultAutoArchiveDurationListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerTextChannel.class,
                                                              getId(),
                                                              ServerTextChannelChangeDefaultAutoArchiveDurationListener.class);
    }

    @Override
    default ListenerManager<ServerTextChannelChangeSlowmodeListener> addServerTextChannelChangeSlowmodeListener(ServerTextChannelChangeSlowmodeListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerTextChannel.class,
                                                             getId(),
                                                             ServerTextChannelChangeSlowmodeListener.class,
                                                             listener);
    }

    @Override
    default List<ServerTextChannelChangeSlowmodeListener> getServerTextChannelChangeSlowmodeListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerTextChannel.class,
                                                              getId(),
                                                              ServerTextChannelChangeSlowmodeListener.class);
    }

    @Override
    default ListenerManager<ServerTextChannelChangeTopicListener> addServerTextChannelChangeTopicListener(ServerTextChannelChangeTopicListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerTextChannel.class,
                                                             getId(),
                                                             ServerTextChannelChangeTopicListener.class,
                                                             listener);
    }

    @Override
    default List<ServerTextChannelChangeTopicListener> getServerTextChannelChangeTopicListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerTextChannel.class,
                                                              getId(),
                                                              ServerTextChannelChangeTopicListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeNsfwFlagListener> addServerChannelChangeNsfwFlagListener(ServerChannelChangeNsfwFlagListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerTextChannel.class,
                                                             getId(),
                                                             ServerChannelChangeNsfwFlagListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeNsfwFlagListener> getServerChannelChangeNsfwFlagListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerTextChannel.class,
                                                              getId(),
                                                              ServerChannelChangeNsfwFlagListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerTextChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<? extends ServerTextChannelAttachableListener>> addServerTextChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerTextChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .flatMap(listenerClass -> {
                              if (ServerThreadChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addServerThreadChannelAttachableListener((ServerThreadChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (TextChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addTextChannelAttachableListener((TextChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (ServerChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addServerChannelAttachableListener((ServerChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else {
                                  return Stream.of(((DiscordApiImpl) getApi()).addObjectListener(ServerTextChannel.class,
                                                                                                 getId(),
                                                                                                 listenerClass,
                                                                                                 listener));
                              }
                          })
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerTextChannelAttachableListener & ObjectAttachableListener> void removeServerTextChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerTextChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> {
                       if (ServerThreadChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeServerThreadChannelAttachableListener((ServerThreadChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (TextChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeTextChannelAttachableListener((TextChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (ServerChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeServerChannelAttachableListener((ServerChannelAttachableListener & ObjectAttachableListener) listener);
                       } else {
                           ((DiscordApiImpl) getApi()).removeObjectListener(ServerTextChannel.class,
                                                                            getId(),
                                                                            listenerClass,
                                                                            listener);
                       }
                   });
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerTextChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerTextChannelAttachableListeners() {
        Map<T, List<Class<T>>> listeners = ((DiscordApiImpl) getApi()).getObjectListeners(ServerTextChannel.class,
                                                                                          getId());
        getServerChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                     (List<Class<T>>) (Object) listenerClasses,
                                                                                                     (listenerClasses1, listenerClasses2) -> {
                                                                                                         listenerClasses1.addAll(listenerClasses2);
                                                                                                         return listenerClasses1;
                                                                                                     }));
        getTextChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                   (List<Class<T>>) (Object) listenerClasses,
                                                                                                   (listenerClasses1, listenerClasses2) -> {
                                                                                                       listenerClasses1.addAll(listenerClasses2);
                                                                                                       return listenerClasses1;
                                                                                                   }));
        getChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                               (List<Class<T>>) (Object) listenerClasses,
                                                                                               (listenerClasses1, listenerClasses2) -> {
                                                                                                   listenerClasses1.addAll(listenerClasses2);
                                                                                                   return listenerClasses1;
                                                                                               }));
        getServerThreadChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                           (List<Class<T>>) (Object) listenerClasses,
                                                                                                           (listenerClasses1, listenerClasses2) -> {
                                                                                                               listenerClasses1.addAll(listenerClasses2);
                                                                                                               return listenerClasses1;
                                                                                                           }));
        return listeners;
    }

    @Override
    default <T extends ServerTextChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ServerTextChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
