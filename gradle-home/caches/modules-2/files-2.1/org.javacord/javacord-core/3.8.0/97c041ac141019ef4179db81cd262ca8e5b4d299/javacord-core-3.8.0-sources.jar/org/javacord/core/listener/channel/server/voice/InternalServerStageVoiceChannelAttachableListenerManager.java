package org.javacord.core.listener.channel.server.voice;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ServerStageVoiceChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.server.voice.ServerStageVoiceChannelAttachableListener;
import org.javacord.api.listener.channel.server.voice.ServerStageVoiceChannelAttachableListenerManager;
import org.javacord.api.listener.channel.server.voice.ServerStageVoiceChannelChangeTopicListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerStageVoiceChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerStageVoiceChannelAttachableListenerManager extends ServerStageVoiceChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<ServerStageVoiceChannelChangeTopicListener> addServerStageVoiceChannelChangeTopicListener(ServerStageVoiceChannelChangeTopicListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerStageVoiceChannel.class,
                                                             getId(),
                                                             ServerStageVoiceChannelChangeTopicListener.class,
                                                             listener);
    }

    @Override
    default List<ServerStageVoiceChannelChangeTopicListener> getServerStageVoiceChannelChangeTopicListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerStageVoiceChannel.class,
                                                              getId(),
                                                              ServerStageVoiceChannelChangeTopicListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerStageVoiceChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addServerStageVoiceChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerStageVoiceChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(ServerStageVoiceChannel.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerStageVoiceChannelAttachableListener & ObjectAttachableListener> void removeServerStageVoiceChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerStageVoiceChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(ServerStageVoiceChannel.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends ServerStageVoiceChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerStageVoiceChannelAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerStageVoiceChannel.class,
                                                              getId());
    }

    @Override
    default <T extends ServerStageVoiceChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ServerStageVoiceChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
