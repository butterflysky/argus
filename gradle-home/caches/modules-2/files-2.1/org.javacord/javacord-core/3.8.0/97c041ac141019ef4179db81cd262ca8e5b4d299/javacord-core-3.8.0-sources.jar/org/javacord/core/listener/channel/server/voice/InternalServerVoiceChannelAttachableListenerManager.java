package org.javacord.core.listener.channel.server.voice;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.ServerVoiceChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ChannelAttachableListener;
import org.javacord.api.listener.channel.VoiceChannelAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelAttachableListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelAttachableListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelAttachableListenerManager;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeBitrateListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeNsfwListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeUserLimitListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberJoinListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberLeaveListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.listener.channel.InternalVoiceChannelAttachableListenerManager;
import org.javacord.core.listener.channel.server.InternalServerChannelAttachableListenerManager;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerVoiceChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerVoiceChannelAttachableListenerManager extends ServerVoiceChannelAttachableListenerManager, InternalVoiceChannelAttachableListenerManager, InternalServerChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<ServerVoiceChannelChangeBitrateListener> addServerVoiceChannelChangeBitrateListener(ServerVoiceChannelChangeBitrateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerVoiceChannel.class,
                                                             getId(),
                                                             ServerVoiceChannelChangeBitrateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelChangeBitrateListener> getServerVoiceChannelChangeBitrateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerVoiceChannel.class,
                                                              getId(),
                                                              ServerVoiceChannelChangeBitrateListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelChangeUserLimitListener> addServerVoiceChannelChangeUserLimitListener(ServerVoiceChannelChangeUserLimitListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerVoiceChannel.class,
                                                             getId(),
                                                             ServerVoiceChannelChangeUserLimitListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelChangeUserLimitListener> getServerVoiceChannelChangeUserLimitListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerVoiceChannel.class,
                                                              getId(),
                                                              ServerVoiceChannelChangeUserLimitListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelMemberLeaveListener> addServerVoiceChannelMemberLeaveListener(ServerVoiceChannelMemberLeaveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerVoiceChannel.class,
                                                             getId(),
                                                             ServerVoiceChannelMemberLeaveListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelMemberLeaveListener> getServerVoiceChannelMemberLeaveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerVoiceChannel.class,
                                                              getId(),
                                                              ServerVoiceChannelMemberLeaveListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelChangeNsfwListener> addServerVoiceChannelChangeNsfwListener(ServerVoiceChannelChangeNsfwListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerVoiceChannel.class,
                                                             getId(),
                                                             ServerVoiceChannelChangeNsfwListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelChangeNsfwListener> getServerVoiceChannelChangeNsfwListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerVoiceChannel.class,
                                                              getId(),
                                                              ServerVoiceChannelChangeNsfwListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelMemberJoinListener> addServerVoiceChannelMemberJoinListener(ServerVoiceChannelMemberJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(ServerVoiceChannel.class,
                                                             getId(),
                                                             ServerVoiceChannelMemberJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelMemberJoinListener> getServerVoiceChannelMemberJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(ServerVoiceChannel.class,
                                                              getId(),
                                                              ServerVoiceChannelMemberJoinListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerVoiceChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<? extends ServerVoiceChannelAttachableListener>> addServerVoiceChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerVoiceChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .flatMap(listenerClass -> {
                              if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (VoiceChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addVoiceChannelAttachableListener((VoiceChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (ServerChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addServerChannelAttachableListener((ServerChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else {
                                  return Stream.of(((DiscordApiImpl) getApi()).addObjectListener(ServerVoiceChannel.class,
                                                                                                 getId(),
                                                                                                 listenerClass,
                                                                                                 listener));
                              }
                          })
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerVoiceChannelAttachableListener & ObjectAttachableListener> void removeServerVoiceChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerVoiceChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> {
                       if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (VoiceChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeVoiceChannelAttachableListener((VoiceChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (ServerChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeServerChannelAttachableListener((ServerChannelAttachableListener & ObjectAttachableListener) listener);
                       } else {
                           ((DiscordApiImpl) getApi()).removeObjectListener(ServerVoiceChannel.class,
                                                                            getId(),
                                                                            listenerClass,
                                                                            listener);
                       }
                   });
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerVoiceChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerVoiceChannelAttachableListeners() {
        Map<T, List<Class<T>>> listeners = ((DiscordApiImpl) getApi()).getObjectListeners(ServerVoiceChannel.class,
                                                                                          getId());
        getServerChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                     (List<Class<T>>) (Object) listenerClasses,
                                                                                                     (listenerClasses1, listenerClasses2) -> {
                                                                                                         listenerClasses1.addAll(listenerClasses2);
                                                                                                         return listenerClasses1;
                                                                                                     }));
        getVoiceChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                    (List<Class<T>>) (Object) listenerClasses,
                                                                                                    (listenerClasses1, listenerClasses2) -> {
                                                                                                        listenerClasses1.addAll(listenerClasses2);
                                                                                                        return listenerClasses1;
                                                                                                    }));
        getChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                               (List<Class<T>>) (Object) listenerClasses,
                                                                                               (listenerClasses1, listenerClasses2) -> {
                                                                                                   listenerClasses1.addAll(listenerClasses2);
                                                                                                   return listenerClasses1;
                                                                                               }));
        return listeners;
    }

    @Override
    default <T extends ServerVoiceChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(ServerVoiceChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
