package org.javacord.core.listener.channel.user;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.channel.PrivateChannel;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.ChannelAttachableListener;
import org.javacord.api.listener.channel.ServerThreadChannelAttachableListener;
import org.javacord.api.listener.channel.TextChannelAttachableListener;
import org.javacord.api.listener.channel.VoiceChannelAttachableListener;
import org.javacord.api.listener.channel.user.PrivateChannelAttachableListener;
import org.javacord.api.listener.channel.user.PrivateChannelAttachableListenerManager;
import org.javacord.api.listener.channel.user.PrivateChannelDeleteListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.listener.channel.InternalTextChannelAttachableListenerManager;
import org.javacord.core.listener.channel.InternalVoiceChannelAttachableListenerManager;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code PrivateChannelAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalPrivateChannelAttachableListenerManager extends PrivateChannelAttachableListenerManager, InternalVoiceChannelAttachableListenerManager, InternalTextChannelAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<PrivateChannelDeleteListener> addPrivateChannelDeleteListener(PrivateChannelDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(PrivateChannel.class,
                                                             getId(),
                                                             PrivateChannelDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<PrivateChannelDeleteListener> getPrivateChannelDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(PrivateChannel.class,
                                                              getId(),
                                                              PrivateChannelDeleteListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends PrivateChannelAttachableListener & ObjectAttachableListener> Collection<ListenerManager<? extends PrivateChannelAttachableListener>> addPrivateChannelAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(PrivateChannelAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .flatMap(listenerClass -> {
                              if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (ServerThreadChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addServerThreadChannelAttachableListener((ServerThreadChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (VoiceChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addVoiceChannelAttachableListener((VoiceChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else if (TextChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                                  return addTextChannelAttachableListener((TextChannelAttachableListener & ObjectAttachableListener) listener).stream();
                              } else {
                                  return Stream.of(((DiscordApiImpl) getApi()).addObjectListener(PrivateChannel.class,
                                                                                                 getId(),
                                                                                                 listenerClass,
                                                                                                 listener));
                              }
                          })
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends PrivateChannelAttachableListener & ObjectAttachableListener> void removePrivateChannelAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(PrivateChannelAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> {
                       if (ChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeChannelAttachableListener((ChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (ServerThreadChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeServerThreadChannelAttachableListener((ServerThreadChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (VoiceChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeVoiceChannelAttachableListener((VoiceChannelAttachableListener & ObjectAttachableListener) listener);
                       } else if (TextChannelAttachableListener.class.isAssignableFrom(listenerClass)) {
                           removeTextChannelAttachableListener((TextChannelAttachableListener & ObjectAttachableListener) listener);
                       } else {
                           ((DiscordApiImpl) getApi()).removeObjectListener(PrivateChannel.class,
                                                                            getId(),
                                                                            listenerClass,
                                                                            listener);
                       }
                   });
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends PrivateChannelAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getPrivateChannelAttachableListeners() {
        Map<T, List<Class<T>>> listeners = ((DiscordApiImpl) getApi()).getObjectListeners(PrivateChannel.class,
                                                                                          getId());
        getTextChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                   (List<Class<T>>) (Object) listenerClasses,
                                                                                                   (listenerClasses1, listenerClasses2) -> {
                                                                                                       listenerClasses1.addAll(listenerClasses2);
                                                                                                       return listenerClasses1;
                                                                                                   }));
        getVoiceChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                    (List<Class<T>>) (Object) listenerClasses,
                                                                                                    (listenerClasses1, listenerClasses2) -> {
                                                                                                        listenerClasses1.addAll(listenerClasses2);
                                                                                                        return listenerClasses1;
                                                                                                    }));
        getServerThreadChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                                           (List<Class<T>>) (Object) listenerClasses,
                                                                                                           (listenerClasses1, listenerClasses2) -> {
                                                                                                               listenerClasses1.addAll(listenerClasses2);
                                                                                                               return listenerClasses1;
                                                                                                           }));
        getChannelAttachableListeners().forEach((listener, listenerClasses) -> listeners.merge((T) listener,
                                                                                               (List<Class<T>>) (Object) listenerClasses,
                                                                                               (listenerClasses1, listenerClasses2) -> {
                                                                                                   listenerClasses1.addAll(listenerClasses2);
                                                                                                   return listenerClasses1;
                                                                                               }));
        return listeners;
    }

    @Override
    default <T extends PrivateChannelAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(PrivateChannel.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
