package org.javacord.core.listener.message;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.message.Message;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.interaction.ButtonClickListener;
import org.javacord.api.listener.interaction.MessageComponentCreateListener;
import org.javacord.api.listener.interaction.MessageContextMenuCommandListener;
import org.javacord.api.listener.interaction.SelectMenuChooseListener;
import org.javacord.api.listener.message.CachedMessagePinListener;
import org.javacord.api.listener.message.CachedMessageUnpinListener;
import org.javacord.api.listener.message.MessageAttachableListener;
import org.javacord.api.listener.message.MessageAttachableListenerManager;
import org.javacord.api.listener.message.MessageDeleteListener;
import org.javacord.api.listener.message.MessageEditListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.message.reaction.ReactionAddListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveAllListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;

/**
 * The implementation of {@code MessageAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalMessageAttachableListenerManager extends MessageAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<MessageContextMenuCommandListener> addMessageContextMenuCommandListener(MessageContextMenuCommandListener listener) {
        return MessageAttachableListenerManager.addMessageContextMenuCommandListener(getApi(),
                                                                                     getId(),
                                                                                     listener);
    }

    @Override
    default List<MessageContextMenuCommandListener> getMessageContextMenuCommandListeners() {
        return MessageAttachableListenerManager.getMessageContextMenuCommandListeners(getApi(),
                                                                                      getId());
    }

    @Override
    default ListenerManager<MessageComponentCreateListener> addMessageComponentCreateListener(MessageComponentCreateListener listener) {
        return MessageAttachableListenerManager.addMessageComponentCreateListener(getApi(),
                                                                                  getId(),
                                                                                  listener);
    }

    @Override
    default List<MessageComponentCreateListener> getMessageComponentCreateListeners() {
        return MessageAttachableListenerManager.getMessageComponentCreateListeners(getApi(),
                                                                                   getId());
    }

    @Override
    default ListenerManager<SelectMenuChooseListener> addSelectMenuChooseListener(SelectMenuChooseListener listener) {
        return MessageAttachableListenerManager.addSelectMenuChooseListener(getApi(),
                                                                            getId(),
                                                                            listener);
    }

    @Override
    default List<SelectMenuChooseListener> getSelectMenuChooseListeners() {
        return MessageAttachableListenerManager.getSelectMenuChooseListeners(getApi(),
                                                                             getId());
    }

    @Override
    default ListenerManager<ButtonClickListener> addButtonClickListener(ButtonClickListener listener) {
        return MessageAttachableListenerManager.addButtonClickListener(getApi(),
                                                                       getId(),
                                                                       listener);
    }

    @Override
    default List<ButtonClickListener> getButtonClickListeners() {
        return MessageAttachableListenerManager.getButtonClickListeners(getApi(),
                                                                        getId());
    }

    @Override
    default ListenerManager<MessageEditListener> addMessageEditListener(MessageEditListener listener) {
        return MessageAttachableListenerManager.addMessageEditListener(getApi(),
                                                                       getId(),
                                                                       listener);
    }

    @Override
    default List<MessageEditListener> getMessageEditListeners() {
        return MessageAttachableListenerManager.getMessageEditListeners(getApi(),
                                                                        getId());
    }

    @Override
    default ListenerManager<ReactionRemoveListener> addReactionRemoveListener(ReactionRemoveListener listener) {
        return MessageAttachableListenerManager.addReactionRemoveListener(getApi(),
                                                                          getId(),
                                                                          listener);
    }

    @Override
    default List<ReactionRemoveListener> getReactionRemoveListeners() {
        return MessageAttachableListenerManager.getReactionRemoveListeners(getApi(),
                                                                           getId());
    }

    @Override
    default ListenerManager<ReactionAddListener> addReactionAddListener(ReactionAddListener listener) {
        return MessageAttachableListenerManager.addReactionAddListener(getApi(),
                                                                       getId(),
                                                                       listener);
    }

    @Override
    default List<ReactionAddListener> getReactionAddListeners() {
        return MessageAttachableListenerManager.getReactionAddListeners(getApi(),
                                                                        getId());
    }

    @Override
    default ListenerManager<ReactionRemoveAllListener> addReactionRemoveAllListener(ReactionRemoveAllListener listener) {
        return MessageAttachableListenerManager.addReactionRemoveAllListener(getApi(),
                                                                             getId(),
                                                                             listener);
    }

    @Override
    default List<ReactionRemoveAllListener> getReactionRemoveAllListeners() {
        return MessageAttachableListenerManager.getReactionRemoveAllListeners(getApi(),
                                                                              getId());
    }

    @Override
    default ListenerManager<CachedMessageUnpinListener> addCachedMessageUnpinListener(CachedMessageUnpinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             getId(),
                                                             CachedMessageUnpinListener.class,
                                                             listener);
    }

    @Override
    default List<CachedMessageUnpinListener> getCachedMessageUnpinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              getId(),
                                                              CachedMessageUnpinListener.class);
    }

    @Override
    default ListenerManager<CachedMessagePinListener> addCachedMessagePinListener(CachedMessagePinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             getId(),
                                                             CachedMessagePinListener.class,
                                                             listener);
    }

    @Override
    default List<CachedMessagePinListener> getCachedMessagePinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              getId(),
                                                              CachedMessagePinListener.class);
    }

    @Override
    default ListenerManager<MessageReplyListener> addMessageReplyListener(MessageReplyListener listener) {
        return MessageAttachableListenerManager.addMessageReplyListener(getApi(),
                                                                        getId(),
                                                                        listener);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners() {
        return MessageAttachableListenerManager.getMessageReplyListeners(getApi(),
                                                                         getId());
    }

    @Override
    default ListenerManager<MessageDeleteListener> addMessageDeleteListener(MessageDeleteListener listener) {
        return MessageAttachableListenerManager.addMessageDeleteListener(getApi(),
                                                                         getId(),
                                                                         listener);
    }

    @Override
    default List<MessageDeleteListener> getMessageDeleteListeners() {
        return MessageAttachableListenerManager.getMessageDeleteListeners(getApi(),
                                                                          getId());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends MessageAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addMessageAttachableListener(T listener) {
        return MessageAttachableListenerManager.addMessageAttachableListener(getApi(),
                                                                             getId(),
                                                                             listener);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends MessageAttachableListener & ObjectAttachableListener> void removeMessageAttachableListener(T listener) {
        MessageAttachableListenerManager.removeMessageAttachableListener(getApi(),
                                                                         getId(),
                                                                         listener);
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getMessageAttachableListeners() {
        return MessageAttachableListenerManager.getMessageAttachableListeners(getApi(),
                                                                              getId());
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        MessageAttachableListenerManager.removeListener(getApi(),
                                                        getId(),
                                                        listenerClass,
                                                        listener);
    }
}
