package org.javacord.core.listener.message;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.message.Message;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.interaction.ButtonClickListener;
import org.javacord.api.listener.interaction.MessageComponentCreateListener;
import org.javacord.api.listener.interaction.MessageContextMenuCommandListener;
import org.javacord.api.listener.interaction.SelectMenuChooseListener;
import org.javacord.api.listener.message.MessageAttachableListener;
import org.javacord.api.listener.message.MessageDeleteListener;
import org.javacord.api.listener.message.MessageEditListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.message.UncachedMessageAttachableListenerManager;
import org.javacord.api.listener.message.reaction.ReactionAddListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveAllListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code UncachedMessageAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalUncachedMessageAttachableListenerManager extends UncachedMessageAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    @Override
    default ListenerManager<MessageContextMenuCommandListener> addMessageContextMenuCommandListener(long messageId, MessageContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             MessageContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<MessageContextMenuCommandListener> getMessageContextMenuCommandListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              MessageContextMenuCommandListener.class);
    }

    @Override
    default List<MessageContextMenuCommandListener> getMessageContextMenuCommandListeners(String messageId) {
        try {
            return getMessageContextMenuCommandListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<MessageComponentCreateListener> addMessageComponentCreateListener(long messageId, MessageComponentCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             MessageComponentCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageComponentCreateListener> getMessageComponentCreateListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              MessageComponentCreateListener.class);
    }

    @Override
    default List<MessageComponentCreateListener> getMessageComponentCreateListeners(String messageId) {
        try {
            return getMessageComponentCreateListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<SelectMenuChooseListener> addSelectMenuChooseListener(long messageId, SelectMenuChooseListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             SelectMenuChooseListener.class,
                                                             listener);
    }

    @Override
    default List<SelectMenuChooseListener> getSelectMenuChooseListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              SelectMenuChooseListener.class);
    }

    @Override
    default List<SelectMenuChooseListener> getSelectMenuChooseListeners(String messageId) {
        try {
            return getSelectMenuChooseListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<ButtonClickListener> addButtonClickListener(long messageId, ButtonClickListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             ButtonClickListener.class,
                                                             listener);
    }

    @Override
    default List<ButtonClickListener> getButtonClickListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              ButtonClickListener.class);
    }

    @Override
    default List<ButtonClickListener> getButtonClickListeners(String messageId) {
        try {
            return getButtonClickListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<MessageEditListener> addMessageEditListener(long messageId, MessageEditListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             MessageEditListener.class,
                                                             listener);
    }

    @Override
    default List<MessageEditListener> getMessageEditListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              MessageEditListener.class);
    }

    @Override
    default List<MessageEditListener> getMessageEditListeners(String messageId) {
        try {
            return getMessageEditListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<ReactionRemoveListener> addReactionRemoveListener(long messageId, ReactionRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             ReactionRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveListener> getReactionRemoveListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              ReactionRemoveListener.class);
    }

    @Override
    default List<ReactionRemoveListener> getReactionRemoveListeners(String messageId) {
        try {
            return getReactionRemoveListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<ReactionAddListener> addReactionAddListener(long messageId, ReactionAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             ReactionAddListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionAddListener> getReactionAddListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              ReactionAddListener.class);
    }

    @Override
    default List<ReactionAddListener> getReactionAddListeners(String messageId) {
        try {
            return getReactionAddListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<ReactionRemoveAllListener> addReactionRemoveAllListener(long messageId, ReactionRemoveAllListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             ReactionRemoveAllListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveAllListener> getReactionRemoveAllListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              ReactionRemoveAllListener.class);
    }

    @Override
    default List<ReactionRemoveAllListener> getReactionRemoveAllListeners(String messageId) {
        try {
            return getReactionRemoveAllListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<MessageReplyListener> addMessageReplyListener(long messageId, MessageReplyListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             MessageReplyListener.class,
                                                             listener);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              MessageReplyListener.class);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners(String messageId) {
        try {
            return getMessageReplyListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    default ListenerManager<MessageDeleteListener> addMessageDeleteListener(long messageId, MessageDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                             messageId,
                                                             MessageDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<MessageDeleteListener> getMessageDeleteListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId,
                                                              MessageDeleteListener.class);
    }

    @Override
    default List<MessageDeleteListener> getMessageDeleteListeners(String messageId) {
        try {
            return getMessageDeleteListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends MessageAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addMessageAttachableListener(long messageId, T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(MessageAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(Message.class,
                                                                                              messageId,
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addMessageAttachableListener(String messageId, T listener) {
        try {
            return addMessageAttachableListener(Long.parseLong(messageId),
                                                listener);
        } catch (NumberFormatException ignored) {
            return Collections.emptyList();
        }
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends MessageAttachableListener & ObjectAttachableListener> void removeMessageAttachableListener(long messageId, T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(MessageAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> removeListener(messageId,
                                                            listenerClass,
                                                            listener));
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> void removeMessageAttachableListener(String messageId, T listener) {
        try {
            removeMessageAttachableListener(Long.parseLong(messageId),
                                            listener);
        } catch (NumberFormatException ignored) {
        }
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getMessageAttachableListeners(long messageId) {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Message.class,
                                                              messageId);
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getMessageAttachableListeners(String messageId) {
        try {
            return getMessageAttachableListeners(Long.parseLong(messageId));
        } catch (NumberFormatException ignored) {
            return Collections.emptyMap();
        }
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> void removeListener(long messageId, Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(Message.class,
                                                         messageId,
                                                         listenerClass,
                                                         listener);
    }

    @Override
    default <T extends MessageAttachableListener & ObjectAttachableListener> void removeListener(String messageId, Class<T> listenerClass, T listener) {
        try {
            removeListener(Long.parseLong(messageId),
                           listenerClass,
                           listener);
        } catch (NumberFormatException ignored) {
        }
    }
}
