package org.javacord.core.listener.server;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.server.Server;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeNameListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeNsfwFlagListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeOverwrittenPermissionsListener;
import org.javacord.api.listener.channel.server.ServerChannelChangePositionListener;
import org.javacord.api.listener.channel.server.ServerChannelCreateListener;
import org.javacord.api.listener.channel.server.ServerChannelDeleteListener;
import org.javacord.api.listener.channel.server.invite.ServerChannelInviteCreateListener;
import org.javacord.api.listener.channel.server.invite.ServerChannelInviteDeleteListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeDefaultAutoArchiveDurationListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeSlowmodeListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeTopicListener;
import org.javacord.api.listener.channel.server.text.WebhooksUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelMembersUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadListSyncListener;
import org.javacord.api.listener.channel.server.voice.ServerStageVoiceChannelChangeTopicListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeBitrateListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeNsfwListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeUserLimitListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberJoinListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberLeaveListener;
import org.javacord.api.listener.interaction.AutocompleteCreateListener;
import org.javacord.api.listener.interaction.ButtonClickListener;
import org.javacord.api.listener.interaction.InteractionCreateListener;
import org.javacord.api.listener.interaction.MessageComponentCreateListener;
import org.javacord.api.listener.interaction.MessageContextMenuCommandListener;
import org.javacord.api.listener.interaction.ModalSubmitListener;
import org.javacord.api.listener.interaction.SelectMenuChooseListener;
import org.javacord.api.listener.interaction.SlashCommandCreateListener;
import org.javacord.api.listener.interaction.UserContextMenuCommandListener;
import org.javacord.api.listener.message.CachedMessagePinListener;
import org.javacord.api.listener.message.CachedMessageUnpinListener;
import org.javacord.api.listener.message.ChannelPinsUpdateListener;
import org.javacord.api.listener.message.MessageCreateListener;
import org.javacord.api.listener.message.MessageDeleteListener;
import org.javacord.api.listener.message.MessageEditListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.message.reaction.ReactionAddListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveAllListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveListener;
import org.javacord.api.listener.server.ApplicationCommandPermissionsUpdateListener;
import org.javacord.api.listener.server.ServerAttachableListener;
import org.javacord.api.listener.server.ServerAttachableListenerManager;
import org.javacord.api.listener.server.ServerBecomesUnavailableListener;
import org.javacord.api.listener.server.ServerChangeAfkChannelListener;
import org.javacord.api.listener.server.ServerChangeAfkTimeoutListener;
import org.javacord.api.listener.server.ServerChangeBoostCountListener;
import org.javacord.api.listener.server.ServerChangeBoostLevelListener;
import org.javacord.api.listener.server.ServerChangeDefaultMessageNotificationLevelListener;
import org.javacord.api.listener.server.ServerChangeDescriptionListener;
import org.javacord.api.listener.server.ServerChangeDiscoverySplashListener;
import org.javacord.api.listener.server.ServerChangeExplicitContentFilterLevelListener;
import org.javacord.api.listener.server.ServerChangeIconListener;
import org.javacord.api.listener.server.ServerChangeModeratorsOnlyChannelListener;
import org.javacord.api.listener.server.ServerChangeMultiFactorAuthenticationLevelListener;
import org.javacord.api.listener.server.ServerChangeNameListener;
import org.javacord.api.listener.server.ServerChangeNsfwLevelListener;
import org.javacord.api.listener.server.ServerChangeOwnerListener;
import org.javacord.api.listener.server.ServerChangePreferredLocaleListener;
import org.javacord.api.listener.server.ServerChangeRegionListener;
import org.javacord.api.listener.server.ServerChangeRulesChannelListener;
import org.javacord.api.listener.server.ServerChangeServerFeatureListener;
import org.javacord.api.listener.server.ServerChangeSplashListener;
import org.javacord.api.listener.server.ServerChangeSystemChannelListener;
import org.javacord.api.listener.server.ServerChangeVanityUrlCodeListener;
import org.javacord.api.listener.server.ServerChangeVerificationLevelListener;
import org.javacord.api.listener.server.ServerLeaveListener;
import org.javacord.api.listener.server.VoiceServerUpdateListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiChangeNameListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiChangeWhitelistedRolesListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiCreateListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiDeleteListener;
import org.javacord.api.listener.server.member.ServerMemberBanListener;
import org.javacord.api.listener.server.member.ServerMemberJoinListener;
import org.javacord.api.listener.server.member.ServerMemberLeaveListener;
import org.javacord.api.listener.server.member.ServerMemberUnbanListener;
import org.javacord.api.listener.server.member.ServerMembersChunkListener;
import org.javacord.api.listener.server.role.RoleChangeColorListener;
import org.javacord.api.listener.server.role.RoleChangeHoistListener;
import org.javacord.api.listener.server.role.RoleChangeMentionableListener;
import org.javacord.api.listener.server.role.RoleChangeNameListener;
import org.javacord.api.listener.server.role.RoleChangePermissionsListener;
import org.javacord.api.listener.server.role.RoleChangePositionListener;
import org.javacord.api.listener.server.role.RoleCreateListener;
import org.javacord.api.listener.server.role.RoleDeleteListener;
import org.javacord.api.listener.server.role.UserRoleAddListener;
import org.javacord.api.listener.server.role.UserRoleRemoveListener;
import org.javacord.api.listener.server.sticker.StickerChangeDescriptionListener;
import org.javacord.api.listener.server.sticker.StickerChangeNameListener;
import org.javacord.api.listener.server.sticker.StickerChangeTagsListener;
import org.javacord.api.listener.server.sticker.StickerCreateListener;
import org.javacord.api.listener.server.sticker.StickerDeleteListener;
import org.javacord.api.listener.server.thread.ServerPrivateThreadJoinListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeArchiveTimestampListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeArchivedListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeAutoArchiveDurationListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeInvitableListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeLastMessageIdListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeLockedListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeMemberCountListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeMessageCountListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeRateLimitPerUserListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeTotalMessageSentListener;
import org.javacord.api.listener.user.UserChangeActivityListener;
import org.javacord.api.listener.user.UserChangeAvatarListener;
import org.javacord.api.listener.user.UserChangeDeafenedListener;
import org.javacord.api.listener.user.UserChangeDiscriminatorListener;
import org.javacord.api.listener.user.UserChangeMutedListener;
import org.javacord.api.listener.user.UserChangeNameListener;
import org.javacord.api.listener.user.UserChangeNicknameListener;
import org.javacord.api.listener.user.UserChangePendingListener;
import org.javacord.api.listener.user.UserChangeSelfDeafenedListener;
import org.javacord.api.listener.user.UserChangeSelfMutedListener;
import org.javacord.api.listener.user.UserChangeServerAvatarListener;
import org.javacord.api.listener.user.UserChangeStatusListener;
import org.javacord.api.listener.user.UserChangeTimeoutListener;
import org.javacord.api.listener.user.UserStartTypingListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code ServerAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalServerAttachableListenerManager extends ServerAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<InteractionCreateListener> addInteractionCreateListener(InteractionCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             InteractionCreateListener.class,
                                                             listener);
    }

    @Override
    default List<InteractionCreateListener> getInteractionCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              InteractionCreateListener.class);
    }

    @Override
    default ListenerManager<SlashCommandCreateListener> addSlashCommandCreateListener(SlashCommandCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             SlashCommandCreateListener.class,
                                                             listener);
    }

    @Override
    default List<SlashCommandCreateListener> getSlashCommandCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              SlashCommandCreateListener.class);
    }

    @Override
    default ListenerManager<AutocompleteCreateListener> addAutocompleteCreateListener(AutocompleteCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             AutocompleteCreateListener.class,
                                                             listener);
    }

    @Override
    default List<AutocompleteCreateListener> getAutocompleteCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              AutocompleteCreateListener.class);
    }

    @Override
    default ListenerManager<ModalSubmitListener> addModalSubmitListener(ModalSubmitListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ModalSubmitListener.class,
                                                             listener);
    }

    @Override
    default List<ModalSubmitListener> getModalSubmitListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ModalSubmitListener.class);
    }

    @Override
    default ListenerManager<MessageContextMenuCommandListener> addMessageContextMenuCommandListener(MessageContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             MessageContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<MessageContextMenuCommandListener> getMessageContextMenuCommandListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              MessageContextMenuCommandListener.class);
    }

    @Override
    default ListenerManager<MessageComponentCreateListener> addMessageComponentCreateListener(MessageComponentCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             MessageComponentCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageComponentCreateListener> getMessageComponentCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              MessageComponentCreateListener.class);
    }

    @Override
    default ListenerManager<UserContextMenuCommandListener> addUserContextMenuCommandListener(UserContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<UserContextMenuCommandListener> getUserContextMenuCommandListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserContextMenuCommandListener.class);
    }

    @Override
    default ListenerManager<SelectMenuChooseListener> addSelectMenuChooseListener(SelectMenuChooseListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             SelectMenuChooseListener.class,
                                                             listener);
    }

    @Override
    default List<SelectMenuChooseListener> getSelectMenuChooseListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              SelectMenuChooseListener.class);
    }

    @Override
    default ListenerManager<ButtonClickListener> addButtonClickListener(ButtonClickListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ButtonClickListener.class,
                                                             listener);
    }

    @Override
    default List<ButtonClickListener> getButtonClickListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ButtonClickListener.class);
    }

    @Override
    default ListenerManager<ServerChangeIconListener> addServerChangeIconListener(ServerChangeIconListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeIconListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeIconListener> getServerChangeIconListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeIconListener.class);
    }

    @Override
    default ListenerManager<ServerChangeNameListener> addServerChangeNameListener(ServerChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeNameListener> getServerChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeNameListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeLastMessageIdListener> addServerThreadChannelChangeLastMessageIdListener(ServerThreadChannelChangeLastMessageIdListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeLastMessageIdListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeLastMessageIdListener> getServerThreadChannelChangeLastMessageIdListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeLastMessageIdListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeArchivedListener> addServerThreadChannelChangeArchivedListener(ServerThreadChannelChangeArchivedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeArchivedListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeArchivedListener> getServerThreadChannelChangeArchivedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeArchivedListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeMemberCountListener> addServerThreadChannelChangeMemberCountListener(ServerThreadChannelChangeMemberCountListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeMemberCountListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeMemberCountListener> getServerThreadChannelChangeMemberCountListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeMemberCountListener.class);
    }

    @Override
    default ListenerManager<ServerPrivateThreadJoinListener> addServerPrivateThreadJoinListener(ServerPrivateThreadJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerPrivateThreadJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerPrivateThreadJoinListener> getServerPrivateThreadJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerPrivateThreadJoinListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeInvitableListener> addServerThreadChannelChangeInvitableListener(ServerThreadChannelChangeInvitableListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeInvitableListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeInvitableListener> getServerThreadChannelChangeInvitableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeInvitableListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeAutoArchiveDurationListener> addServerThreadChannelChangeAutoArchiveDurationListener(ServerThreadChannelChangeAutoArchiveDurationListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeAutoArchiveDurationListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeAutoArchiveDurationListener> getServerThreadChannelChangeAutoArchiveDurationListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeAutoArchiveDurationListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeRateLimitPerUserListener> addServerThreadChannelChangeRateLimitPerUserListener(ServerThreadChannelChangeRateLimitPerUserListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeRateLimitPerUserListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeRateLimitPerUserListener> getServerThreadChannelChangeRateLimitPerUserListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeRateLimitPerUserListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeLockedListener> addServerThreadChannelChangeLockedListener(ServerThreadChannelChangeLockedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeLockedListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeLockedListener> getServerThreadChannelChangeLockedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeLockedListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeArchiveTimestampListener> addServerThreadChannelChangeArchiveTimestampListener(ServerThreadChannelChangeArchiveTimestampListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeArchiveTimestampListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeArchiveTimestampListener> getServerThreadChannelChangeArchiveTimestampListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeArchiveTimestampListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeTotalMessageSentListener> addServerThreadChannelChangeTotalMessageSentListener(ServerThreadChannelChangeTotalMessageSentListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeTotalMessageSentListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeTotalMessageSentListener> getServerThreadChannelChangeTotalMessageSentListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeTotalMessageSentListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelChangeMessageCountListener> addServerThreadChannelChangeMessageCountListener(ServerThreadChannelChangeMessageCountListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelChangeMessageCountListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelChangeMessageCountListener> getServerThreadChannelChangeMessageCountListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelChangeMessageCountListener.class);
    }

    @Override
    default ListenerManager<ServerChangeAfkTimeoutListener> addServerChangeAfkTimeoutListener(ServerChangeAfkTimeoutListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeAfkTimeoutListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeAfkTimeoutListener> getServerChangeAfkTimeoutListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeAfkTimeoutListener.class);
    }

    @Override
    default ListenerManager<StickerChangeTagsListener> addStickerChangeTagsListener(StickerChangeTagsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             StickerChangeTagsListener.class,
                                                             listener);
    }

    @Override
    default List<StickerChangeTagsListener> getStickerChangeTagsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              StickerChangeTagsListener.class);
    }

    @Override
    default ListenerManager<StickerChangeDescriptionListener> addStickerChangeDescriptionListener(StickerChangeDescriptionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             StickerChangeDescriptionListener.class,
                                                             listener);
    }

    @Override
    default List<StickerChangeDescriptionListener> getStickerChangeDescriptionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              StickerChangeDescriptionListener.class);
    }

    @Override
    default ListenerManager<StickerCreateListener> addStickerCreateListener(StickerCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             StickerCreateListener.class,
                                                             listener);
    }

    @Override
    default List<StickerCreateListener> getStickerCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              StickerCreateListener.class);
    }

    @Override
    default ListenerManager<StickerChangeNameListener> addStickerChangeNameListener(StickerChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             StickerChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<StickerChangeNameListener> getStickerChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              StickerChangeNameListener.class);
    }

    @Override
    default ListenerManager<StickerDeleteListener> addStickerDeleteListener(StickerDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             StickerDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<StickerDeleteListener> getStickerDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              StickerDeleteListener.class);
    }

    @Override
    default ListenerManager<ServerChangeSplashListener> addServerChangeSplashListener(ServerChangeSplashListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeSplashListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeSplashListener> getServerChangeSplashListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeSplashListener.class);
    }

    @Override
    default ListenerManager<ServerChangeAfkChannelListener> addServerChangeAfkChannelListener(ServerChangeAfkChannelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeAfkChannelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeAfkChannelListener> getServerChangeAfkChannelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeAfkChannelListener.class);
    }

    @Override
    default ListenerManager<ServerChangeVanityUrlCodeListener> addServerChangeVanityUrlCodeListener(ServerChangeVanityUrlCodeListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeVanityUrlCodeListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeVanityUrlCodeListener> getServerChangeVanityUrlCodeListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeVanityUrlCodeListener.class);
    }

    @Override
    default ListenerManager<ServerChangeDiscoverySplashListener> addServerChangeDiscoverySplashListener(ServerChangeDiscoverySplashListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeDiscoverySplashListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeDiscoverySplashListener> getServerChangeDiscoverySplashListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeDiscoverySplashListener.class);
    }

    @Override
    default ListenerManager<ApplicationCommandPermissionsUpdateListener> addApplicationCommandPermissionsUpdateListener(ApplicationCommandPermissionsUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ApplicationCommandPermissionsUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ApplicationCommandPermissionsUpdateListener> getApplicationCommandPermissionsUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ApplicationCommandPermissionsUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerBecomesUnavailableListener> addServerBecomesUnavailableListener(ServerBecomesUnavailableListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerBecomesUnavailableListener.class,
                                                             listener);
    }

    @Override
    default List<ServerBecomesUnavailableListener> getServerBecomesUnavailableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerBecomesUnavailableListener.class);
    }

    @Override
    default ListenerManager<VoiceServerUpdateListener> addVoiceServerUpdateListener(VoiceServerUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             VoiceServerUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<VoiceServerUpdateListener> getVoiceServerUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              VoiceServerUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerChangeDescriptionListener> addServerChangeDescriptionListener(ServerChangeDescriptionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeDescriptionListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeDescriptionListener> getServerChangeDescriptionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeDescriptionListener.class);
    }

    @Override
    default ListenerManager<ServerChangeVerificationLevelListener> addServerChangeVerificationLevelListener(ServerChangeVerificationLevelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeVerificationLevelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeVerificationLevelListener> getServerChangeVerificationLevelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeVerificationLevelListener.class);
    }

    @Override
    default ListenerManager<ServerLeaveListener> addServerLeaveListener(ServerLeaveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerLeaveListener.class,
                                                             listener);
    }

    @Override
    default List<ServerLeaveListener> getServerLeaveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerLeaveListener.class);
    }

    @Override
    default ListenerManager<ServerChangeBoostCountListener> addServerChangeBoostCountListener(ServerChangeBoostCountListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeBoostCountListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeBoostCountListener> getServerChangeBoostCountListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeBoostCountListener.class);
    }

    @Override
    default ListenerManager<ServerChangeDefaultMessageNotificationLevelListener> addServerChangeDefaultMessageNotificationLevelListener(ServerChangeDefaultMessageNotificationLevelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeDefaultMessageNotificationLevelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeDefaultMessageNotificationLevelListener> getServerChangeDefaultMessageNotificationLevelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeDefaultMessageNotificationLevelListener.class);
    }

    @Override
    default ListenerManager<ServerChangeRegionListener> addServerChangeRegionListener(ServerChangeRegionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeRegionListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeRegionListener> getServerChangeRegionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeRegionListener.class);
    }

    @Override
    default ListenerManager<ServerMemberJoinListener> addServerMemberJoinListener(ServerMemberJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerMemberJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberJoinListener> getServerMemberJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerMemberJoinListener.class);
    }

    @Override
    default ListenerManager<ServerMemberLeaveListener> addServerMemberLeaveListener(ServerMemberLeaveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerMemberLeaveListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberLeaveListener> getServerMemberLeaveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerMemberLeaveListener.class);
    }

    @Override
    default ListenerManager<ServerMemberBanListener> addServerMemberBanListener(ServerMemberBanListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerMemberBanListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberBanListener> getServerMemberBanListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerMemberBanListener.class);
    }

    @Override
    default ListenerManager<ServerMembersChunkListener> addServerMembersChunkListener(ServerMembersChunkListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerMembersChunkListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMembersChunkListener> getServerMembersChunkListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerMembersChunkListener.class);
    }

    @Override
    default ListenerManager<ServerMemberUnbanListener> addServerMemberUnbanListener(ServerMemberUnbanListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerMemberUnbanListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberUnbanListener> getServerMemberUnbanListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerMemberUnbanListener.class);
    }

    @Override
    default ListenerManager<KnownCustomEmojiChangeNameListener> addKnownCustomEmojiChangeNameListener(KnownCustomEmojiChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             KnownCustomEmojiChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiChangeNameListener> getKnownCustomEmojiChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              KnownCustomEmojiChangeNameListener.class);
    }

    @Override
    default ListenerManager<KnownCustomEmojiDeleteListener> addKnownCustomEmojiDeleteListener(KnownCustomEmojiDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             KnownCustomEmojiDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiDeleteListener> getKnownCustomEmojiDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              KnownCustomEmojiDeleteListener.class);
    }

    @Override
    default ListenerManager<KnownCustomEmojiChangeWhitelistedRolesListener> addKnownCustomEmojiChangeWhitelistedRolesListener(KnownCustomEmojiChangeWhitelistedRolesListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             KnownCustomEmojiChangeWhitelistedRolesListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiChangeWhitelistedRolesListener> getKnownCustomEmojiChangeWhitelistedRolesListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              KnownCustomEmojiChangeWhitelistedRolesListener.class);
    }

    @Override
    default ListenerManager<KnownCustomEmojiCreateListener> addKnownCustomEmojiCreateListener(KnownCustomEmojiCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             KnownCustomEmojiCreateListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiCreateListener> getKnownCustomEmojiCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              KnownCustomEmojiCreateListener.class);
    }

    @Override
    default ListenerManager<ServerChangeSystemChannelListener> addServerChangeSystemChannelListener(ServerChangeSystemChannelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeSystemChannelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeSystemChannelListener> getServerChangeSystemChannelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeSystemChannelListener.class);
    }

    @Override
    default ListenerManager<ServerChangePreferredLocaleListener> addServerChangePreferredLocaleListener(ServerChangePreferredLocaleListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangePreferredLocaleListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangePreferredLocaleListener> getServerChangePreferredLocaleListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangePreferredLocaleListener.class);
    }

    @Override
    default ListenerManager<ServerChangeBoostLevelListener> addServerChangeBoostLevelListener(ServerChangeBoostLevelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeBoostLevelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeBoostLevelListener> getServerChangeBoostLevelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeBoostLevelListener.class);
    }

    @Override
    default ListenerManager<ServerChangeRulesChannelListener> addServerChangeRulesChannelListener(ServerChangeRulesChannelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeRulesChannelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeRulesChannelListener> getServerChangeRulesChannelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeRulesChannelListener.class);
    }

    @Override
    default ListenerManager<ServerChangeServerFeatureListener> addServerChangeServerFeatureListener(ServerChangeServerFeatureListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeServerFeatureListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeServerFeatureListener> getServerChangeServerFeatureListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeServerFeatureListener.class);
    }

    @Override
    default ListenerManager<ServerChangeOwnerListener> addServerChangeOwnerListener(ServerChangeOwnerListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeOwnerListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeOwnerListener> getServerChangeOwnerListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeOwnerListener.class);
    }

    @Override
    default ListenerManager<ServerChangeMultiFactorAuthenticationLevelListener> addServerChangeMultiFactorAuthenticationLevelListener(ServerChangeMultiFactorAuthenticationLevelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeMultiFactorAuthenticationLevelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeMultiFactorAuthenticationLevelListener> getServerChangeMultiFactorAuthenticationLevelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeMultiFactorAuthenticationLevelListener.class);
    }

    @Override
    default ListenerManager<ServerChangeExplicitContentFilterLevelListener> addServerChangeExplicitContentFilterLevelListener(ServerChangeExplicitContentFilterLevelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeExplicitContentFilterLevelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeExplicitContentFilterLevelListener> getServerChangeExplicitContentFilterLevelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeExplicitContentFilterLevelListener.class);
    }

    @Override
    default ListenerManager<RoleChangePositionListener> addRoleChangePositionListener(RoleChangePositionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleChangePositionListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangePositionListener> getRoleChangePositionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleChangePositionListener.class);
    }

    @Override
    default ListenerManager<RoleChangeMentionableListener> addRoleChangeMentionableListener(RoleChangeMentionableListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleChangeMentionableListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeMentionableListener> getRoleChangeMentionableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleChangeMentionableListener.class);
    }

    @Override
    default ListenerManager<RoleChangeColorListener> addRoleChangeColorListener(RoleChangeColorListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleChangeColorListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeColorListener> getRoleChangeColorListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleChangeColorListener.class);
    }

    @Override
    default ListenerManager<RoleChangeNameListener> addRoleChangeNameListener(RoleChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeNameListener> getRoleChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleChangeNameListener.class);
    }

    @Override
    default ListenerManager<RoleChangeHoistListener> addRoleChangeHoistListener(RoleChangeHoistListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleChangeHoistListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeHoistListener> getRoleChangeHoistListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleChangeHoistListener.class);
    }

    @Override
    default ListenerManager<RoleCreateListener> addRoleCreateListener(RoleCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleCreateListener.class,
                                                             listener);
    }

    @Override
    default List<RoleCreateListener> getRoleCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleCreateListener.class);
    }

    @Override
    default ListenerManager<RoleChangePermissionsListener> addRoleChangePermissionsListener(RoleChangePermissionsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleChangePermissionsListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangePermissionsListener> getRoleChangePermissionsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleChangePermissionsListener.class);
    }

    @Override
    default ListenerManager<UserRoleRemoveListener> addUserRoleRemoveListener(UserRoleRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserRoleRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<UserRoleRemoveListener> getUserRoleRemoveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserRoleRemoveListener.class);
    }

    @Override
    default ListenerManager<UserRoleAddListener> addUserRoleAddListener(UserRoleAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserRoleAddListener.class,
                                                             listener);
    }

    @Override
    default List<UserRoleAddListener> getUserRoleAddListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserRoleAddListener.class);
    }

    @Override
    default ListenerManager<RoleDeleteListener> addRoleDeleteListener(RoleDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             RoleDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<RoleDeleteListener> getRoleDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              RoleDeleteListener.class);
    }

    @Override
    default ListenerManager<ServerChangeModeratorsOnlyChannelListener> addServerChangeModeratorsOnlyChannelListener(ServerChangeModeratorsOnlyChannelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeModeratorsOnlyChannelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeModeratorsOnlyChannelListener> getServerChangeModeratorsOnlyChannelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeModeratorsOnlyChannelListener.class);
    }

    @Override
    default ListenerManager<ServerChangeNsfwLevelListener> addServerChangeNsfwLevelListener(ServerChangeNsfwLevelListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChangeNsfwLevelListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChangeNsfwLevelListener> getServerChangeNsfwLevelListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChangeNsfwLevelListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangePositionListener> addServerChannelChangePositionListener(ServerChannelChangePositionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelChangePositionListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangePositionListener> getServerChannelChangePositionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelChangePositionListener.class);
    }

    @Override
    default ListenerManager<ServerThreadListSyncListener> addServerThreadListSyncListener(ServerThreadListSyncListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadListSyncListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadListSyncListener> getServerThreadListSyncListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadListSyncListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelUpdateListener> addServerThreadChannelUpdateListener(ServerThreadChannelUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelUpdateListener> getServerThreadChannelUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerThreadChannelMembersUpdateListener> addServerThreadChannelMembersUpdateListener(ServerThreadChannelMembersUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerThreadChannelMembersUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerThreadChannelMembersUpdateListener> getServerThreadChannelMembersUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerThreadChannelMembersUpdateListener.class);
    }

    @Override
    default ListenerManager<WebhooksUpdateListener> addWebhooksUpdateListener(WebhooksUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             WebhooksUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<WebhooksUpdateListener> getWebhooksUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              WebhooksUpdateListener.class);
    }

    @Override
    default ListenerManager<ServerTextChannelChangeDefaultAutoArchiveDurationListener> addServerTextChannelChangeDefaultAutoArchiveDurationListener(ServerTextChannelChangeDefaultAutoArchiveDurationListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerTextChannelChangeDefaultAutoArchiveDurationListener.class,
                                                             listener);
    }

    @Override
    default List<ServerTextChannelChangeDefaultAutoArchiveDurationListener> getServerTextChannelChangeDefaultAutoArchiveDurationListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerTextChannelChangeDefaultAutoArchiveDurationListener.class);
    }

    @Override
    default ListenerManager<ServerTextChannelChangeSlowmodeListener> addServerTextChannelChangeSlowmodeListener(ServerTextChannelChangeSlowmodeListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerTextChannelChangeSlowmodeListener.class,
                                                             listener);
    }

    @Override
    default List<ServerTextChannelChangeSlowmodeListener> getServerTextChannelChangeSlowmodeListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerTextChannelChangeSlowmodeListener.class);
    }

    @Override
    default ListenerManager<ServerTextChannelChangeTopicListener> addServerTextChannelChangeTopicListener(ServerTextChannelChangeTopicListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerTextChannelChangeTopicListener.class,
                                                             listener);
    }

    @Override
    default List<ServerTextChannelChangeTopicListener> getServerTextChannelChangeTopicListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerTextChannelChangeTopicListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeOverwrittenPermissionsListener> addServerChannelChangeOverwrittenPermissionsListener(ServerChannelChangeOverwrittenPermissionsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelChangeOverwrittenPermissionsListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeOverwrittenPermissionsListener> getServerChannelChangeOverwrittenPermissionsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelChangeOverwrittenPermissionsListener.class);
    }

    @Override
    default ListenerManager<ServerChannelInviteDeleteListener> addServerChannelInviteDeleteListener(ServerChannelInviteDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelInviteDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelInviteDeleteListener> getServerChannelInviteDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelInviteDeleteListener.class);
    }

    @Override
    default ListenerManager<ServerChannelInviteCreateListener> addServerChannelInviteCreateListener(ServerChannelInviteCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelInviteCreateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelInviteCreateListener> getServerChannelInviteCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelInviteCreateListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeNsfwFlagListener> addServerChannelChangeNsfwFlagListener(ServerChannelChangeNsfwFlagListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelChangeNsfwFlagListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeNsfwFlagListener> getServerChannelChangeNsfwFlagListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelChangeNsfwFlagListener.class);
    }

    @Override
    default ListenerManager<ServerChannelDeleteListener> addServerChannelDeleteListener(ServerChannelDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelDeleteListener> getServerChannelDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelDeleteListener.class);
    }

    @Override
    default ListenerManager<ServerChannelCreateListener> addServerChannelCreateListener(ServerChannelCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelCreateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelCreateListener> getServerChannelCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelCreateListener.class);
    }

    @Override
    default ListenerManager<ServerStageVoiceChannelChangeTopicListener> addServerStageVoiceChannelChangeTopicListener(ServerStageVoiceChannelChangeTopicListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerStageVoiceChannelChangeTopicListener.class,
                                                             listener);
    }

    @Override
    default List<ServerStageVoiceChannelChangeTopicListener> getServerStageVoiceChannelChangeTopicListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerStageVoiceChannelChangeTopicListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelChangeBitrateListener> addServerVoiceChannelChangeBitrateListener(ServerVoiceChannelChangeBitrateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerVoiceChannelChangeBitrateListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelChangeBitrateListener> getServerVoiceChannelChangeBitrateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerVoiceChannelChangeBitrateListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelChangeUserLimitListener> addServerVoiceChannelChangeUserLimitListener(ServerVoiceChannelChangeUserLimitListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerVoiceChannelChangeUserLimitListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelChangeUserLimitListener> getServerVoiceChannelChangeUserLimitListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerVoiceChannelChangeUserLimitListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelMemberLeaveListener> addServerVoiceChannelMemberLeaveListener(ServerVoiceChannelMemberLeaveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerVoiceChannelMemberLeaveListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelMemberLeaveListener> getServerVoiceChannelMemberLeaveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerVoiceChannelMemberLeaveListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelChangeNsfwListener> addServerVoiceChannelChangeNsfwListener(ServerVoiceChannelChangeNsfwListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerVoiceChannelChangeNsfwListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelChangeNsfwListener> getServerVoiceChannelChangeNsfwListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerVoiceChannelChangeNsfwListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelMemberJoinListener> addServerVoiceChannelMemberJoinListener(ServerVoiceChannelMemberJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerVoiceChannelMemberJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelMemberJoinListener> getServerVoiceChannelMemberJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerVoiceChannelMemberJoinListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeNameListener> addServerChannelChangeNameListener(ServerChannelChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ServerChannelChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeNameListener> getServerChannelChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ServerChannelChangeNameListener.class);
    }

    @Override
    default ListenerManager<UserChangeDeafenedListener> addUserChangeDeafenedListener(UserChangeDeafenedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeDeafenedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeDeafenedListener> getUserChangeDeafenedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeDeafenedListener.class);
    }

    @Override
    default ListenerManager<UserChangeNicknameListener> addUserChangeNicknameListener(UserChangeNicknameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeNicknameListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeNicknameListener> getUserChangeNicknameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeNicknameListener.class);
    }

    @Override
    default ListenerManager<UserChangePendingListener> addUserChangePendingListener(UserChangePendingListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangePendingListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangePendingListener> getUserChangePendingListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangePendingListener.class);
    }

    @Override
    default ListenerManager<UserStartTypingListener> addUserStartTypingListener(UserStartTypingListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserStartTypingListener.class,
                                                             listener);
    }

    @Override
    default List<UserStartTypingListener> getUserStartTypingListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserStartTypingListener.class);
    }

    @Override
    default ListenerManager<UserChangeDiscriminatorListener> addUserChangeDiscriminatorListener(UserChangeDiscriminatorListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeDiscriminatorListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeDiscriminatorListener> getUserChangeDiscriminatorListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeDiscriminatorListener.class);
    }

    @Override
    default ListenerManager<UserChangeStatusListener> addUserChangeStatusListener(UserChangeStatusListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeStatusListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeStatusListener> getUserChangeStatusListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeStatusListener.class);
    }

    @Override
    default ListenerManager<UserChangeServerAvatarListener> addUserChangeServerAvatarListener(UserChangeServerAvatarListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeServerAvatarListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeServerAvatarListener> getUserChangeServerAvatarListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeServerAvatarListener.class);
    }

    @Override
    default ListenerManager<UserChangeSelfMutedListener> addUserChangeSelfMutedListener(UserChangeSelfMutedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeSelfMutedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeSelfMutedListener> getUserChangeSelfMutedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeSelfMutedListener.class);
    }

    @Override
    default ListenerManager<UserChangeNameListener> addUserChangeNameListener(UserChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeNameListener> getUserChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeNameListener.class);
    }

    @Override
    default ListenerManager<UserChangeTimeoutListener> addUserChangeTimeoutListener(UserChangeTimeoutListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeTimeoutListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeTimeoutListener> getUserChangeTimeoutListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeTimeoutListener.class);
    }

    @Override
    default ListenerManager<UserChangeAvatarListener> addUserChangeAvatarListener(UserChangeAvatarListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeAvatarListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeAvatarListener> getUserChangeAvatarListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeAvatarListener.class);
    }

    @Override
    default ListenerManager<UserChangeSelfDeafenedListener> addUserChangeSelfDeafenedListener(UserChangeSelfDeafenedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeSelfDeafenedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeSelfDeafenedListener> getUserChangeSelfDeafenedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeSelfDeafenedListener.class);
    }

    @Override
    default ListenerManager<UserChangeMutedListener> addUserChangeMutedListener(UserChangeMutedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeMutedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeMutedListener> getUserChangeMutedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeMutedListener.class);
    }

    @Override
    default ListenerManager<UserChangeActivityListener> addUserChangeActivityListener(UserChangeActivityListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             UserChangeActivityListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeActivityListener> getUserChangeActivityListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              UserChangeActivityListener.class);
    }

    @Override
    default ListenerManager<MessageEditListener> addMessageEditListener(MessageEditListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             MessageEditListener.class,
                                                             listener);
    }

    @Override
    default List<MessageEditListener> getMessageEditListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              MessageEditListener.class);
    }

    @Override
    default ListenerManager<ChannelPinsUpdateListener> addChannelPinsUpdateListener(ChannelPinsUpdateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ChannelPinsUpdateListener.class,
                                                             listener);
    }

    @Override
    default List<ChannelPinsUpdateListener> getChannelPinsUpdateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ChannelPinsUpdateListener.class);
    }

    @Override
    default ListenerManager<ReactionRemoveListener> addReactionRemoveListener(ReactionRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ReactionRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveListener> getReactionRemoveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ReactionRemoveListener.class);
    }

    @Override
    default ListenerManager<ReactionAddListener> addReactionAddListener(ReactionAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ReactionAddListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionAddListener> getReactionAddListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ReactionAddListener.class);
    }

    @Override
    default ListenerManager<ReactionRemoveAllListener> addReactionRemoveAllListener(ReactionRemoveAllListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             ReactionRemoveAllListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveAllListener> getReactionRemoveAllListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              ReactionRemoveAllListener.class);
    }

    @Override
    default ListenerManager<MessageCreateListener> addMessageCreateListener(MessageCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             MessageCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageCreateListener> getMessageCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              MessageCreateListener.class);
    }

    @Override
    default ListenerManager<CachedMessageUnpinListener> addCachedMessageUnpinListener(CachedMessageUnpinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             CachedMessageUnpinListener.class,
                                                             listener);
    }

    @Override
    default List<CachedMessageUnpinListener> getCachedMessageUnpinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              CachedMessageUnpinListener.class);
    }

    @Override
    default ListenerManager<CachedMessagePinListener> addCachedMessagePinListener(CachedMessagePinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             CachedMessagePinListener.class,
                                                             listener);
    }

    @Override
    default List<CachedMessagePinListener> getCachedMessagePinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              CachedMessagePinListener.class);
    }

    @Override
    default ListenerManager<MessageReplyListener> addMessageReplyListener(MessageReplyListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             MessageReplyListener.class,
                                                             listener);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              MessageReplyListener.class);
    }

    @Override
    default ListenerManager<MessageDeleteListener> addMessageDeleteListener(MessageDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                             getId(),
                                                             MessageDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<MessageDeleteListener> getMessageDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId(),
                                                              MessageDeleteListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addServerAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(ServerAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(Server.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends ServerAttachableListener & ObjectAttachableListener> void removeServerAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(ServerAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(Server.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends ServerAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getServerAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Server.class,
                                                              getId());
    }

    @Override
    default <T extends ServerAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(Server.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
