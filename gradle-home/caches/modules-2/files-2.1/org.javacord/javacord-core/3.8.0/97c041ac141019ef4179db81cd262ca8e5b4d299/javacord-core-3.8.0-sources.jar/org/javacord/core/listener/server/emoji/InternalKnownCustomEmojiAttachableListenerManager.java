package org.javacord.core.listener.server.emoji;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.emoji.KnownCustomEmoji;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiAttachableListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiAttachableListenerManager;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiChangeNameListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiChangeWhitelistedRolesListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiDeleteListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code KnownCustomEmojiAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalKnownCustomEmojiAttachableListenerManager extends KnownCustomEmojiAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<KnownCustomEmojiChangeNameListener> addKnownCustomEmojiChangeNameListener(KnownCustomEmojiChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(KnownCustomEmoji.class,
                                                             getId(),
                                                             KnownCustomEmojiChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiChangeNameListener> getKnownCustomEmojiChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(KnownCustomEmoji.class,
                                                              getId(),
                                                              KnownCustomEmojiChangeNameListener.class);
    }

    @Override
    default ListenerManager<KnownCustomEmojiDeleteListener> addKnownCustomEmojiDeleteListener(KnownCustomEmojiDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(KnownCustomEmoji.class,
                                                             getId(),
                                                             KnownCustomEmojiDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiDeleteListener> getKnownCustomEmojiDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(KnownCustomEmoji.class,
                                                              getId(),
                                                              KnownCustomEmojiDeleteListener.class);
    }

    @Override
    default ListenerManager<KnownCustomEmojiChangeWhitelistedRolesListener> addKnownCustomEmojiChangeWhitelistedRolesListener(KnownCustomEmojiChangeWhitelistedRolesListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(KnownCustomEmoji.class,
                                                             getId(),
                                                             KnownCustomEmojiChangeWhitelistedRolesListener.class,
                                                             listener);
    }

    @Override
    default List<KnownCustomEmojiChangeWhitelistedRolesListener> getKnownCustomEmojiChangeWhitelistedRolesListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(KnownCustomEmoji.class,
                                                              getId(),
                                                              KnownCustomEmojiChangeWhitelistedRolesListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends KnownCustomEmojiAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addKnownCustomEmojiAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(KnownCustomEmojiAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(KnownCustomEmoji.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends KnownCustomEmojiAttachableListener & ObjectAttachableListener> void removeKnownCustomEmojiAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(KnownCustomEmojiAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(KnownCustomEmoji.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends KnownCustomEmojiAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getKnownCustomEmojiAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(KnownCustomEmoji.class,
                                                              getId());
    }

    @Override
    default <T extends KnownCustomEmojiAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(KnownCustomEmoji.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
