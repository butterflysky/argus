package org.javacord.core.listener.server.role;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.permission.Role;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeOverwrittenPermissionsListener;
import org.javacord.api.listener.server.role.RoleAttachableListener;
import org.javacord.api.listener.server.role.RoleAttachableListenerManager;
import org.javacord.api.listener.server.role.RoleChangeColorListener;
import org.javacord.api.listener.server.role.RoleChangeHoistListener;
import org.javacord.api.listener.server.role.RoleChangeMentionableListener;
import org.javacord.api.listener.server.role.RoleChangeNameListener;
import org.javacord.api.listener.server.role.RoleChangePermissionsListener;
import org.javacord.api.listener.server.role.RoleChangePositionListener;
import org.javacord.api.listener.server.role.RoleDeleteListener;
import org.javacord.api.listener.server.role.UserRoleAddListener;
import org.javacord.api.listener.server.role.UserRoleRemoveListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code RoleAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalRoleAttachableListenerManager extends RoleAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<RoleChangePositionListener> addRoleChangePositionListener(RoleChangePositionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleChangePositionListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangePositionListener> getRoleChangePositionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleChangePositionListener.class);
    }

    @Override
    default ListenerManager<RoleChangeMentionableListener> addRoleChangeMentionableListener(RoleChangeMentionableListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleChangeMentionableListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeMentionableListener> getRoleChangeMentionableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleChangeMentionableListener.class);
    }

    @Override
    default ListenerManager<RoleChangeColorListener> addRoleChangeColorListener(RoleChangeColorListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleChangeColorListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeColorListener> getRoleChangeColorListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleChangeColorListener.class);
    }

    @Override
    default ListenerManager<RoleChangeNameListener> addRoleChangeNameListener(RoleChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeNameListener> getRoleChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleChangeNameListener.class);
    }

    @Override
    default ListenerManager<RoleChangeHoistListener> addRoleChangeHoistListener(RoleChangeHoistListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleChangeHoistListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangeHoistListener> getRoleChangeHoistListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleChangeHoistListener.class);
    }

    @Override
    default ListenerManager<RoleChangePermissionsListener> addRoleChangePermissionsListener(RoleChangePermissionsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleChangePermissionsListener.class,
                                                             listener);
    }

    @Override
    default List<RoleChangePermissionsListener> getRoleChangePermissionsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleChangePermissionsListener.class);
    }

    @Override
    default ListenerManager<UserRoleRemoveListener> addUserRoleRemoveListener(UserRoleRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             UserRoleRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<UserRoleRemoveListener> getUserRoleRemoveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              UserRoleRemoveListener.class);
    }

    @Override
    default ListenerManager<UserRoleAddListener> addUserRoleAddListener(UserRoleAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             UserRoleAddListener.class,
                                                             listener);
    }

    @Override
    default List<UserRoleAddListener> getUserRoleAddListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              UserRoleAddListener.class);
    }

    @Override
    default ListenerManager<RoleDeleteListener> addRoleDeleteListener(RoleDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             RoleDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<RoleDeleteListener> getRoleDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              RoleDeleteListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeOverwrittenPermissionsListener> addServerChannelChangeOverwrittenPermissionsListener(ServerChannelChangeOverwrittenPermissionsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                             getId(),
                                                             ServerChannelChangeOverwrittenPermissionsListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeOverwrittenPermissionsListener> getServerChannelChangeOverwrittenPermissionsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId(),
                                                              ServerChannelChangeOverwrittenPermissionsListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends RoleAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addRoleAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(RoleAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(Role.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends RoleAttachableListener & ObjectAttachableListener> void removeRoleAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(RoleAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(Role.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends RoleAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getRoleAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Role.class,
                                                              getId());
    }

    @Override
    default <T extends RoleAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(Role.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
