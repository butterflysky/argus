package org.javacord.core.listener.server.sticker;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.sticker.Sticker;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.server.sticker.StickerAttachableListener;
import org.javacord.api.listener.server.sticker.StickerAttachableListenerManager;
import org.javacord.api.listener.server.sticker.StickerChangeDescriptionListener;
import org.javacord.api.listener.server.sticker.StickerChangeNameListener;
import org.javacord.api.listener.server.sticker.StickerChangeTagsListener;
import org.javacord.api.listener.server.sticker.StickerDeleteListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code StickerAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalStickerAttachableListenerManager extends StickerAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<StickerChangeTagsListener> addStickerChangeTagsListener(StickerChangeTagsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Sticker.class,
                                                             getId(),
                                                             StickerChangeTagsListener.class,
                                                             listener);
    }

    @Override
    default List<StickerChangeTagsListener> getStickerChangeTagsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Sticker.class,
                                                              getId(),
                                                              StickerChangeTagsListener.class);
    }

    @Override
    default ListenerManager<StickerChangeDescriptionListener> addStickerChangeDescriptionListener(StickerChangeDescriptionListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Sticker.class,
                                                             getId(),
                                                             StickerChangeDescriptionListener.class,
                                                             listener);
    }

    @Override
    default List<StickerChangeDescriptionListener> getStickerChangeDescriptionListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Sticker.class,
                                                              getId(),
                                                              StickerChangeDescriptionListener.class);
    }

    @Override
    default ListenerManager<StickerChangeNameListener> addStickerChangeNameListener(StickerChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Sticker.class,
                                                             getId(),
                                                             StickerChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<StickerChangeNameListener> getStickerChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Sticker.class,
                                                              getId(),
                                                              StickerChangeNameListener.class);
    }

    @Override
    default ListenerManager<StickerDeleteListener> addStickerDeleteListener(StickerDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Sticker.class,
                                                             getId(),
                                                             StickerDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<StickerDeleteListener> getStickerDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Sticker.class,
                                                              getId(),
                                                              StickerDeleteListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends StickerAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addStickerAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(StickerAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(Sticker.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends StickerAttachableListener & ObjectAttachableListener> void removeStickerAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(StickerAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(Sticker.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends StickerAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getStickerAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Sticker.class,
                                                              getId());
    }

    @Override
    default <T extends StickerAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(Sticker.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
