package org.javacord.core.listener.user;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.user.User;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeOverwrittenPermissionsListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberJoinListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberLeaveListener;
import org.javacord.api.listener.channel.user.PrivateChannelCreateListener;
import org.javacord.api.listener.channel.user.PrivateChannelDeleteListener;
import org.javacord.api.listener.interaction.AutocompleteCreateListener;
import org.javacord.api.listener.interaction.ButtonClickListener;
import org.javacord.api.listener.interaction.InteractionCreateListener;
import org.javacord.api.listener.interaction.MessageComponentCreateListener;
import org.javacord.api.listener.interaction.MessageContextMenuCommandListener;
import org.javacord.api.listener.interaction.ModalSubmitListener;
import org.javacord.api.listener.interaction.SelectMenuChooseListener;
import org.javacord.api.listener.interaction.SlashCommandCreateListener;
import org.javacord.api.listener.interaction.UserContextMenuCommandListener;
import org.javacord.api.listener.message.MessageCreateListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.message.reaction.ReactionAddListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveListener;
import org.javacord.api.listener.server.member.ServerMemberBanListener;
import org.javacord.api.listener.server.member.ServerMemberJoinListener;
import org.javacord.api.listener.server.member.ServerMemberLeaveListener;
import org.javacord.api.listener.server.member.ServerMemberUnbanListener;
import org.javacord.api.listener.server.role.UserRoleAddListener;
import org.javacord.api.listener.server.role.UserRoleRemoveListener;
import org.javacord.api.listener.user.UserAttachableListener;
import org.javacord.api.listener.user.UserAttachableListenerManager;
import org.javacord.api.listener.user.UserChangeActivityListener;
import org.javacord.api.listener.user.UserChangeAvatarListener;
import org.javacord.api.listener.user.UserChangeDeafenedListener;
import org.javacord.api.listener.user.UserChangeDiscriminatorListener;
import org.javacord.api.listener.user.UserChangeMutedListener;
import org.javacord.api.listener.user.UserChangeNameListener;
import org.javacord.api.listener.user.UserChangeNicknameListener;
import org.javacord.api.listener.user.UserChangePendingListener;
import org.javacord.api.listener.user.UserChangeSelfDeafenedListener;
import org.javacord.api.listener.user.UserChangeSelfMutedListener;
import org.javacord.api.listener.user.UserChangeServerAvatarListener;
import org.javacord.api.listener.user.UserChangeStatusListener;
import org.javacord.api.listener.user.UserChangeTimeoutListener;
import org.javacord.api.listener.user.UserStartTypingListener;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code UserAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalUserAttachableListenerManager extends UserAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<InteractionCreateListener> addInteractionCreateListener(InteractionCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             InteractionCreateListener.class,
                                                             listener);
    }

    @Override
    default List<InteractionCreateListener> getInteractionCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              InteractionCreateListener.class);
    }

    @Override
    default ListenerManager<SlashCommandCreateListener> addSlashCommandCreateListener(SlashCommandCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             SlashCommandCreateListener.class,
                                                             listener);
    }

    @Override
    default List<SlashCommandCreateListener> getSlashCommandCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              SlashCommandCreateListener.class);
    }

    @Override
    default ListenerManager<AutocompleteCreateListener> addAutocompleteCreateListener(AutocompleteCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             AutocompleteCreateListener.class,
                                                             listener);
    }

    @Override
    default List<AutocompleteCreateListener> getAutocompleteCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              AutocompleteCreateListener.class);
    }

    @Override
    default ListenerManager<ModalSubmitListener> addModalSubmitListener(ModalSubmitListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ModalSubmitListener.class,
                                                             listener);
    }

    @Override
    default List<ModalSubmitListener> getModalSubmitListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ModalSubmitListener.class);
    }

    @Override
    default ListenerManager<MessageContextMenuCommandListener> addMessageContextMenuCommandListener(MessageContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             MessageContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<MessageContextMenuCommandListener> getMessageContextMenuCommandListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              MessageContextMenuCommandListener.class);
    }

    @Override
    default ListenerManager<MessageComponentCreateListener> addMessageComponentCreateListener(MessageComponentCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             MessageComponentCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageComponentCreateListener> getMessageComponentCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              MessageComponentCreateListener.class);
    }

    @Override
    default ListenerManager<UserContextMenuCommandListener> addUserContextMenuCommandListener(UserContextMenuCommandListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserContextMenuCommandListener.class,
                                                             listener);
    }

    @Override
    default List<UserContextMenuCommandListener> getUserContextMenuCommandListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserContextMenuCommandListener.class);
    }

    @Override
    default ListenerManager<SelectMenuChooseListener> addSelectMenuChooseListener(SelectMenuChooseListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             SelectMenuChooseListener.class,
                                                             listener);
    }

    @Override
    default List<SelectMenuChooseListener> getSelectMenuChooseListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              SelectMenuChooseListener.class);
    }

    @Override
    default ListenerManager<ButtonClickListener> addButtonClickListener(ButtonClickListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ButtonClickListener.class,
                                                             listener);
    }

    @Override
    default List<ButtonClickListener> getButtonClickListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ButtonClickListener.class);
    }

    @Override
    default ListenerManager<ServerMemberJoinListener> addServerMemberJoinListener(ServerMemberJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerMemberJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberJoinListener> getServerMemberJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerMemberJoinListener.class);
    }

    @Override
    default ListenerManager<ServerMemberLeaveListener> addServerMemberLeaveListener(ServerMemberLeaveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerMemberLeaveListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberLeaveListener> getServerMemberLeaveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerMemberLeaveListener.class);
    }

    @Override
    default ListenerManager<ServerMemberBanListener> addServerMemberBanListener(ServerMemberBanListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerMemberBanListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberBanListener> getServerMemberBanListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerMemberBanListener.class);
    }

    @Override
    default ListenerManager<ServerMemberUnbanListener> addServerMemberUnbanListener(ServerMemberUnbanListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerMemberUnbanListener.class,
                                                             listener);
    }

    @Override
    default List<ServerMemberUnbanListener> getServerMemberUnbanListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerMemberUnbanListener.class);
    }

    @Override
    default ListenerManager<UserRoleRemoveListener> addUserRoleRemoveListener(UserRoleRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserRoleRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<UserRoleRemoveListener> getUserRoleRemoveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserRoleRemoveListener.class);
    }

    @Override
    default ListenerManager<UserRoleAddListener> addUserRoleAddListener(UserRoleAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserRoleAddListener.class,
                                                             listener);
    }

    @Override
    default List<UserRoleAddListener> getUserRoleAddListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserRoleAddListener.class);
    }

    @Override
    default ListenerManager<ServerChannelChangeOverwrittenPermissionsListener> addServerChannelChangeOverwrittenPermissionsListener(ServerChannelChangeOverwrittenPermissionsListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerChannelChangeOverwrittenPermissionsListener.class,
                                                             listener);
    }

    @Override
    default List<ServerChannelChangeOverwrittenPermissionsListener> getServerChannelChangeOverwrittenPermissionsListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerChannelChangeOverwrittenPermissionsListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelMemberLeaveListener> addServerVoiceChannelMemberLeaveListener(ServerVoiceChannelMemberLeaveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerVoiceChannelMemberLeaveListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelMemberLeaveListener> getServerVoiceChannelMemberLeaveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerVoiceChannelMemberLeaveListener.class);
    }

    @Override
    default ListenerManager<ServerVoiceChannelMemberJoinListener> addServerVoiceChannelMemberJoinListener(ServerVoiceChannelMemberJoinListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ServerVoiceChannelMemberJoinListener.class,
                                                             listener);
    }

    @Override
    default List<ServerVoiceChannelMemberJoinListener> getServerVoiceChannelMemberJoinListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ServerVoiceChannelMemberJoinListener.class);
    }

    @Override
    default ListenerManager<PrivateChannelDeleteListener> addPrivateChannelDeleteListener(PrivateChannelDeleteListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             PrivateChannelDeleteListener.class,
                                                             listener);
    }

    @Override
    default List<PrivateChannelDeleteListener> getPrivateChannelDeleteListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              PrivateChannelDeleteListener.class);
    }

    @Override
    default ListenerManager<PrivateChannelCreateListener> addPrivateChannelCreateListener(PrivateChannelCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             PrivateChannelCreateListener.class,
                                                             listener);
    }

    @Override
    default List<PrivateChannelCreateListener> getPrivateChannelCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              PrivateChannelCreateListener.class);
    }

    @Override
    default ListenerManager<UserChangeDeafenedListener> addUserChangeDeafenedListener(UserChangeDeafenedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeDeafenedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeDeafenedListener> getUserChangeDeafenedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeDeafenedListener.class);
    }

    @Override
    default ListenerManager<UserChangeNicknameListener> addUserChangeNicknameListener(UserChangeNicknameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeNicknameListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeNicknameListener> getUserChangeNicknameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeNicknameListener.class);
    }

    @Override
    default ListenerManager<UserChangePendingListener> addUserChangePendingListener(UserChangePendingListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangePendingListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangePendingListener> getUserChangePendingListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangePendingListener.class);
    }

    @Override
    default ListenerManager<UserStartTypingListener> addUserStartTypingListener(UserStartTypingListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserStartTypingListener.class,
                                                             listener);
    }

    @Override
    default List<UserStartTypingListener> getUserStartTypingListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserStartTypingListener.class);
    }

    @Override
    default ListenerManager<UserChangeDiscriminatorListener> addUserChangeDiscriminatorListener(UserChangeDiscriminatorListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeDiscriminatorListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeDiscriminatorListener> getUserChangeDiscriminatorListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeDiscriminatorListener.class);
    }

    @Override
    default ListenerManager<UserChangeStatusListener> addUserChangeStatusListener(UserChangeStatusListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeStatusListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeStatusListener> getUserChangeStatusListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeStatusListener.class);
    }

    @Override
    default ListenerManager<UserChangeServerAvatarListener> addUserChangeServerAvatarListener(UserChangeServerAvatarListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeServerAvatarListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeServerAvatarListener> getUserChangeServerAvatarListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeServerAvatarListener.class);
    }

    @Override
    default ListenerManager<UserChangeSelfMutedListener> addUserChangeSelfMutedListener(UserChangeSelfMutedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeSelfMutedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeSelfMutedListener> getUserChangeSelfMutedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeSelfMutedListener.class);
    }

    @Override
    default ListenerManager<UserChangeNameListener> addUserChangeNameListener(UserChangeNameListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeNameListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeNameListener> getUserChangeNameListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeNameListener.class);
    }

    @Override
    default ListenerManager<UserChangeTimeoutListener> addUserChangeTimeoutListener(UserChangeTimeoutListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeTimeoutListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeTimeoutListener> getUserChangeTimeoutListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeTimeoutListener.class);
    }

    @Override
    default ListenerManager<UserChangeAvatarListener> addUserChangeAvatarListener(UserChangeAvatarListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeAvatarListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeAvatarListener> getUserChangeAvatarListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeAvatarListener.class);
    }

    @Override
    default ListenerManager<UserChangeSelfDeafenedListener> addUserChangeSelfDeafenedListener(UserChangeSelfDeafenedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeSelfDeafenedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeSelfDeafenedListener> getUserChangeSelfDeafenedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeSelfDeafenedListener.class);
    }

    @Override
    default ListenerManager<UserChangeMutedListener> addUserChangeMutedListener(UserChangeMutedListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeMutedListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeMutedListener> getUserChangeMutedListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeMutedListener.class);
    }

    @Override
    default ListenerManager<UserChangeActivityListener> addUserChangeActivityListener(UserChangeActivityListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             UserChangeActivityListener.class,
                                                             listener);
    }

    @Override
    default List<UserChangeActivityListener> getUserChangeActivityListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              UserChangeActivityListener.class);
    }

    @Override
    default ListenerManager<ReactionRemoveListener> addReactionRemoveListener(ReactionRemoveListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ReactionRemoveListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionRemoveListener> getReactionRemoveListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ReactionRemoveListener.class);
    }

    @Override
    default ListenerManager<ReactionAddListener> addReactionAddListener(ReactionAddListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             ReactionAddListener.class,
                                                             listener);
    }

    @Override
    default List<ReactionAddListener> getReactionAddListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              ReactionAddListener.class);
    }

    @Override
    default ListenerManager<MessageCreateListener> addMessageCreateListener(MessageCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             MessageCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageCreateListener> getMessageCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              MessageCreateListener.class);
    }

    @Override
    default ListenerManager<MessageReplyListener> addMessageReplyListener(MessageReplyListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                             getId(),
                                                             MessageReplyListener.class,
                                                             listener);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId(),
                                                              MessageReplyListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends UserAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addUserAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(UserAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(User.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends UserAttachableListener & ObjectAttachableListener> void removeUserAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(UserAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(User.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends UserAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getUserAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(User.class,
                                                              getId());
    }

    @Override
    default <T extends UserAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(User.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
