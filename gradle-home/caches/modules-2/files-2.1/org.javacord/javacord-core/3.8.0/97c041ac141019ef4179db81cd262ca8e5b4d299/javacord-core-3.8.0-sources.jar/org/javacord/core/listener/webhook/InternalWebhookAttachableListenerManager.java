package org.javacord.core.listener.webhook;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import javax.annotation.Generated;
import org.javacord.api.DiscordApi;
import org.javacord.api.entity.webhook.Webhook;
import org.javacord.api.listener.ObjectAttachableListener;
import org.javacord.api.listener.message.MessageCreateListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.webhook.WebhookAttachableListener;
import org.javacord.api.listener.webhook.WebhookAttachableListenerManager;
import org.javacord.api.util.event.ListenerManager;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.ClassHelper;

/**
 * The implementation of {@code WebhookAttachableListenerManager}.
 */
@Generated("listener-manager-generation.gradle")
public interface InternalWebhookAttachableListenerManager extends WebhookAttachableListenerManager {

    /**
     * Gets the discord api instance.
     *
     * @return The discord api instance.
     */
    DiscordApi getApi();

    /**
     * Gets the id of this object.
     *
     * @return The id of this object.
     */
    long getId();

    @Override
    default ListenerManager<MessageCreateListener> addMessageCreateListener(MessageCreateListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Webhook.class,
                                                             getId(),
                                                             MessageCreateListener.class,
                                                             listener);
    }

    @Override
    default List<MessageCreateListener> getMessageCreateListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Webhook.class,
                                                              getId(),
                                                              MessageCreateListener.class);
    }

    @Override
    default ListenerManager<MessageReplyListener> addMessageReplyListener(MessageReplyListener listener) {
        return ((DiscordApiImpl) getApi()).addObjectListener(Webhook.class,
                                                             getId(),
                                                             MessageReplyListener.class,
                                                             listener);
    }

    @Override
    default List<MessageReplyListener> getMessageReplyListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Webhook.class,
                                                              getId(),
                                                              MessageReplyListener.class);
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends WebhookAttachableListener & ObjectAttachableListener> Collection<ListenerManager<T>> addWebhookAttachableListener(T listener) {
        return ClassHelper.getInterfacesAsStream(listener.getClass())
                          .filter(WebhookAttachableListener.class::isAssignableFrom)
                          .filter(ObjectAttachableListener.class::isAssignableFrom)
                          .map(listenerClass -> (Class<T>) listenerClass)
                          .map(listenerClass -> ((DiscordApiImpl) getApi()).addObjectListener(Webhook.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener))
                          .collect(Collectors.toList());
    }

    @Override
    @SuppressWarnings("unchecked")
    default <T extends WebhookAttachableListener & ObjectAttachableListener> void removeWebhookAttachableListener(T listener) {
        ClassHelper.getInterfacesAsStream(listener.getClass())
                   .filter(WebhookAttachableListener.class::isAssignableFrom)
                   .filter(ObjectAttachableListener.class::isAssignableFrom)
                   .map(listenerClass -> (Class<T>) listenerClass)
                   .forEach(listenerClass -> ((DiscordApiImpl) getApi()).removeObjectListener(Webhook.class,
                                                                                              getId(),
                                                                                              listenerClass,
                                                                                              listener));
    }

    @Override
    default <T extends WebhookAttachableListener & ObjectAttachableListener> Map<T, List<Class<T>>> getWebhookAttachableListeners() {
        return ((DiscordApiImpl) getApi()).getObjectListeners(Webhook.class,
                                                              getId());
    }

    @Override
    default <T extends WebhookAttachableListener & ObjectAttachableListener> void removeListener(Class<T> listenerClass, T listener) {
        ((DiscordApiImpl) getApi()).removeObjectListener(Webhook.class,
                                                         getId(),
                                                         listenerClass,
                                                         listener);
    }
}
