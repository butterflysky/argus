package org.javacord.core.util.event;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.annotation.Generated;
import org.javacord.api.audio.AudioConnection;
import org.javacord.api.audio.AudioSource;
import org.javacord.api.entity.channel.ChannelCategory;
import org.javacord.api.entity.channel.PrivateChannel;
import org.javacord.api.entity.channel.ServerChannel;
import org.javacord.api.entity.channel.ServerStageVoiceChannel;
import org.javacord.api.entity.channel.ServerTextChannel;
import org.javacord.api.entity.channel.ServerThreadChannel;
import org.javacord.api.entity.channel.ServerVoiceChannel;
import org.javacord.api.entity.channel.TextChannel;
import org.javacord.api.entity.emoji.KnownCustomEmoji;
import org.javacord.api.entity.message.Message;
import org.javacord.api.entity.permission.Role;
import org.javacord.api.entity.server.Server;
import org.javacord.api.entity.sticker.Sticker;
import org.javacord.api.entity.user.User;
import org.javacord.api.entity.webhook.Webhook;
import org.javacord.api.event.audio.AudioSourceFinishedEvent;
import org.javacord.api.event.channel.server.ServerChannelChangeNameEvent;
import org.javacord.api.event.channel.server.ServerChannelChangeNsfwFlagEvent;
import org.javacord.api.event.channel.server.ServerChannelChangeOverwrittenPermissionsEvent;
import org.javacord.api.event.channel.server.ServerChannelChangePositionEvent;
import org.javacord.api.event.channel.server.ServerChannelCreateEvent;
import org.javacord.api.event.channel.server.ServerChannelDeleteEvent;
import org.javacord.api.event.channel.server.invite.ServerChannelInviteCreateEvent;
import org.javacord.api.event.channel.server.invite.ServerChannelInviteDeleteEvent;
import org.javacord.api.event.channel.server.text.ServerTextChannelChangeDefaultAutoArchiveDurationEvent;
import org.javacord.api.event.channel.server.text.ServerTextChannelChangeSlowmodeEvent;
import org.javacord.api.event.channel.server.text.ServerTextChannelChangeTopicEvent;
import org.javacord.api.event.channel.server.text.WebhooksUpdateEvent;
import org.javacord.api.event.channel.server.thread.ServerPrivateThreadJoinEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeArchiveTimestampEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeArchivedEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeAutoArchiveDurationEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeInvitableEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeLastMessageIdEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeLockedEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeMemberCountEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeMessageCountEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeRateLimitPerUserEvent;
import org.javacord.api.event.channel.server.thread.ServerThreadChannelChangeTotalMessageSentEvent;
import org.javacord.api.event.channel.server.voice.ServerStageVoiceChannelChangeTopicEvent;
import org.javacord.api.event.channel.server.voice.ServerVoiceChannelChangeBitrateEvent;
import org.javacord.api.event.channel.server.voice.ServerVoiceChannelChangeNsfwEvent;
import org.javacord.api.event.channel.server.voice.ServerVoiceChannelChangeUserLimitEvent;
import org.javacord.api.event.channel.server.voice.ServerVoiceChannelMemberJoinEvent;
import org.javacord.api.event.channel.server.voice.ServerVoiceChannelMemberLeaveEvent;
import org.javacord.api.event.channel.thread.ThreadCreateEvent;
import org.javacord.api.event.channel.thread.ThreadDeleteEvent;
import org.javacord.api.event.channel.thread.ThreadListSyncEvent;
import org.javacord.api.event.channel.thread.ThreadMembersUpdateEvent;
import org.javacord.api.event.channel.thread.ThreadUpdateEvent;
import org.javacord.api.event.channel.user.PrivateChannelCreateEvent;
import org.javacord.api.event.channel.user.PrivateChannelDeleteEvent;
import org.javacord.api.event.connection.LostConnectionEvent;
import org.javacord.api.event.connection.ReconnectEvent;
import org.javacord.api.event.connection.ResumeEvent;
import org.javacord.api.event.interaction.AutocompleteCreateEvent;
import org.javacord.api.event.interaction.ButtonClickEvent;
import org.javacord.api.event.interaction.InteractionCreateEvent;
import org.javacord.api.event.interaction.MessageComponentCreateEvent;
import org.javacord.api.event.interaction.MessageContextMenuCommandEvent;
import org.javacord.api.event.interaction.ModalSubmitEvent;
import org.javacord.api.event.interaction.SelectMenuChooseEvent;
import org.javacord.api.event.interaction.SlashCommandCreateEvent;
import org.javacord.api.event.interaction.UserContextMenuCommandEvent;
import org.javacord.api.event.message.CachedMessagePinEvent;
import org.javacord.api.event.message.CachedMessageUnpinEvent;
import org.javacord.api.event.message.ChannelPinsUpdateEvent;
import org.javacord.api.event.message.MessageCreateEvent;
import org.javacord.api.event.message.MessageDeleteEvent;
import org.javacord.api.event.message.MessageEditEvent;
import org.javacord.api.event.message.MessageReplyEvent;
import org.javacord.api.event.message.reaction.ReactionAddEvent;
import org.javacord.api.event.message.reaction.ReactionRemoveAllEvent;
import org.javacord.api.event.message.reaction.ReactionRemoveEvent;
import org.javacord.api.event.server.ApplicationCommandPermissionsUpdateEvent;
import org.javacord.api.event.server.ServerBecomesAvailableEvent;
import org.javacord.api.event.server.ServerBecomesUnavailableEvent;
import org.javacord.api.event.server.ServerChangeAfkChannelEvent;
import org.javacord.api.event.server.ServerChangeAfkTimeoutEvent;
import org.javacord.api.event.server.ServerChangeBoostCountEvent;
import org.javacord.api.event.server.ServerChangeBoostLevelEvent;
import org.javacord.api.event.server.ServerChangeDefaultMessageNotificationLevelEvent;
import org.javacord.api.event.server.ServerChangeDescriptionEvent;
import org.javacord.api.event.server.ServerChangeDiscoverySplashEvent;
import org.javacord.api.event.server.ServerChangeExplicitContentFilterLevelEvent;
import org.javacord.api.event.server.ServerChangeIconEvent;
import org.javacord.api.event.server.ServerChangeModeratorsOnlyChannelEvent;
import org.javacord.api.event.server.ServerChangeMultiFactorAuthenticationLevelEvent;
import org.javacord.api.event.server.ServerChangeNameEvent;
import org.javacord.api.event.server.ServerChangeNsfwLevelEvent;
import org.javacord.api.event.server.ServerChangeOwnerEvent;
import org.javacord.api.event.server.ServerChangePreferredLocaleEvent;
import org.javacord.api.event.server.ServerChangeRegionEvent;
import org.javacord.api.event.server.ServerChangeRulesChannelEvent;
import org.javacord.api.event.server.ServerChangeServerFeaturesEvent;
import org.javacord.api.event.server.ServerChangeSplashEvent;
import org.javacord.api.event.server.ServerChangeSystemChannelEvent;
import org.javacord.api.event.server.ServerChangeVanityUrlCodeEvent;
import org.javacord.api.event.server.ServerChangeVerificationLevelEvent;
import org.javacord.api.event.server.ServerJoinEvent;
import org.javacord.api.event.server.ServerLeaveEvent;
import org.javacord.api.event.server.VoiceServerUpdateEvent;
import org.javacord.api.event.server.VoiceStateUpdateEvent;
import org.javacord.api.event.server.emoji.KnownCustomEmojiChangeNameEvent;
import org.javacord.api.event.server.emoji.KnownCustomEmojiChangeWhitelistedRolesEvent;
import org.javacord.api.event.server.emoji.KnownCustomEmojiCreateEvent;
import org.javacord.api.event.server.emoji.KnownCustomEmojiDeleteEvent;
import org.javacord.api.event.server.member.ServerMemberBanEvent;
import org.javacord.api.event.server.member.ServerMemberJoinEvent;
import org.javacord.api.event.server.member.ServerMemberLeaveEvent;
import org.javacord.api.event.server.member.ServerMemberUnbanEvent;
import org.javacord.api.event.server.member.ServerMembersChunkEvent;
import org.javacord.api.event.server.role.RoleChangeColorEvent;
import org.javacord.api.event.server.role.RoleChangeHoistEvent;
import org.javacord.api.event.server.role.RoleChangeMentionableEvent;
import org.javacord.api.event.server.role.RoleChangeNameEvent;
import org.javacord.api.event.server.role.RoleChangePermissionsEvent;
import org.javacord.api.event.server.role.RoleChangePositionEvent;
import org.javacord.api.event.server.role.RoleCreateEvent;
import org.javacord.api.event.server.role.RoleDeleteEvent;
import org.javacord.api.event.server.role.UserRoleAddEvent;
import org.javacord.api.event.server.role.UserRoleRemoveEvent;
import org.javacord.api.event.server.sticker.StickerChangeDescriptionEvent;
import org.javacord.api.event.server.sticker.StickerChangeNameEvent;
import org.javacord.api.event.server.sticker.StickerChangeTagsEvent;
import org.javacord.api.event.server.sticker.StickerCreateEvent;
import org.javacord.api.event.server.sticker.StickerDeleteEvent;
import org.javacord.api.event.user.UserChangeActivityEvent;
import org.javacord.api.event.user.UserChangeAvatarEvent;
import org.javacord.api.event.user.UserChangeDeafenedEvent;
import org.javacord.api.event.user.UserChangeDiscriminatorEvent;
import org.javacord.api.event.user.UserChangeMutedEvent;
import org.javacord.api.event.user.UserChangeNameEvent;
import org.javacord.api.event.user.UserChangeNicknameEvent;
import org.javacord.api.event.user.UserChangePendingEvent;
import org.javacord.api.event.user.UserChangeSelfDeafenedEvent;
import org.javacord.api.event.user.UserChangeSelfMutedEvent;
import org.javacord.api.event.user.UserChangeServerAvatarEvent;
import org.javacord.api.event.user.UserChangeStatusEvent;
import org.javacord.api.event.user.UserChangeTimeoutEvent;
import org.javacord.api.event.user.UserStartTypingEvent;
import org.javacord.api.listener.audio.AudioSourceFinishedListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeNameListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeNsfwFlagListener;
import org.javacord.api.listener.channel.server.ServerChannelChangeOverwrittenPermissionsListener;
import org.javacord.api.listener.channel.server.ServerChannelChangePositionListener;
import org.javacord.api.listener.channel.server.ServerChannelCreateListener;
import org.javacord.api.listener.channel.server.ServerChannelDeleteListener;
import org.javacord.api.listener.channel.server.invite.ServerChannelInviteCreateListener;
import org.javacord.api.listener.channel.server.invite.ServerChannelInviteDeleteListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeDefaultAutoArchiveDurationListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeSlowmodeListener;
import org.javacord.api.listener.channel.server.text.ServerTextChannelChangeTopicListener;
import org.javacord.api.listener.channel.server.text.WebhooksUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelCreateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelDeleteListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelMembersUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadChannelUpdateListener;
import org.javacord.api.listener.channel.server.thread.ServerThreadListSyncListener;
import org.javacord.api.listener.channel.server.voice.ServerStageVoiceChannelChangeTopicListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeBitrateListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeNsfwListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelChangeUserLimitListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberJoinListener;
import org.javacord.api.listener.channel.server.voice.ServerVoiceChannelMemberLeaveListener;
import org.javacord.api.listener.channel.user.PrivateChannelCreateListener;
import org.javacord.api.listener.channel.user.PrivateChannelDeleteListener;
import org.javacord.api.listener.connection.LostConnectionListener;
import org.javacord.api.listener.connection.ReconnectListener;
import org.javacord.api.listener.connection.ResumeListener;
import org.javacord.api.listener.interaction.AutocompleteCreateListener;
import org.javacord.api.listener.interaction.ButtonClickListener;
import org.javacord.api.listener.interaction.InteractionCreateListener;
import org.javacord.api.listener.interaction.MessageComponentCreateListener;
import org.javacord.api.listener.interaction.MessageContextMenuCommandListener;
import org.javacord.api.listener.interaction.ModalSubmitListener;
import org.javacord.api.listener.interaction.SelectMenuChooseListener;
import org.javacord.api.listener.interaction.SlashCommandCreateListener;
import org.javacord.api.listener.interaction.UserContextMenuCommandListener;
import org.javacord.api.listener.message.CachedMessagePinListener;
import org.javacord.api.listener.message.CachedMessageUnpinListener;
import org.javacord.api.listener.message.ChannelPinsUpdateListener;
import org.javacord.api.listener.message.MessageAttachableListenerManager;
import org.javacord.api.listener.message.MessageCreateListener;
import org.javacord.api.listener.message.MessageDeleteListener;
import org.javacord.api.listener.message.MessageEditListener;
import org.javacord.api.listener.message.MessageReplyListener;
import org.javacord.api.listener.message.reaction.ReactionAddListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveAllListener;
import org.javacord.api.listener.message.reaction.ReactionRemoveListener;
import org.javacord.api.listener.server.ApplicationCommandPermissionsUpdateListener;
import org.javacord.api.listener.server.ServerBecomesAvailableListener;
import org.javacord.api.listener.server.ServerBecomesUnavailableListener;
import org.javacord.api.listener.server.ServerChangeAfkChannelListener;
import org.javacord.api.listener.server.ServerChangeAfkTimeoutListener;
import org.javacord.api.listener.server.ServerChangeBoostCountListener;
import org.javacord.api.listener.server.ServerChangeBoostLevelListener;
import org.javacord.api.listener.server.ServerChangeDefaultMessageNotificationLevelListener;
import org.javacord.api.listener.server.ServerChangeDescriptionListener;
import org.javacord.api.listener.server.ServerChangeDiscoverySplashListener;
import org.javacord.api.listener.server.ServerChangeExplicitContentFilterLevelListener;
import org.javacord.api.listener.server.ServerChangeIconListener;
import org.javacord.api.listener.server.ServerChangeModeratorsOnlyChannelListener;
import org.javacord.api.listener.server.ServerChangeMultiFactorAuthenticationLevelListener;
import org.javacord.api.listener.server.ServerChangeNameListener;
import org.javacord.api.listener.server.ServerChangeNsfwLevelListener;
import org.javacord.api.listener.server.ServerChangeOwnerListener;
import org.javacord.api.listener.server.ServerChangePreferredLocaleListener;
import org.javacord.api.listener.server.ServerChangeRegionListener;
import org.javacord.api.listener.server.ServerChangeRulesChannelListener;
import org.javacord.api.listener.server.ServerChangeServerFeatureListener;
import org.javacord.api.listener.server.ServerChangeSplashListener;
import org.javacord.api.listener.server.ServerChangeSystemChannelListener;
import org.javacord.api.listener.server.ServerChangeVanityUrlCodeListener;
import org.javacord.api.listener.server.ServerChangeVerificationLevelListener;
import org.javacord.api.listener.server.ServerJoinListener;
import org.javacord.api.listener.server.ServerLeaveListener;
import org.javacord.api.listener.server.VoiceServerUpdateListener;
import org.javacord.api.listener.server.VoiceStateUpdateListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiChangeNameListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiChangeWhitelistedRolesListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiCreateListener;
import org.javacord.api.listener.server.emoji.KnownCustomEmojiDeleteListener;
import org.javacord.api.listener.server.member.ServerMemberBanListener;
import org.javacord.api.listener.server.member.ServerMemberJoinListener;
import org.javacord.api.listener.server.member.ServerMemberLeaveListener;
import org.javacord.api.listener.server.member.ServerMemberUnbanListener;
import org.javacord.api.listener.server.member.ServerMembersChunkListener;
import org.javacord.api.listener.server.role.RoleChangeColorListener;
import org.javacord.api.listener.server.role.RoleChangeHoistListener;
import org.javacord.api.listener.server.role.RoleChangeMentionableListener;
import org.javacord.api.listener.server.role.RoleChangeNameListener;
import org.javacord.api.listener.server.role.RoleChangePermissionsListener;
import org.javacord.api.listener.server.role.RoleChangePositionListener;
import org.javacord.api.listener.server.role.RoleCreateListener;
import org.javacord.api.listener.server.role.RoleDeleteListener;
import org.javacord.api.listener.server.role.UserRoleAddListener;
import org.javacord.api.listener.server.role.UserRoleRemoveListener;
import org.javacord.api.listener.server.sticker.StickerChangeDescriptionListener;
import org.javacord.api.listener.server.sticker.StickerChangeNameListener;
import org.javacord.api.listener.server.sticker.StickerChangeTagsListener;
import org.javacord.api.listener.server.sticker.StickerCreateListener;
import org.javacord.api.listener.server.sticker.StickerDeleteListener;
import org.javacord.api.listener.server.thread.ServerPrivateThreadJoinListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeArchiveTimestampListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeArchivedListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeAutoArchiveDurationListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeInvitableListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeLastMessageIdListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeLockedListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeMemberCountListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeMessageCountListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeRateLimitPerUserListener;
import org.javacord.api.listener.server.thread.ServerThreadChannelChangeTotalMessageSentListener;
import org.javacord.api.listener.user.UserChangeActivityListener;
import org.javacord.api.listener.user.UserChangeAvatarListener;
import org.javacord.api.listener.user.UserChangeDeafenedListener;
import org.javacord.api.listener.user.UserChangeDiscriminatorListener;
import org.javacord.api.listener.user.UserChangeMutedListener;
import org.javacord.api.listener.user.UserChangeNameListener;
import org.javacord.api.listener.user.UserChangeNicknameListener;
import org.javacord.api.listener.user.UserChangePendingListener;
import org.javacord.api.listener.user.UserChangeSelfDeafenedListener;
import org.javacord.api.listener.user.UserChangeSelfMutedListener;
import org.javacord.api.listener.user.UserChangeServerAvatarListener;
import org.javacord.api.listener.user.UserChangeStatusListener;
import org.javacord.api.listener.user.UserChangeTimeoutListener;
import org.javacord.api.listener.user.UserStartTypingListener;
import org.javacord.core.DiscordApiImpl;
import org.javacord.core.util.event.EventDispatcherBase;

/**
 * This class is used to dispatch events.
 */
@Generated("event-dispatcher-generation.gradle")
public class EventDispatcher extends EventDispatcherBase {

    /**
     * Creates a new event dispatcher.
     *
     * @param api The discord api instance.
     */
    public EventDispatcher(DiscordApiImpl api) {
        super(api);
    }

    /**
     * Dispatch an event to {@code InteractionCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchInteractionCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, InteractionCreateEvent event) {
        List<InteractionCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getInteractionCreateListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getInteractionCreateListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getInteractionCreateListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getInteractionCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onInteractionCreate(event));
    }

    /**
     * Dispatch an event to {@code InteractionCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchInteractionCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, InteractionCreateEvent event) {
        List<InteractionCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getInteractionCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getInteractionCreateListeners());
        }
        if (user != null) {
            listeners.addAll(user.getInteractionCreateListeners());
        }
        listeners.addAll(getApi().getInteractionCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onInteractionCreate(event));
    }

    /**
     * Dispatch an event to {@code InteractionCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchInteractionCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, InteractionCreateEvent event) {
        List<InteractionCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getInteractionCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getInteractionCreateListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     InteractionCreateListener.class));
        listeners.addAll(getApi().getInteractionCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onInteractionCreate(event));
    }

    /**
     * Dispatch an event to {@code SlashCommandCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchSlashCommandCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, SlashCommandCreateEvent event) {
        List<SlashCommandCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getSlashCommandCreateListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getSlashCommandCreateListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getSlashCommandCreateListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getSlashCommandCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onSlashCommandCreate(event));
    }

    /**
     * Dispatch an event to {@code SlashCommandCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchSlashCommandCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, SlashCommandCreateEvent event) {
        List<SlashCommandCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getSlashCommandCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getSlashCommandCreateListeners());
        }
        if (user != null) {
            listeners.addAll(user.getSlashCommandCreateListeners());
        }
        listeners.addAll(getApi().getSlashCommandCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onSlashCommandCreate(event));
    }

    /**
     * Dispatch an event to {@code SlashCommandCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchSlashCommandCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, SlashCommandCreateEvent event) {
        List<SlashCommandCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getSlashCommandCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getSlashCommandCreateListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     SlashCommandCreateListener.class));
        listeners.addAll(getApi().getSlashCommandCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onSlashCommandCreate(event));
    }

    /**
     * Dispatch an event to {@code AutocompleteCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchAutocompleteCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, AutocompleteCreateEvent event) {
        List<AutocompleteCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getAutocompleteCreateListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getAutocompleteCreateListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getAutocompleteCreateListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getAutocompleteCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onAutocompleteCreate(event));
    }

    /**
     * Dispatch an event to {@code AutocompleteCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchAutocompleteCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, AutocompleteCreateEvent event) {
        List<AutocompleteCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getAutocompleteCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getAutocompleteCreateListeners());
        }
        if (user != null) {
            listeners.addAll(user.getAutocompleteCreateListeners());
        }
        listeners.addAll(getApi().getAutocompleteCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onAutocompleteCreate(event));
    }

    /**
     * Dispatch an event to {@code AutocompleteCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchAutocompleteCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, AutocompleteCreateEvent event) {
        List<AutocompleteCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getAutocompleteCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getAutocompleteCreateListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     AutocompleteCreateListener.class));
        listeners.addAll(getApi().getAutocompleteCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onAutocompleteCreate(event));
    }

    /**
     * Dispatch an event to {@code ModalSubmitListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchModalSubmitEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, ModalSubmitEvent event) {
        List<ModalSubmitListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getModalSubmitListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getModalSubmitListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getModalSubmitListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getModalSubmitListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onModalSubmit(event));
    }

    /**
     * Dispatch an event to {@code ModalSubmitListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchModalSubmitEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, ModalSubmitEvent event) {
        List<ModalSubmitListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getModalSubmitListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getModalSubmitListeners());
        }
        if (user != null) {
            listeners.addAll(user.getModalSubmitListeners());
        }
        listeners.addAll(getApi().getModalSubmitListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onModalSubmit(event));
    }

    /**
     * Dispatch an event to {@code ModalSubmitListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchModalSubmitEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, ModalSubmitEvent event) {
        List<ModalSubmitListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getModalSubmitListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getModalSubmitListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ModalSubmitListener.class));
        listeners.addAll(getApi().getModalSubmitListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onModalSubmit(event));
    }

    /**
     * Dispatch an event to {@code MessageContextMenuCommandListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchMessageContextMenuCommandEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, MessageContextMenuCommandEvent event) {
        List<MessageContextMenuCommandListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getMessageContextMenuCommandListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getMessageContextMenuCommandListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getMessageContextMenuCommandListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getMessageContextMenuCommandListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getMessageContextMenuCommandListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageContextMenuCommand(event));
    }

    /**
     * Dispatch an event to {@code MessageContextMenuCommandListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchMessageContextMenuCommandEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, MessageContextMenuCommandEvent event) {
        List<MessageContextMenuCommandListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageContextMenuCommandListeners(getApi(),
                                                                                                messageId));
        if (server != null) {
            listeners.addAll(server.getMessageContextMenuCommandListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageContextMenuCommandListeners());
        }
        if (user != null) {
            listeners.addAll(user.getMessageContextMenuCommandListeners());
        }
        listeners.addAll(getApi().getMessageContextMenuCommandListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageContextMenuCommand(event));
    }

    /**
     * Dispatch an event to {@code MessageContextMenuCommandListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchMessageContextMenuCommandEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, MessageContextMenuCommandEvent event) {
        List<MessageContextMenuCommandListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageContextMenuCommandListeners(getApi(),
                                                                                                messageId));
        if (server != null) {
            listeners.addAll(server.getMessageContextMenuCommandListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageContextMenuCommandListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     MessageContextMenuCommandListener.class));
        listeners.addAll(getApi().getMessageContextMenuCommandListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageContextMenuCommand(event));
    }

    /**
     * Dispatch an event to {@code MessageComponentCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchMessageComponentCreateEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, MessageComponentCreateEvent event) {
        List<MessageComponentCreateListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getMessageComponentCreateListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getMessageComponentCreateListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getMessageComponentCreateListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getMessageComponentCreateListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getMessageComponentCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onComponentCreate(event));
    }

    /**
     * Dispatch an event to {@code MessageComponentCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchMessageComponentCreateEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, MessageComponentCreateEvent event) {
        List<MessageComponentCreateListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageComponentCreateListeners(getApi(),
                                                                                             messageId));
        if (server != null) {
            listeners.addAll(server.getMessageComponentCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageComponentCreateListeners());
        }
        if (user != null) {
            listeners.addAll(user.getMessageComponentCreateListeners());
        }
        listeners.addAll(getApi().getMessageComponentCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onComponentCreate(event));
    }

    /**
     * Dispatch an event to {@code MessageComponentCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchMessageComponentCreateEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, MessageComponentCreateEvent event) {
        List<MessageComponentCreateListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageComponentCreateListeners(getApi(),
                                                                                             messageId));
        if (server != null) {
            listeners.addAll(server.getMessageComponentCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageComponentCreateListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     MessageComponentCreateListener.class));
        listeners.addAll(getApi().getMessageComponentCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onComponentCreate(event));
    }

    /**
     * Dispatch an event to {@code UserContextMenuCommandListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserContextMenuCommandEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, UserContextMenuCommandEvent event) {
        List<UserContextMenuCommandListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserContextMenuCommandListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getUserContextMenuCommandListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserContextMenuCommandListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserContextMenuCommandListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserContextMenuCommand(event));
    }

    /**
     * Dispatch an event to {@code UserContextMenuCommandListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserContextMenuCommandEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, UserContextMenuCommandEvent event) {
        List<UserContextMenuCommandListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserContextMenuCommandListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getUserContextMenuCommandListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserContextMenuCommandListeners());
        }
        listeners.addAll(getApi().getUserContextMenuCommandListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserContextMenuCommand(event));
    }

    /**
     * Dispatch an event to {@code UserContextMenuCommandListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserContextMenuCommandEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, UserContextMenuCommandEvent event) {
        List<UserContextMenuCommandListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserContextMenuCommandListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getUserContextMenuCommandListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserContextMenuCommandListener.class));
        listeners.addAll(getApi().getUserContextMenuCommandListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserContextMenuCommand(event));
    }

    /**
     * Dispatch an event to {@code SelectMenuChooseListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchSelectMenuChooseEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, SelectMenuChooseEvent event) {
        List<SelectMenuChooseListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getSelectMenuChooseListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getSelectMenuChooseListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getSelectMenuChooseListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getSelectMenuChooseListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getSelectMenuChooseListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onSelectMenuChoose(event));
    }

    /**
     * Dispatch an event to {@code SelectMenuChooseListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchSelectMenuChooseEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, SelectMenuChooseEvent event) {
        List<SelectMenuChooseListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getSelectMenuChooseListeners(getApi(),
                                                                                       messageId));
        if (server != null) {
            listeners.addAll(server.getSelectMenuChooseListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getSelectMenuChooseListeners());
        }
        if (user != null) {
            listeners.addAll(user.getSelectMenuChooseListeners());
        }
        listeners.addAll(getApi().getSelectMenuChooseListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onSelectMenuChoose(event));
    }

    /**
     * Dispatch an event to {@code SelectMenuChooseListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchSelectMenuChooseEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, SelectMenuChooseEvent event) {
        List<SelectMenuChooseListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getSelectMenuChooseListeners(getApi(),
                                                                                       messageId));
        if (server != null) {
            listeners.addAll(server.getSelectMenuChooseListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getSelectMenuChooseListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     SelectMenuChooseListener.class));
        listeners.addAll(getApi().getSelectMenuChooseListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onSelectMenuChoose(event));
    }

    /**
     * Dispatch an event to {@code ButtonClickListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchButtonClickEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, ButtonClickEvent event) {
        List<ButtonClickListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getButtonClickListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getButtonClickListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getButtonClickListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getButtonClickListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getButtonClickListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onButtonClick(event));
    }

    /**
     * Dispatch an event to {@code ButtonClickListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchButtonClickEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, ButtonClickEvent event) {
        List<ButtonClickListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getButtonClickListeners(getApi(),
                                                                                  messageId));
        if (server != null) {
            listeners.addAll(server.getButtonClickListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getButtonClickListeners());
        }
        if (user != null) {
            listeners.addAll(user.getButtonClickListeners());
        }
        listeners.addAll(getApi().getButtonClickListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onButtonClick(event));
    }

    /**
     * Dispatch an event to {@code ButtonClickListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchButtonClickEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, ButtonClickEvent event) {
        List<ButtonClickListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getButtonClickListeners(getApi(),
                                                                                  messageId));
        if (server != null) {
            listeners.addAll(server.getButtonClickListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getButtonClickListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ButtonClickListener.class));
        listeners.addAll(getApi().getButtonClickListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onButtonClick(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeIconListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeIconEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeIconEvent event) {
        List<ServerChangeIconListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeIconListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeIconListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeIcon(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeIconListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeIconEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeIconEvent event) {
        List<ServerChangeIconListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeIconListeners());
        }
        listeners.addAll(getApi().getServerChangeIconListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeIcon(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeNameEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeNameEvent event) {
        List<ServerChangeNameListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeNameListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeName(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeNameEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeNameEvent event) {
        List<ServerChangeNameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeNameListeners());
        }
        listeners.addAll(getApi().getServerChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeName(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeLastMessageIdListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeLastMessageIdEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeLastMessageIdEvent event) {
        List<ServerThreadChannelChangeLastMessageIdListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeLastMessageIdListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeLastMessageIdListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeLastMessageIdListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeLastMessageId(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeLastMessageIdListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeLastMessageIdEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeLastMessageIdEvent event) {
        List<ServerThreadChannelChangeLastMessageIdListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeLastMessageIdListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeLastMessageIdListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeLastMessageIdListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeLastMessageId(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeArchivedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeArchivedEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeArchivedEvent event) {
        List<ServerThreadChannelChangeArchivedListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeArchivedListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeArchivedListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeArchivedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeArchived(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeArchivedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeArchivedEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeArchivedEvent event) {
        List<ServerThreadChannelChangeArchivedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeArchivedListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeArchivedListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeArchivedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeArchived(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeMemberCountListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeMemberCountEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeMemberCountEvent event) {
        List<ServerThreadChannelChangeMemberCountListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeMemberCountListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeMemberCountListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeMemberCountListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeMemberCount(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeMemberCountListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeMemberCountEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeMemberCountEvent event) {
        List<ServerThreadChannelChangeMemberCountListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeMemberCountListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeMemberCountListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeMemberCountListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeMemberCount(event));
    }

    /**
     * Dispatch an event to {@code ServerPrivateThreadJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerPrivateThreadJoinEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerPrivateThreadJoinEvent event) {
        List<ServerPrivateThreadJoinListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerPrivateThreadJoinListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerPrivateThreadJoinListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerPrivateThreadJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerPrivateThreadJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerPrivateThreadJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerPrivateThreadJoinEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerPrivateThreadJoinEvent event) {
        List<ServerPrivateThreadJoinListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerPrivateThreadJoinListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerPrivateThreadJoinListeners());
        }
        listeners.addAll(getApi().getServerPrivateThreadJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerPrivateThreadJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeInvitableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeInvitableEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeInvitableEvent event) {
        List<ServerThreadChannelChangeInvitableListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeInvitableListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeInvitableListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeInvitableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeInvitable(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeInvitableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeInvitableEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeInvitableEvent event) {
        List<ServerThreadChannelChangeInvitableListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeInvitableListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeInvitableListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeInvitableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeInvitable(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeAutoArchiveDurationListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeAutoArchiveDurationEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeAutoArchiveDurationEvent event) {
        List<ServerThreadChannelChangeAutoArchiveDurationListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeAutoArchiveDurationListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeAutoArchiveDurationListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeAutoArchiveDurationListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeAutoArchiveDuration(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeAutoArchiveDurationListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeAutoArchiveDurationEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeAutoArchiveDurationEvent event) {
        List<ServerThreadChannelChangeAutoArchiveDurationListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeAutoArchiveDurationListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeAutoArchiveDurationListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeAutoArchiveDurationListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeAutoArchiveDuration(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeRateLimitPerUserListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeRateLimitPerUserEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeRateLimitPerUserEvent event) {
        List<ServerThreadChannelChangeRateLimitPerUserListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeRateLimitPerUserListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeRateLimitPerUserListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeRateLimitPerUserListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeRateLimitPerUser(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeRateLimitPerUserListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeRateLimitPerUserEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeRateLimitPerUserEvent event) {
        List<ServerThreadChannelChangeRateLimitPerUserListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeRateLimitPerUserListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeRateLimitPerUserListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeRateLimitPerUserListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeRateLimitPerUser(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeLockedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeLockedEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeLockedEvent event) {
        List<ServerThreadChannelChangeLockedListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeLockedListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeLockedListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeLockedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeLocked(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeLockedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeLockedEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeLockedEvent event) {
        List<ServerThreadChannelChangeLockedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeLockedListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeLockedListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeLockedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeLocked(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeArchiveTimestampListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeArchiveTimestampEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeArchiveTimestampEvent event) {
        List<ServerThreadChannelChangeArchiveTimestampListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeArchiveTimestampListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeArchiveTimestampListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeArchiveTimestampListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeArchiveTimestamp(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeArchiveTimestampListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeArchiveTimestampEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeArchiveTimestampEvent event) {
        List<ServerThreadChannelChangeArchiveTimestampListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeArchiveTimestampListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeArchiveTimestampListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeArchiveTimestampListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeArchiveTimestamp(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeTotalMessageSentListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeTotalMessageSentEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeTotalMessageSentEvent event) {
        List<ServerThreadChannelChangeTotalMessageSentListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeTotalMessageSentListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeTotalMessageSentListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeTotalMessageSentListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeTotalMessageSent(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeTotalMessageSentListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeTotalMessageSentEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeTotalMessageSentEvent event) {
        List<ServerThreadChannelChangeTotalMessageSentListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeTotalMessageSentListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeTotalMessageSentListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeTotalMessageSentListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeTotalMessageSent(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeMessageCountListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeMessageCountEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ServerThreadChannelChangeMessageCountEvent event) {
        List<ServerThreadChannelChangeMessageCountListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelChangeMessageCountListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelChangeMessageCountListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelChangeMessageCountListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeMessageCount(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelChangeMessageCountListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchServerThreadChannelChangeMessageCountEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ServerThreadChannelChangeMessageCountEvent event) {
        List<ServerThreadChannelChangeMessageCountListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelChangeMessageCountListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelChangeMessageCountListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelChangeMessageCountListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerThreadChannelChangeMessageCount(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeAfkTimeoutListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeAfkTimeoutEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeAfkTimeoutEvent event) {
        List<ServerChangeAfkTimeoutListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeAfkTimeoutListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeAfkTimeoutListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeAfkTimeout(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeAfkTimeoutListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeAfkTimeoutEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeAfkTimeoutEvent event) {
        List<ServerChangeAfkTimeoutListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeAfkTimeoutListeners());
        }
        listeners.addAll(getApi().getServerChangeAfkTimeoutListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeAfkTimeout(event));
    }

    /**
     * Dispatch an event to {@code StickerChangeTagsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param stickers The {@code Sticker}s.
     * @param event The event.
     */
    public void dispatchStickerChangeTagsEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<Sticker> stickers, StickerChangeTagsEvent event) {
        List<StickerChangeTagsListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getStickerChangeTagsListeners)
                   .forEach(listeners::addAll);
        }
        if (stickers != null) {
            stickers.stream()
                    .map(Sticker::getStickerChangeTagsListeners)
                    .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getStickerChangeTagsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerChangeTags(event));
    }

    /**
     * Dispatch an event to {@code StickerChangeTagsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param sticker The {@code Sticker}.
     * @param event The event.
     */
    public void dispatchStickerChangeTagsEvent(DispatchQueueSelector queueSelector, Server server, Sticker sticker, StickerChangeTagsEvent event) {
        List<StickerChangeTagsListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getStickerChangeTagsListeners());
        }
        if (sticker != null) {
            listeners.addAll(sticker.getStickerChangeTagsListeners());
        }
        listeners.addAll(getApi().getStickerChangeTagsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerChangeTags(event));
    }

    /**
     * Dispatch an event to {@code StickerChangeDescriptionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param stickers The {@code Sticker}s.
     * @param event The event.
     */
    public void dispatchStickerChangeDescriptionEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<Sticker> stickers, StickerChangeDescriptionEvent event) {
        List<StickerChangeDescriptionListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getStickerChangeDescriptionListeners)
                   .forEach(listeners::addAll);
        }
        if (stickers != null) {
            stickers.stream()
                    .map(Sticker::getStickerChangeDescriptionListeners)
                    .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getStickerChangeDescriptionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerChangeDescription(event));
    }

    /**
     * Dispatch an event to {@code StickerChangeDescriptionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param sticker The {@code Sticker}.
     * @param event The event.
     */
    public void dispatchStickerChangeDescriptionEvent(DispatchQueueSelector queueSelector, Server server, Sticker sticker, StickerChangeDescriptionEvent event) {
        List<StickerChangeDescriptionListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getStickerChangeDescriptionListeners());
        }
        if (sticker != null) {
            listeners.addAll(sticker.getStickerChangeDescriptionListeners());
        }
        listeners.addAll(getApi().getStickerChangeDescriptionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerChangeDescription(event));
    }

    /**
     * Dispatch an event to {@code StickerCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchStickerCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, StickerCreateEvent event) {
        List<StickerCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getStickerCreateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getStickerCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerCreate(event));
    }

    /**
     * Dispatch an event to {@code StickerCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchStickerCreateEvent(DispatchQueueSelector queueSelector, Server server, StickerCreateEvent event) {
        List<StickerCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getStickerCreateListeners());
        }
        listeners.addAll(getApi().getStickerCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerCreate(event));
    }

    /**
     * Dispatch an event to {@code StickerChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param stickers The {@code Sticker}s.
     * @param event The event.
     */
    public void dispatchStickerChangeNameEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<Sticker> stickers, StickerChangeNameEvent event) {
        List<StickerChangeNameListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getStickerChangeNameListeners)
                   .forEach(listeners::addAll);
        }
        if (stickers != null) {
            stickers.stream()
                    .map(Sticker::getStickerChangeNameListeners)
                    .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getStickerChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerChangeName(event));
    }

    /**
     * Dispatch an event to {@code StickerChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param sticker The {@code Sticker}.
     * @param event The event.
     */
    public void dispatchStickerChangeNameEvent(DispatchQueueSelector queueSelector, Server server, Sticker sticker, StickerChangeNameEvent event) {
        List<StickerChangeNameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getStickerChangeNameListeners());
        }
        if (sticker != null) {
            listeners.addAll(sticker.getStickerChangeNameListeners());
        }
        listeners.addAll(getApi().getStickerChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerChangeName(event));
    }

    /**
     * Dispatch an event to {@code StickerDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param stickers The {@code Sticker}s.
     * @param event The event.
     */
    public void dispatchStickerDeleteEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<Sticker> stickers, StickerDeleteEvent event) {
        List<StickerDeleteListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getStickerDeleteListeners)
                   .forEach(listeners::addAll);
        }
        if (stickers != null) {
            stickers.stream()
                    .map(Sticker::getStickerDeleteListeners)
                    .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getStickerDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerDelete(event));
    }

    /**
     * Dispatch an event to {@code StickerDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param sticker The {@code Sticker}.
     * @param event The event.
     */
    public void dispatchStickerDeleteEvent(DispatchQueueSelector queueSelector, Server server, Sticker sticker, StickerDeleteEvent event) {
        List<StickerDeleteListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getStickerDeleteListeners());
        }
        if (sticker != null) {
            listeners.addAll(sticker.getStickerDeleteListeners());
        }
        listeners.addAll(getApi().getStickerDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onStickerDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeSplashListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeSplashEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeSplashEvent event) {
        List<ServerChangeSplashListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeSplashListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeSplashListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeSplash(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeSplashListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeSplashEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeSplashEvent event) {
        List<ServerChangeSplashListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeSplashListeners());
        }
        listeners.addAll(getApi().getServerChangeSplashListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeSplash(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeAfkChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeAfkChannelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeAfkChannelEvent event) {
        List<ServerChangeAfkChannelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeAfkChannelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeAfkChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeAfkChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeAfkChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeAfkChannelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeAfkChannelEvent event) {
        List<ServerChangeAfkChannelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeAfkChannelListeners());
        }
        listeners.addAll(getApi().getServerChangeAfkChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeAfkChannel(event));
    }

    /**
     * Dispatch an event to {@code VoiceStateUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param serverChannels The {@code ServerChannel}s.
     * @param event The event.
     */
    public void dispatchVoiceStateUpdateEvent(DispatchQueueSelector queueSelector, Collection<ServerChannel> serverChannels, VoiceStateUpdateEvent event) {
        List<VoiceStateUpdateListener> listeners = new ArrayList<>();
        if (serverChannels != null) {
            serverChannels.stream()
                          .map(ServerChannel::getVoiceStateUpdateListeners)
                          .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getVoiceStateUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onVoiceStateUpdate(event));
    }

    /**
     * Dispatch an event to {@code VoiceStateUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param serverChannel The {@code ServerChannel}.
     * @param event The event.
     */
    public void dispatchVoiceStateUpdateEvent(DispatchQueueSelector queueSelector, ServerChannel serverChannel, VoiceStateUpdateEvent event) {
        List<VoiceStateUpdateListener> listeners = new ArrayList<>();
        if (serverChannel != null) {
            listeners.addAll(serverChannel.getVoiceStateUpdateListeners());
        }
        listeners.addAll(getApi().getVoiceStateUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onVoiceStateUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeVanityUrlCodeListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeVanityUrlCodeEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeVanityUrlCodeEvent event) {
        List<ServerChangeVanityUrlCodeListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeVanityUrlCodeListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeVanityUrlCodeListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeVanityUrlCode(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeVanityUrlCodeListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeVanityUrlCodeEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeVanityUrlCodeEvent event) {
        List<ServerChangeVanityUrlCodeListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeVanityUrlCodeListeners());
        }
        listeners.addAll(getApi().getServerChangeVanityUrlCodeListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeVanityUrlCode(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeDiscoverySplashListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeDiscoverySplashEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeDiscoverySplashEvent event) {
        List<ServerChangeDiscoverySplashListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeDiscoverySplashListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeDiscoverySplashListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeDiscoverySplash(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeDiscoverySplashListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeDiscoverySplashEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeDiscoverySplashEvent event) {
        List<ServerChangeDiscoverySplashListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeDiscoverySplashListeners());
        }
        listeners.addAll(getApi().getServerChangeDiscoverySplashListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeDiscoverySplash(event));
    }

    /**
     * Dispatch an event to {@code ServerJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param event The event.
     */
    public void dispatchServerJoinEvent(DispatchQueueSelector queueSelector, ServerJoinEvent event) {
        List<ServerJoinListener> listeners = new ArrayList<>();
        listeners.addAll(getApi().getServerJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerJoin(event));
    }

    /**
     * Dispatch an event to {@code ApplicationCommandPermissionsUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchApplicationCommandPermissionsUpdateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ApplicationCommandPermissionsUpdateEvent event) {
        List<ApplicationCommandPermissionsUpdateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getApplicationCommandPermissionsUpdateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getApplicationCommandPermissionsUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onApplicationCommandPermissionsUpdate(event));
    }

    /**
     * Dispatch an event to {@code ApplicationCommandPermissionsUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchApplicationCommandPermissionsUpdateEvent(DispatchQueueSelector queueSelector, Server server, ApplicationCommandPermissionsUpdateEvent event) {
        List<ApplicationCommandPermissionsUpdateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getApplicationCommandPermissionsUpdateListeners());
        }
        listeners.addAll(getApi().getApplicationCommandPermissionsUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onApplicationCommandPermissionsUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerBecomesUnavailableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerBecomesUnavailableEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerBecomesUnavailableEvent event) {
        List<ServerBecomesUnavailableListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerBecomesUnavailableListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerBecomesUnavailableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerBecomesUnavailable(event));
    }

    /**
     * Dispatch an event to {@code ServerBecomesUnavailableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerBecomesUnavailableEvent(DispatchQueueSelector queueSelector, Server server, ServerBecomesUnavailableEvent event) {
        List<ServerBecomesUnavailableListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerBecomesUnavailableListeners());
        }
        listeners.addAll(getApi().getServerBecomesUnavailableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerBecomesUnavailable(event));
    }

    /**
     * Dispatch an event to {@code VoiceServerUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchVoiceServerUpdateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, VoiceServerUpdateEvent event) {
        List<VoiceServerUpdateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getVoiceServerUpdateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getVoiceServerUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onVoiceServerUpdate(event));
    }

    /**
     * Dispatch an event to {@code VoiceServerUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchVoiceServerUpdateEvent(DispatchQueueSelector queueSelector, Server server, VoiceServerUpdateEvent event) {
        List<VoiceServerUpdateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getVoiceServerUpdateListeners());
        }
        listeners.addAll(getApi().getVoiceServerUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onVoiceServerUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeDescriptionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeDescriptionEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeDescriptionEvent event) {
        List<ServerChangeDescriptionListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeDescriptionListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeDescriptionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeDescription(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeDescriptionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeDescriptionEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeDescriptionEvent event) {
        List<ServerChangeDescriptionListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeDescriptionListeners());
        }
        listeners.addAll(getApi().getServerChangeDescriptionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeDescription(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeVerificationLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeVerificationLevelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeVerificationLevelEvent event) {
        List<ServerChangeVerificationLevelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeVerificationLevelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeVerificationLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeVerificationLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeVerificationLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeVerificationLevelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeVerificationLevelEvent event) {
        List<ServerChangeVerificationLevelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeVerificationLevelListeners());
        }
        listeners.addAll(getApi().getServerChangeVerificationLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeVerificationLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerLeaveEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerLeaveEvent event) {
        List<ServerLeaveListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerLeaveListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerLeaveEvent(DispatchQueueSelector queueSelector, Server server, ServerLeaveEvent event) {
        List<ServerLeaveListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerLeaveListeners());
        }
        listeners.addAll(getApi().getServerLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeBoostCountListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeBoostCountEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeBoostCountEvent event) {
        List<ServerChangeBoostCountListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeBoostCountListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeBoostCountListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeBoostCount(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeBoostCountListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeBoostCountEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeBoostCountEvent event) {
        List<ServerChangeBoostCountListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeBoostCountListeners());
        }
        listeners.addAll(getApi().getServerChangeBoostCountListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeBoostCount(event));
    }

    /**
     * Dispatch an event to {@code ServerBecomesAvailableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param event The event.
     */
    public void dispatchServerBecomesAvailableEvent(DispatchQueueSelector queueSelector, ServerBecomesAvailableEvent event) {
        List<ServerBecomesAvailableListener> listeners = new ArrayList<>();
        listeners.addAll(getApi().getServerBecomesAvailableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerBecomesAvailable(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeDefaultMessageNotificationLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeDefaultMessageNotificationLevelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeDefaultMessageNotificationLevelEvent event) {
        List<ServerChangeDefaultMessageNotificationLevelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeDefaultMessageNotificationLevelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeDefaultMessageNotificationLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeDefaultMessageNotificationLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeDefaultMessageNotificationLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeDefaultMessageNotificationLevelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeDefaultMessageNotificationLevelEvent event) {
        List<ServerChangeDefaultMessageNotificationLevelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeDefaultMessageNotificationLevelListeners());
        }
        listeners.addAll(getApi().getServerChangeDefaultMessageNotificationLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeDefaultMessageNotificationLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeRegionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeRegionEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeRegionEvent event) {
        List<ServerChangeRegionListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeRegionListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeRegionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeRegion(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeRegionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeRegionEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeRegionEvent event) {
        List<ServerChangeRegionListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeRegionListeners());
        }
        listeners.addAll(getApi().getServerChangeRegionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeRegion(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerMemberJoinEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, ServerMemberJoinEvent event) {
        List<ServerMemberJoinListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerMemberJoinListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerMemberJoinListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerMemberJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerMemberJoinEvent(DispatchQueueSelector queueSelector, Server server, User user, ServerMemberJoinEvent event) {
        List<ServerMemberJoinListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberJoinListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerMemberJoinListeners());
        }
        listeners.addAll(getApi().getServerMemberJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerMemberJoinEvent(DispatchQueueSelector queueSelector, Server server, long userId, ServerMemberJoinEvent event) {
        List<ServerMemberJoinListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberJoinListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerMemberJoinListener.class));
        listeners.addAll(getApi().getServerMemberJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerMemberLeaveEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, ServerMemberLeaveEvent event) {
        List<ServerMemberLeaveListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerMemberLeaveListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerMemberLeaveListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerMemberLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerMemberLeaveEvent(DispatchQueueSelector queueSelector, Server server, User user, ServerMemberLeaveEvent event) {
        List<ServerMemberLeaveListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberLeaveListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerMemberLeaveListeners());
        }
        listeners.addAll(getApi().getServerMemberLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerMemberLeaveEvent(DispatchQueueSelector queueSelector, Server server, long userId, ServerMemberLeaveEvent event) {
        List<ServerMemberLeaveListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberLeaveListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerMemberLeaveListener.class));
        listeners.addAll(getApi().getServerMemberLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberBanListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerMemberBanEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, ServerMemberBanEvent event) {
        List<ServerMemberBanListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerMemberBanListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerMemberBanListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerMemberBanListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberBan(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberBanListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerMemberBanEvent(DispatchQueueSelector queueSelector, Server server, User user, ServerMemberBanEvent event) {
        List<ServerMemberBanListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberBanListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerMemberBanListeners());
        }
        listeners.addAll(getApi().getServerMemberBanListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberBan(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberBanListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerMemberBanEvent(DispatchQueueSelector queueSelector, Server server, long userId, ServerMemberBanEvent event) {
        List<ServerMemberBanListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberBanListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerMemberBanListener.class));
        listeners.addAll(getApi().getServerMemberBanListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberBan(event));
    }

    /**
     * Dispatch an event to {@code ServerMembersChunkListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerMembersChunkEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerMembersChunkEvent event) {
        List<ServerMembersChunkListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerMembersChunkListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerMembersChunkListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMembersChunk(event));
    }

    /**
     * Dispatch an event to {@code ServerMembersChunkListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerMembersChunkEvent(DispatchQueueSelector queueSelector, Server server, ServerMembersChunkEvent event) {
        List<ServerMembersChunkListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMembersChunkListeners());
        }
        listeners.addAll(getApi().getServerMembersChunkListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMembersChunk(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberUnbanListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerMemberUnbanEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, ServerMemberUnbanEvent event) {
        List<ServerMemberUnbanListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerMemberUnbanListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerMemberUnbanListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerMemberUnbanListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberUnban(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberUnbanListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerMemberUnbanEvent(DispatchQueueSelector queueSelector, Server server, User user, ServerMemberUnbanEvent event) {
        List<ServerMemberUnbanListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberUnbanListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerMemberUnbanListeners());
        }
        listeners.addAll(getApi().getServerMemberUnbanListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberUnban(event));
    }

    /**
     * Dispatch an event to {@code ServerMemberUnbanListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerMemberUnbanEvent(DispatchQueueSelector queueSelector, Server server, long userId, ServerMemberUnbanEvent event) {
        List<ServerMemberUnbanListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerMemberUnbanListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerMemberUnbanListener.class));
        listeners.addAll(getApi().getServerMemberUnbanListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberUnban(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param knownCustomEmojis The {@code KnownCustomEmoji}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiChangeNameEvent(DispatchQueueSelector queueSelector, Collection<KnownCustomEmoji> knownCustomEmojis, Collection<Server> servers, KnownCustomEmojiChangeNameEvent event) {
        List<KnownCustomEmojiChangeNameListener> listeners = new ArrayList<>();
        if (knownCustomEmojis != null) {
            knownCustomEmojis.stream()
                             .map(KnownCustomEmoji::getKnownCustomEmojiChangeNameListeners)
                             .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getKnownCustomEmojiChangeNameListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getKnownCustomEmojiChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiChangeName(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param knownCustomEmoji The {@code KnownCustomEmoji}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiChangeNameEvent(DispatchQueueSelector queueSelector, KnownCustomEmoji knownCustomEmoji, Server server, KnownCustomEmojiChangeNameEvent event) {
        List<KnownCustomEmojiChangeNameListener> listeners = new ArrayList<>();
        if (knownCustomEmoji != null) {
            listeners.addAll(knownCustomEmoji.getKnownCustomEmojiChangeNameListeners());
        }
        if (server != null) {
            listeners.addAll(server.getKnownCustomEmojiChangeNameListeners());
        }
        listeners.addAll(getApi().getKnownCustomEmojiChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiChangeName(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param knownCustomEmojis The {@code KnownCustomEmoji}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiDeleteEvent(DispatchQueueSelector queueSelector, Collection<KnownCustomEmoji> knownCustomEmojis, Collection<Server> servers, KnownCustomEmojiDeleteEvent event) {
        List<KnownCustomEmojiDeleteListener> listeners = new ArrayList<>();
        if (knownCustomEmojis != null) {
            knownCustomEmojis.stream()
                             .map(KnownCustomEmoji::getKnownCustomEmojiDeleteListeners)
                             .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getKnownCustomEmojiDeleteListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getKnownCustomEmojiDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiDelete(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param knownCustomEmoji The {@code KnownCustomEmoji}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiDeleteEvent(DispatchQueueSelector queueSelector, KnownCustomEmoji knownCustomEmoji, Server server, KnownCustomEmojiDeleteEvent event) {
        List<KnownCustomEmojiDeleteListener> listeners = new ArrayList<>();
        if (knownCustomEmoji != null) {
            listeners.addAll(knownCustomEmoji.getKnownCustomEmojiDeleteListeners());
        }
        if (server != null) {
            listeners.addAll(server.getKnownCustomEmojiDeleteListeners());
        }
        listeners.addAll(getApi().getKnownCustomEmojiDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiDelete(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiChangeWhitelistedRolesListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param knownCustomEmojis The {@code KnownCustomEmoji}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiChangeWhitelistedRolesEvent(DispatchQueueSelector queueSelector, Collection<KnownCustomEmoji> knownCustomEmojis, Collection<Server> servers, KnownCustomEmojiChangeWhitelistedRolesEvent event) {
        List<KnownCustomEmojiChangeWhitelistedRolesListener> listeners = new ArrayList<>();
        if (knownCustomEmojis != null) {
            knownCustomEmojis.stream()
                             .map(KnownCustomEmoji::getKnownCustomEmojiChangeWhitelistedRolesListeners)
                             .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getKnownCustomEmojiChangeWhitelistedRolesListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getKnownCustomEmojiChangeWhitelistedRolesListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiChangeWhitelistedRoles(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiChangeWhitelistedRolesListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param knownCustomEmoji The {@code KnownCustomEmoji}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiChangeWhitelistedRolesEvent(DispatchQueueSelector queueSelector, KnownCustomEmoji knownCustomEmoji, Server server, KnownCustomEmojiChangeWhitelistedRolesEvent event) {
        List<KnownCustomEmojiChangeWhitelistedRolesListener> listeners = new ArrayList<>();
        if (knownCustomEmoji != null) {
            listeners.addAll(knownCustomEmoji.getKnownCustomEmojiChangeWhitelistedRolesListeners());
        }
        if (server != null) {
            listeners.addAll(server.getKnownCustomEmojiChangeWhitelistedRolesListeners());
        }
        listeners.addAll(getApi().getKnownCustomEmojiChangeWhitelistedRolesListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiChangeWhitelistedRoles(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, KnownCustomEmojiCreateEvent event) {
        List<KnownCustomEmojiCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getKnownCustomEmojiCreateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getKnownCustomEmojiCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiCreate(event));
    }

    /**
     * Dispatch an event to {@code KnownCustomEmojiCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchKnownCustomEmojiCreateEvent(DispatchQueueSelector queueSelector, Server server, KnownCustomEmojiCreateEvent event) {
        List<KnownCustomEmojiCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getKnownCustomEmojiCreateListeners());
        }
        listeners.addAll(getApi().getKnownCustomEmojiCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onKnownCustomEmojiCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeSystemChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeSystemChannelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeSystemChannelEvent event) {
        List<ServerChangeSystemChannelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeSystemChannelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeSystemChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeSystemChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeSystemChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeSystemChannelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeSystemChannelEvent event) {
        List<ServerChangeSystemChannelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeSystemChannelListeners());
        }
        listeners.addAll(getApi().getServerChangeSystemChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeSystemChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangePreferredLocaleListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangePreferredLocaleEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangePreferredLocaleEvent event) {
        List<ServerChangePreferredLocaleListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangePreferredLocaleListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangePreferredLocaleListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangePreferredLocale(event));
    }

    /**
     * Dispatch an event to {@code ServerChangePreferredLocaleListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangePreferredLocaleEvent(DispatchQueueSelector queueSelector, Server server, ServerChangePreferredLocaleEvent event) {
        List<ServerChangePreferredLocaleListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangePreferredLocaleListeners());
        }
        listeners.addAll(getApi().getServerChangePreferredLocaleListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangePreferredLocale(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeBoostLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeBoostLevelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeBoostLevelEvent event) {
        List<ServerChangeBoostLevelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeBoostLevelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeBoostLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeBoostLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeBoostLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeBoostLevelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeBoostLevelEvent event) {
        List<ServerChangeBoostLevelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeBoostLevelListeners());
        }
        listeners.addAll(getApi().getServerChangeBoostLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeBoostLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeRulesChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeRulesChannelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeRulesChannelEvent event) {
        List<ServerChangeRulesChannelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeRulesChannelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeRulesChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeRulesChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeRulesChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeRulesChannelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeRulesChannelEvent event) {
        List<ServerChangeRulesChannelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeRulesChannelListeners());
        }
        listeners.addAll(getApi().getServerChangeRulesChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeRulesChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeServerFeatureListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeServerFeaturesEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeServerFeaturesEvent event) {
        List<ServerChangeServerFeatureListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeServerFeatureListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeServerFeatureListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeServerFeature(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeServerFeatureListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeServerFeaturesEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeServerFeaturesEvent event) {
        List<ServerChangeServerFeatureListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeServerFeatureListeners());
        }
        listeners.addAll(getApi().getServerChangeServerFeatureListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeServerFeature(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeOwnerListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeOwnerEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeOwnerEvent event) {
        List<ServerChangeOwnerListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeOwnerListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeOwnerListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeOwner(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeOwnerListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeOwnerEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeOwnerEvent event) {
        List<ServerChangeOwnerListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeOwnerListeners());
        }
        listeners.addAll(getApi().getServerChangeOwnerListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeOwner(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeMultiFactorAuthenticationLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeMultiFactorAuthenticationLevelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeMultiFactorAuthenticationLevelEvent event) {
        List<ServerChangeMultiFactorAuthenticationLevelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeMultiFactorAuthenticationLevelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeMultiFactorAuthenticationLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeMultiFactorAuthenticationLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeMultiFactorAuthenticationLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeMultiFactorAuthenticationLevelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeMultiFactorAuthenticationLevelEvent event) {
        List<ServerChangeMultiFactorAuthenticationLevelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeMultiFactorAuthenticationLevelListeners());
        }
        listeners.addAll(getApi().getServerChangeMultiFactorAuthenticationLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeMultiFactorAuthenticationLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeExplicitContentFilterLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeExplicitContentFilterLevelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeExplicitContentFilterLevelEvent event) {
        List<ServerChangeExplicitContentFilterLevelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeExplicitContentFilterLevelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeExplicitContentFilterLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeExplicitContentFilterLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeExplicitContentFilterLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeExplicitContentFilterLevelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeExplicitContentFilterLevelEvent event) {
        List<ServerChangeExplicitContentFilterLevelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeExplicitContentFilterLevelListeners());
        }
        listeners.addAll(getApi().getServerChangeExplicitContentFilterLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeExplicitContentFilterLevel(event));
    }

    /**
     * Dispatch an event to {@code RoleChangePositionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleChangePositionEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleChangePositionEvent event) {
        List<RoleChangePositionListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleChangePositionListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleChangePositionListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleChangePositionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangePosition(event));
    }

    /**
     * Dispatch an event to {@code RoleChangePositionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleChangePositionEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleChangePositionEvent event) {
        List<RoleChangePositionListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleChangePositionListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleChangePositionListeners());
        }
        listeners.addAll(getApi().getRoleChangePositionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangePosition(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeMentionableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleChangeMentionableEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleChangeMentionableEvent event) {
        List<RoleChangeMentionableListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleChangeMentionableListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleChangeMentionableListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleChangeMentionableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeMentionable(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeMentionableListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleChangeMentionableEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleChangeMentionableEvent event) {
        List<RoleChangeMentionableListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleChangeMentionableListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleChangeMentionableListeners());
        }
        listeners.addAll(getApi().getRoleChangeMentionableListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeMentionable(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeColorListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleChangeColorEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleChangeColorEvent event) {
        List<RoleChangeColorListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleChangeColorListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleChangeColorListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleChangeColorListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeColor(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeColorListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleChangeColorEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleChangeColorEvent event) {
        List<RoleChangeColorListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleChangeColorListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleChangeColorListeners());
        }
        listeners.addAll(getApi().getRoleChangeColorListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeColor(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleChangeNameEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleChangeNameEvent event) {
        List<RoleChangeNameListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleChangeNameListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleChangeNameListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeName(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleChangeNameEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleChangeNameEvent event) {
        List<RoleChangeNameListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleChangeNameListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleChangeNameListeners());
        }
        listeners.addAll(getApi().getRoleChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeName(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeHoistListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleChangeHoistEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleChangeHoistEvent event) {
        List<RoleChangeHoistListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleChangeHoistListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleChangeHoistListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleChangeHoistListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeHoist(event));
    }

    /**
     * Dispatch an event to {@code RoleChangeHoistListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleChangeHoistEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleChangeHoistEvent event) {
        List<RoleChangeHoistListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleChangeHoistListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleChangeHoistListeners());
        }
        listeners.addAll(getApi().getRoleChangeHoistListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangeHoist(event));
    }

    /**
     * Dispatch an event to {@code RoleCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, RoleCreateEvent event) {
        List<RoleCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleCreateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleCreate(event));
    }

    /**
     * Dispatch an event to {@code RoleCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleCreateEvent(DispatchQueueSelector queueSelector, Server server, RoleCreateEvent event) {
        List<RoleCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getRoleCreateListeners());
        }
        listeners.addAll(getApi().getRoleCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleCreate(event));
    }

    /**
     * Dispatch an event to {@code RoleChangePermissionsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleChangePermissionsEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleChangePermissionsEvent event) {
        List<RoleChangePermissionsListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleChangePermissionsListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleChangePermissionsListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleChangePermissionsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangePermissions(event));
    }

    /**
     * Dispatch an event to {@code RoleChangePermissionsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleChangePermissionsEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleChangePermissionsEvent event) {
        List<RoleChangePermissionsListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleChangePermissionsListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleChangePermissionsListeners());
        }
        listeners.addAll(getApi().getRoleChangePermissionsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleChangePermissions(event));
    }

    /**
     * Dispatch an event to {@code UserRoleRemoveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserRoleRemoveEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, Collection<User> users, UserRoleRemoveEvent event) {
        List<UserRoleRemoveListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getUserRoleRemoveListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserRoleRemoveListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserRoleRemoveListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserRoleRemoveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserRoleRemove(event));
    }

    /**
     * Dispatch an event to {@code UserRoleRemoveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserRoleRemoveEvent(DispatchQueueSelector queueSelector, Role role, Server server, User user, UserRoleRemoveEvent event) {
        List<UserRoleRemoveListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getUserRoleRemoveListeners());
        }
        if (server != null) {
            listeners.addAll(server.getUserRoleRemoveListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserRoleRemoveListeners());
        }
        listeners.addAll(getApi().getUserRoleRemoveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserRoleRemove(event));
    }

    /**
     * Dispatch an event to {@code UserRoleRemoveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserRoleRemoveEvent(DispatchQueueSelector queueSelector, Role role, Server server, long userId, UserRoleRemoveEvent event) {
        List<UserRoleRemoveListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getUserRoleRemoveListeners());
        }
        if (server != null) {
            listeners.addAll(server.getUserRoleRemoveListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserRoleRemoveListener.class));
        listeners.addAll(getApi().getUserRoleRemoveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserRoleRemove(event));
    }

    /**
     * Dispatch an event to {@code UserRoleAddListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserRoleAddEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, Collection<User> users, UserRoleAddEvent event) {
        List<UserRoleAddListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getUserRoleAddListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserRoleAddListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserRoleAddListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserRoleAddListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserRoleAdd(event));
    }

    /**
     * Dispatch an event to {@code UserRoleAddListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserRoleAddEvent(DispatchQueueSelector queueSelector, Role role, Server server, User user, UserRoleAddEvent event) {
        List<UserRoleAddListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getUserRoleAddListeners());
        }
        if (server != null) {
            listeners.addAll(server.getUserRoleAddListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserRoleAddListeners());
        }
        listeners.addAll(getApi().getUserRoleAddListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserRoleAdd(event));
    }

    /**
     * Dispatch an event to {@code UserRoleAddListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserRoleAddEvent(DispatchQueueSelector queueSelector, Role role, Server server, long userId, UserRoleAddEvent event) {
        List<UserRoleAddListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getUserRoleAddListeners());
        }
        if (server != null) {
            listeners.addAll(server.getUserRoleAddListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserRoleAddListener.class));
        listeners.addAll(getApi().getUserRoleAddListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserRoleAdd(event));
    }

    /**
     * Dispatch an event to {@code RoleDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchRoleDeleteEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, RoleDeleteEvent event) {
        List<RoleDeleteListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getRoleDeleteListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getRoleDeleteListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getRoleDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleDelete(event));
    }

    /**
     * Dispatch an event to {@code RoleDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchRoleDeleteEvent(DispatchQueueSelector queueSelector, Role role, Server server, RoleDeleteEvent event) {
        List<RoleDeleteListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getRoleDeleteListeners());
        }
        if (server != null) {
            listeners.addAll(server.getRoleDeleteListeners());
        }
        listeners.addAll(getApi().getRoleDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onRoleDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeModeratorsOnlyChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeModeratorsOnlyChannelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeModeratorsOnlyChannelEvent event) {
        List<ServerChangeModeratorsOnlyChannelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeModeratorsOnlyChannelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeModeratorsOnlyChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeModeratorsOnlyChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeModeratorsOnlyChannelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeModeratorsOnlyChannelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeModeratorsOnlyChannelEvent event) {
        List<ServerChangeModeratorsOnlyChannelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeModeratorsOnlyChannelListeners());
        }
        listeners.addAll(getApi().getServerChangeModeratorsOnlyChannelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeModeratorsOnlyChannel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeNsfwLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChangeNsfwLevelEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChangeNsfwLevelEvent event) {
        List<ServerChangeNsfwLevelListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChangeNsfwLevelListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChangeNsfwLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeNsfwLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChangeNsfwLevelListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChangeNsfwLevelEvent(DispatchQueueSelector queueSelector, Server server, ServerChangeNsfwLevelEvent event) {
        List<ServerChangeNsfwLevelListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChangeNsfwLevelListeners());
        }
        listeners.addAll(getApi().getServerChangeNsfwLevelListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChangeNsfwLevel(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangePositionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverChannels The {@code ServerChannel}s.
     * @param event The event.
     */
    public void dispatchServerChannelChangePositionEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerChannel> serverChannels, ServerChannelChangePositionEvent event) {
        List<ServerChannelChangePositionListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelChangePositionListeners)
                   .forEach(listeners::addAll);
        }
        if (serverChannels != null) {
            serverChannels.stream()
                          .map(ServerChannel::getServerChannelChangePositionListeners)
                          .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelChangePositionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangePosition(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangePositionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverChannel The {@code ServerChannel}.
     * @param event The event.
     */
    public void dispatchServerChannelChangePositionEvent(DispatchQueueSelector queueSelector, Server server, ServerChannel serverChannel, ServerChannelChangePositionEvent event) {
        List<ServerChannelChangePositionListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChannelChangePositionListeners());
        }
        if (serverChannel != null) {
            listeners.addAll(serverChannel.getServerChannelChangePositionListeners());
        }
        listeners.addAll(getApi().getServerChannelChangePositionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangePosition(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadListSyncListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchThreadListSyncEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ThreadListSyncEvent event) {
        List<ServerThreadListSyncListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadListSyncListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadListSyncListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadListSync(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadListSyncListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchThreadListSyncEvent(DispatchQueueSelector queueSelector, Server server, ThreadListSyncEvent event) {
        List<ServerThreadListSyncListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadListSyncListeners());
        }
        listeners.addAll(getApi().getServerThreadListSyncListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadListSync(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchThreadUpdateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ThreadUpdateEvent event) {
        List<ServerThreadChannelUpdateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelUpdateListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelUpdateListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchThreadUpdateEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ThreadUpdateEvent event) {
        List<ServerThreadChannelUpdateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelUpdateListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelUpdateListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelMembersUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchThreadMembersUpdateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerThreadChannel> serverThreadChannels, ThreadMembersUpdateEvent event) {
        List<ServerThreadChannelMembersUpdateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerThreadChannelMembersUpdateListeners)
                   .forEach(listeners::addAll);
        }
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelMembersUpdateListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelMembersUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadMembersUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelMembersUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchThreadMembersUpdateEvent(DispatchQueueSelector queueSelector, Server server, ServerThreadChannel serverThreadChannel, ThreadMembersUpdateEvent event) {
        List<ServerThreadChannelMembersUpdateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerThreadChannelMembersUpdateListeners());
        }
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelMembersUpdateListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelMembersUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadMembersUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchThreadCreateEvent(DispatchQueueSelector queueSelector, Collection<ServerThreadChannel> serverThreadChannels, ThreadCreateEvent event) {
        List<ServerThreadChannelCreateListener> listeners = new ArrayList<>();
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelCreateListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchThreadCreateEvent(DispatchQueueSelector queueSelector, ServerThreadChannel serverThreadChannel, ThreadCreateEvent event) {
        List<ServerThreadChannelCreateListener> listeners = new ArrayList<>();
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelCreateListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param serverThreadChannels The {@code ServerThreadChannel}s.
     * @param event The event.
     */
    public void dispatchThreadDeleteEvent(DispatchQueueSelector queueSelector, Collection<ServerThreadChannel> serverThreadChannels, ThreadDeleteEvent event) {
        List<ServerThreadChannelDeleteListener> listeners = new ArrayList<>();
        if (serverThreadChannels != null) {
            serverThreadChannels.stream()
                                .map(ServerThreadChannel::getServerThreadChannelDeleteListeners)
                                .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerThreadChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerThreadChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param serverThreadChannel The {@code ServerThreadChannel}.
     * @param event The event.
     */
    public void dispatchThreadDeleteEvent(DispatchQueueSelector queueSelector, ServerThreadChannel serverThreadChannel, ThreadDeleteEvent event) {
        List<ServerThreadChannelDeleteListener> listeners = new ArrayList<>();
        if (serverThreadChannel != null) {
            listeners.addAll(serverThreadChannel.getServerThreadChannelDeleteListeners());
        }
        listeners.addAll(getApi().getServerThreadChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onThreadDelete(event));
    }

    /**
     * Dispatch an event to {@code WebhooksUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverTextChannels The {@code ServerTextChannel}s.
     * @param event The event.
     */
    public void dispatchWebhooksUpdateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerTextChannel> serverTextChannels, WebhooksUpdateEvent event) {
        List<WebhooksUpdateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getWebhooksUpdateListeners)
                   .forEach(listeners::addAll);
        }
        if (serverTextChannels != null) {
            serverTextChannels.stream()
                              .map(ServerTextChannel::getWebhooksUpdateListeners)
                              .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getWebhooksUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onWebhooksUpdate(event));
    }

    /**
     * Dispatch an event to {@code WebhooksUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverTextChannel The {@code ServerTextChannel}.
     * @param event The event.
     */
    public void dispatchWebhooksUpdateEvent(DispatchQueueSelector queueSelector, Server server, ServerTextChannel serverTextChannel, WebhooksUpdateEvent event) {
        List<WebhooksUpdateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getWebhooksUpdateListeners());
        }
        if (serverTextChannel != null) {
            listeners.addAll(serverTextChannel.getWebhooksUpdateListeners());
        }
        listeners.addAll(getApi().getWebhooksUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onWebhooksUpdate(event));
    }

    /**
     * Dispatch an event to {@code ServerTextChannelChangeDefaultAutoArchiveDurationListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverTextChannels The {@code ServerTextChannel}s.
     * @param event The event.
     */
    public void dispatchServerTextChannelChangeDefaultAutoArchiveDurationEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerTextChannel> serverTextChannels, ServerTextChannelChangeDefaultAutoArchiveDurationEvent event) {
        List<ServerTextChannelChangeDefaultAutoArchiveDurationListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerTextChannelChangeDefaultAutoArchiveDurationListeners)
                   .forEach(listeners::addAll);
        }
        if (serverTextChannels != null) {
            serverTextChannels.stream()
                              .map(ServerTextChannel::getServerTextChannelChangeDefaultAutoArchiveDurationListeners)
                              .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerTextChannelChangeDefaultAutoArchiveDurationListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerTextChannelChangeDefaultAutoArchiveDuration(event));
    }

    /**
     * Dispatch an event to {@code ServerTextChannelChangeDefaultAutoArchiveDurationListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverTextChannel The {@code ServerTextChannel}.
     * @param event The event.
     */
    public void dispatchServerTextChannelChangeDefaultAutoArchiveDurationEvent(DispatchQueueSelector queueSelector, Server server, ServerTextChannel serverTextChannel, ServerTextChannelChangeDefaultAutoArchiveDurationEvent event) {
        List<ServerTextChannelChangeDefaultAutoArchiveDurationListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerTextChannelChangeDefaultAutoArchiveDurationListeners());
        }
        if (serverTextChannel != null) {
            listeners.addAll(serverTextChannel.getServerTextChannelChangeDefaultAutoArchiveDurationListeners());
        }
        listeners.addAll(getApi().getServerTextChannelChangeDefaultAutoArchiveDurationListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerTextChannelChangeDefaultAutoArchiveDuration(event));
    }

    /**
     * Dispatch an event to {@code ServerTextChannelChangeSlowmodeListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverTextChannels The {@code ServerTextChannel}s.
     * @param event The event.
     */
    public void dispatchServerTextChannelChangeSlowmodeEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerTextChannel> serverTextChannels, ServerTextChannelChangeSlowmodeEvent event) {
        List<ServerTextChannelChangeSlowmodeListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerTextChannelChangeSlowmodeListeners)
                   .forEach(listeners::addAll);
        }
        if (serverTextChannels != null) {
            serverTextChannels.stream()
                              .map(ServerTextChannel::getServerTextChannelChangeSlowmodeListeners)
                              .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerTextChannelChangeSlowmodeListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerTextChannelChangeSlowmodeDelay(event));
    }

    /**
     * Dispatch an event to {@code ServerTextChannelChangeSlowmodeListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverTextChannel The {@code ServerTextChannel}.
     * @param event The event.
     */
    public void dispatchServerTextChannelChangeSlowmodeEvent(DispatchQueueSelector queueSelector, Server server, ServerTextChannel serverTextChannel, ServerTextChannelChangeSlowmodeEvent event) {
        List<ServerTextChannelChangeSlowmodeListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerTextChannelChangeSlowmodeListeners());
        }
        if (serverTextChannel != null) {
            listeners.addAll(serverTextChannel.getServerTextChannelChangeSlowmodeListeners());
        }
        listeners.addAll(getApi().getServerTextChannelChangeSlowmodeListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerTextChannelChangeSlowmodeDelay(event));
    }

    /**
     * Dispatch an event to {@code ServerTextChannelChangeTopicListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverTextChannels The {@code ServerTextChannel}s.
     * @param event The event.
     */
    public void dispatchServerTextChannelChangeTopicEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerTextChannel> serverTextChannels, ServerTextChannelChangeTopicEvent event) {
        List<ServerTextChannelChangeTopicListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerTextChannelChangeTopicListeners)
                   .forEach(listeners::addAll);
        }
        if (serverTextChannels != null) {
            serverTextChannels.stream()
                              .map(ServerTextChannel::getServerTextChannelChangeTopicListeners)
                              .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerTextChannelChangeTopicListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerTextChannelChangeTopic(event));
    }

    /**
     * Dispatch an event to {@code ServerTextChannelChangeTopicListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverTextChannel The {@code ServerTextChannel}.
     * @param event The event.
     */
    public void dispatchServerTextChannelChangeTopicEvent(DispatchQueueSelector queueSelector, Server server, ServerTextChannel serverTextChannel, ServerTextChannelChangeTopicEvent event) {
        List<ServerTextChannelChangeTopicListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerTextChannelChangeTopicListeners());
        }
        if (serverTextChannel != null) {
            listeners.addAll(serverTextChannel.getServerTextChannelChangeTopicListeners());
        }
        listeners.addAll(getApi().getServerTextChannelChangeTopicListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerTextChannelChangeTopic(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeOverwrittenPermissionsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param roles The {@code Role}s.
     * @param servers The {@code Server}s.
     * @param serverChannels The {@code ServerChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerChannelChangeOverwrittenPermissionsEvent(DispatchQueueSelector queueSelector, Collection<Role> roles, Collection<Server> servers, Collection<ServerChannel> serverChannels, Collection<User> users, ServerChannelChangeOverwrittenPermissionsEvent event) {
        List<ServerChannelChangeOverwrittenPermissionsListener> listeners = new ArrayList<>();
        if (roles != null) {
            roles.stream()
                 .map(Role::getServerChannelChangeOverwrittenPermissionsListeners)
                 .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelChangeOverwrittenPermissionsListeners)
                   .forEach(listeners::addAll);
        }
        if (serverChannels != null) {
            serverChannels.stream()
                          .map(ServerChannel::getServerChannelChangeOverwrittenPermissionsListeners)
                          .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerChannelChangeOverwrittenPermissionsListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelChangeOverwrittenPermissionsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeOverwrittenPermissions(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeOverwrittenPermissionsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param serverChannel The {@code ServerChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerChannelChangeOverwrittenPermissionsEvent(DispatchQueueSelector queueSelector, Role role, Server server, ServerChannel serverChannel, User user, ServerChannelChangeOverwrittenPermissionsEvent event) {
        List<ServerChannelChangeOverwrittenPermissionsListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        if (server != null) {
            listeners.addAll(server.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        if (serverChannel != null) {
            listeners.addAll(serverChannel.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        listeners.addAll(getApi().getServerChannelChangeOverwrittenPermissionsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeOverwrittenPermissions(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeOverwrittenPermissionsListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param role The {@code Role}.
     * @param server The {@code Server}.
     * @param serverChannel The {@code ServerChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerChannelChangeOverwrittenPermissionsEvent(DispatchQueueSelector queueSelector, Role role, Server server, ServerChannel serverChannel, long userId, ServerChannelChangeOverwrittenPermissionsEvent event) {
        List<ServerChannelChangeOverwrittenPermissionsListener> listeners = new ArrayList<>();
        if (role != null) {
            listeners.addAll(role.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        if (server != null) {
            listeners.addAll(server.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        if (serverChannel != null) {
            listeners.addAll(serverChannel.getServerChannelChangeOverwrittenPermissionsListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerChannelChangeOverwrittenPermissionsListener.class));
        listeners.addAll(getApi().getServerChannelChangeOverwrittenPermissionsListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeOverwrittenPermissions(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelInviteDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChannelInviteDeleteEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChannelInviteDeleteEvent event) {
        List<ServerChannelInviteDeleteListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelInviteDeleteListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelInviteDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelInviteDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelInviteDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChannelInviteDeleteEvent(DispatchQueueSelector queueSelector, Server server, ServerChannelInviteDeleteEvent event) {
        List<ServerChannelInviteDeleteListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChannelInviteDeleteListeners());
        }
        listeners.addAll(getApi().getServerChannelInviteDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelInviteDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelInviteCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChannelInviteCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChannelInviteCreateEvent event) {
        List<ServerChannelInviteCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelInviteCreateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelInviteCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelInviteCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelInviteCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChannelInviteCreateEvent(DispatchQueueSelector queueSelector, Server server, ServerChannelInviteCreateEvent event) {
        List<ServerChannelInviteCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChannelInviteCreateListeners());
        }
        listeners.addAll(getApi().getServerChannelInviteCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelInviteCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeNsfwFlagListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param channelCategorys The {@code ChannelCategory}s.
     * @param servers The {@code Server}s.
     * @param serverTextChannels The {@code ServerTextChannel}s.
     * @param event The event.
     */
    public void dispatchServerChannelChangeNsfwFlagEvent(DispatchQueueSelector queueSelector, Collection<ChannelCategory> channelCategorys, Collection<Server> servers, Collection<ServerTextChannel> serverTextChannels, ServerChannelChangeNsfwFlagEvent event) {
        List<ServerChannelChangeNsfwFlagListener> listeners = new ArrayList<>();
        if (channelCategorys != null) {
            channelCategorys.stream()
                            .map(ChannelCategory::getServerChannelChangeNsfwFlagListeners)
                            .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelChangeNsfwFlagListeners)
                   .forEach(listeners::addAll);
        }
        if (serverTextChannels != null) {
            serverTextChannels.stream()
                              .map(ServerTextChannel::getServerChannelChangeNsfwFlagListeners)
                              .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelChangeNsfwFlagListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeNsfwFlag(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeNsfwFlagListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param channelCategory The {@code ChannelCategory}.
     * @param server The {@code Server}.
     * @param serverTextChannel The {@code ServerTextChannel}.
     * @param event The event.
     */
    public void dispatchServerChannelChangeNsfwFlagEvent(DispatchQueueSelector queueSelector, ChannelCategory channelCategory, Server server, ServerTextChannel serverTextChannel, ServerChannelChangeNsfwFlagEvent event) {
        List<ServerChannelChangeNsfwFlagListener> listeners = new ArrayList<>();
        if (channelCategory != null) {
            listeners.addAll(channelCategory.getServerChannelChangeNsfwFlagListeners());
        }
        if (server != null) {
            listeners.addAll(server.getServerChannelChangeNsfwFlagListeners());
        }
        if (serverTextChannel != null) {
            listeners.addAll(serverTextChannel.getServerChannelChangeNsfwFlagListeners());
        }
        listeners.addAll(getApi().getServerChannelChangeNsfwFlagListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeNsfwFlag(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverChannels The {@code ServerChannel}s.
     * @param event The event.
     */
    public void dispatchServerChannelDeleteEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerChannel> serverChannels, ServerChannelDeleteEvent event) {
        List<ServerChannelDeleteListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelDeleteListeners)
                   .forEach(listeners::addAll);
        }
        if (serverChannels != null) {
            serverChannels.stream()
                          .map(ServerChannel::getServerChannelDeleteListeners)
                          .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverChannel The {@code ServerChannel}.
     * @param event The event.
     */
    public void dispatchServerChannelDeleteEvent(DispatchQueueSelector queueSelector, Server server, ServerChannel serverChannel, ServerChannelDeleteEvent event) {
        List<ServerChannelDeleteListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChannelDeleteListeners());
        }
        if (serverChannel != null) {
            listeners.addAll(serverChannel.getServerChannelDeleteListeners());
        }
        listeners.addAll(getApi().getServerChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelDelete(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param event The event.
     */
    public void dispatchServerChannelCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, ServerChannelCreateEvent event) {
        List<ServerChannelCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelCreateListeners)
                   .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param event The event.
     */
    public void dispatchServerChannelCreateEvent(DispatchQueueSelector queueSelector, Server server, ServerChannelCreateEvent event) {
        List<ServerChannelCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChannelCreateListeners());
        }
        listeners.addAll(getApi().getServerChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelCreate(event));
    }

    /**
     * Dispatch an event to {@code ServerStageVoiceChannelChangeTopicListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverStageVoiceChannels The {@code ServerStageVoiceChannel}s.
     * @param event The event.
     */
    public void dispatchServerStageVoiceChannelChangeTopicEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerStageVoiceChannel> serverStageVoiceChannels, ServerStageVoiceChannelChangeTopicEvent event) {
        List<ServerStageVoiceChannelChangeTopicListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerStageVoiceChannelChangeTopicListeners)
                   .forEach(listeners::addAll);
        }
        if (serverStageVoiceChannels != null) {
            serverStageVoiceChannels.stream()
                                    .map(ServerStageVoiceChannel::getServerStageVoiceChannelChangeTopicListeners)
                                    .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerStageVoiceChannelChangeTopicListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerStageVoiceChannelChangeTopic(event));
    }

    /**
     * Dispatch an event to {@code ServerStageVoiceChannelChangeTopicListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverStageVoiceChannel The {@code ServerStageVoiceChannel}.
     * @param event The event.
     */
    public void dispatchServerStageVoiceChannelChangeTopicEvent(DispatchQueueSelector queueSelector, Server server, ServerStageVoiceChannel serverStageVoiceChannel, ServerStageVoiceChannelChangeTopicEvent event) {
        List<ServerStageVoiceChannelChangeTopicListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerStageVoiceChannelChangeTopicListeners());
        }
        if (serverStageVoiceChannel != null) {
            listeners.addAll(serverStageVoiceChannel.getServerStageVoiceChannelChangeTopicListeners());
        }
        listeners.addAll(getApi().getServerStageVoiceChannelChangeTopicListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerStageVoiceChannelChangeTopic(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelChangeBitrateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverVoiceChannels The {@code ServerVoiceChannel}s.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelChangeBitrateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerVoiceChannel> serverVoiceChannels, ServerVoiceChannelChangeBitrateEvent event) {
        List<ServerVoiceChannelChangeBitrateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerVoiceChannelChangeBitrateListeners)
                   .forEach(listeners::addAll);
        }
        if (serverVoiceChannels != null) {
            serverVoiceChannels.stream()
                               .map(ServerVoiceChannel::getServerVoiceChannelChangeBitrateListeners)
                               .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerVoiceChannelChangeBitrateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelChangeBitrate(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelChangeBitrateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelChangeBitrateEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, ServerVoiceChannelChangeBitrateEvent event) {
        List<ServerVoiceChannelChangeBitrateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelChangeBitrateListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelChangeBitrateListeners());
        }
        listeners.addAll(getApi().getServerVoiceChannelChangeBitrateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelChangeBitrate(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelChangeUserLimitListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverVoiceChannels The {@code ServerVoiceChannel}s.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelChangeUserLimitEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerVoiceChannel> serverVoiceChannels, ServerVoiceChannelChangeUserLimitEvent event) {
        List<ServerVoiceChannelChangeUserLimitListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerVoiceChannelChangeUserLimitListeners)
                   .forEach(listeners::addAll);
        }
        if (serverVoiceChannels != null) {
            serverVoiceChannels.stream()
                               .map(ServerVoiceChannel::getServerVoiceChannelChangeUserLimitListeners)
                               .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerVoiceChannelChangeUserLimitListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelChangeUserLimit(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelChangeUserLimitListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelChangeUserLimitEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, ServerVoiceChannelChangeUserLimitEvent event) {
        List<ServerVoiceChannelChangeUserLimitListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelChangeUserLimitListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelChangeUserLimitListeners());
        }
        listeners.addAll(getApi().getServerVoiceChannelChangeUserLimitListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelChangeUserLimit(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelMemberLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverVoiceChannels The {@code ServerVoiceChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelMemberLeaveEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerVoiceChannel> serverVoiceChannels, Collection<User> users, ServerVoiceChannelMemberLeaveEvent event) {
        List<ServerVoiceChannelMemberLeaveListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerVoiceChannelMemberLeaveListeners)
                   .forEach(listeners::addAll);
        }
        if (serverVoiceChannels != null) {
            serverVoiceChannels.stream()
                               .map(ServerVoiceChannel::getServerVoiceChannelMemberLeaveListeners)
                               .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerVoiceChannelMemberLeaveListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerVoiceChannelMemberLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelMemberLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelMemberLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelMemberLeaveEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, User user, ServerVoiceChannelMemberLeaveEvent event) {
        List<ServerVoiceChannelMemberLeaveListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelMemberLeaveListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelMemberLeaveListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerVoiceChannelMemberLeaveListeners());
        }
        listeners.addAll(getApi().getServerVoiceChannelMemberLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelMemberLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelMemberLeaveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelMemberLeaveEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, long userId, ServerVoiceChannelMemberLeaveEvent event) {
        List<ServerVoiceChannelMemberLeaveListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelMemberLeaveListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelMemberLeaveListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerVoiceChannelMemberLeaveListener.class));
        listeners.addAll(getApi().getServerVoiceChannelMemberLeaveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelMemberLeave(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelChangeNsfwListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverVoiceChannels The {@code ServerVoiceChannel}s.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelChangeNsfwEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerVoiceChannel> serverVoiceChannels, ServerVoiceChannelChangeNsfwEvent event) {
        List<ServerVoiceChannelChangeNsfwListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerVoiceChannelChangeNsfwListeners)
                   .forEach(listeners::addAll);
        }
        if (serverVoiceChannels != null) {
            serverVoiceChannels.stream()
                               .map(ServerVoiceChannel::getServerVoiceChannelChangeNsfwListeners)
                               .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerVoiceChannelChangeNsfwListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelChangeNsfw(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelChangeNsfwListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelChangeNsfwEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, ServerVoiceChannelChangeNsfwEvent event) {
        List<ServerVoiceChannelChangeNsfwListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelChangeNsfwListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelChangeNsfwListeners());
        }
        listeners.addAll(getApi().getServerVoiceChannelChangeNsfwListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelChangeNsfw(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelMemberJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverVoiceChannels The {@code ServerVoiceChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelMemberJoinEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerVoiceChannel> serverVoiceChannels, Collection<User> users, ServerVoiceChannelMemberJoinEvent event) {
        List<ServerVoiceChannelMemberJoinListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerVoiceChannelMemberJoinListeners)
                   .forEach(listeners::addAll);
        }
        if (serverVoiceChannels != null) {
            serverVoiceChannels.stream()
                               .map(ServerVoiceChannel::getServerVoiceChannelMemberJoinListeners)
                               .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getServerVoiceChannelMemberJoinListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerVoiceChannelMemberJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelMemberJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelMemberJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelMemberJoinEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, User user, ServerVoiceChannelMemberJoinEvent event) {
        List<ServerVoiceChannelMemberJoinListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelMemberJoinListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelMemberJoinListeners());
        }
        if (user != null) {
            listeners.addAll(user.getServerVoiceChannelMemberJoinListeners());
        }
        listeners.addAll(getApi().getServerVoiceChannelMemberJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelMemberJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerVoiceChannelMemberJoinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverVoiceChannel The {@code ServerVoiceChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchServerVoiceChannelMemberJoinEvent(DispatchQueueSelector queueSelector, Server server, ServerVoiceChannel serverVoiceChannel, long userId, ServerVoiceChannelMemberJoinEvent event) {
        List<ServerVoiceChannelMemberJoinListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerVoiceChannelMemberJoinListeners());
        }
        if (serverVoiceChannel != null) {
            listeners.addAll(serverVoiceChannel.getServerVoiceChannelMemberJoinListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ServerVoiceChannelMemberJoinListener.class));
        listeners.addAll(getApi().getServerVoiceChannelMemberJoinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerVoiceChannelMemberJoin(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param serverChannels The {@code ServerChannel}s.
     * @param event The event.
     */
    public void dispatchServerChannelChangeNameEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<ServerChannel> serverChannels, ServerChannelChangeNameEvent event) {
        List<ServerChannelChangeNameListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getServerChannelChangeNameListeners)
                   .forEach(listeners::addAll);
        }
        if (serverChannels != null) {
            serverChannels.stream()
                          .map(ServerChannel::getServerChannelChangeNameListeners)
                          .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getServerChannelChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeName(event));
    }

    /**
     * Dispatch an event to {@code ServerChannelChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param serverChannel The {@code ServerChannel}.
     * @param event The event.
     */
    public void dispatchServerChannelChangeNameEvent(DispatchQueueSelector queueSelector, Server server, ServerChannel serverChannel, ServerChannelChangeNameEvent event) {
        List<ServerChannelChangeNameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getServerChannelChangeNameListeners());
        }
        if (serverChannel != null) {
            listeners.addAll(serverChannel.getServerChannelChangeNameListeners());
        }
        listeners.addAll(getApi().getServerChannelChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerChannelChangeName(event));
    }

    /**
     * Dispatch an event to {@code PrivateChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param privateChannels The {@code PrivateChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchPrivateChannelDeleteEvent(DispatchQueueSelector queueSelector, Collection<PrivateChannel> privateChannels, Collection<User> users, PrivateChannelDeleteEvent event) {
        List<PrivateChannelDeleteListener> listeners = new ArrayList<>();
        if (privateChannels != null) {
            privateChannels.stream()
                           .map(PrivateChannel::getPrivateChannelDeleteListeners)
                           .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getPrivateChannelDeleteListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getPrivateChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onPrivateChannelDelete(event));
    }

    /**
     * Dispatch an event to {@code PrivateChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param privateChannel The {@code PrivateChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchPrivateChannelDeleteEvent(DispatchQueueSelector queueSelector, PrivateChannel privateChannel, User user, PrivateChannelDeleteEvent event) {
        List<PrivateChannelDeleteListener> listeners = new ArrayList<>();
        if (privateChannel != null) {
            listeners.addAll(privateChannel.getPrivateChannelDeleteListeners());
        }
        if (user != null) {
            listeners.addAll(user.getPrivateChannelDeleteListeners());
        }
        listeners.addAll(getApi().getPrivateChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onPrivateChannelDelete(event));
    }

    /**
     * Dispatch an event to {@code PrivateChannelDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param privateChannel The {@code PrivateChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchPrivateChannelDeleteEvent(DispatchQueueSelector queueSelector, PrivateChannel privateChannel, long userId, PrivateChannelDeleteEvent event) {
        List<PrivateChannelDeleteListener> listeners = new ArrayList<>();
        if (privateChannel != null) {
            listeners.addAll(privateChannel.getPrivateChannelDeleteListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     PrivateChannelDeleteListener.class));
        listeners.addAll(getApi().getPrivateChannelDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onPrivateChannelDelete(event));
    }

    /**
     * Dispatch an event to {@code PrivateChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchPrivateChannelCreateEvent(DispatchQueueSelector queueSelector, Collection<User> users, PrivateChannelCreateEvent event) {
        List<PrivateChannelCreateListener> listeners = new ArrayList<>();
        if (users != null) {
            users.stream()
                 .map(User::getPrivateChannelCreateListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getPrivateChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onPrivateChannelCreate(event));
    }

    /**
     * Dispatch an event to {@code PrivateChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchPrivateChannelCreateEvent(DispatchQueueSelector queueSelector, User user, PrivateChannelCreateEvent event) {
        List<PrivateChannelCreateListener> listeners = new ArrayList<>();
        if (user != null) {
            listeners.addAll(user.getPrivateChannelCreateListeners());
        }
        listeners.addAll(getApi().getPrivateChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onPrivateChannelCreate(event));
    }

    /**
     * Dispatch an event to {@code PrivateChannelCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchPrivateChannelCreateEvent(DispatchQueueSelector queueSelector, long userId, PrivateChannelCreateEvent event) {
        List<PrivateChannelCreateListener> listeners = new ArrayList<>();
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     PrivateChannelCreateListener.class));
        listeners.addAll(getApi().getPrivateChannelCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onPrivateChannelCreate(event));
    }

    /**
     * Dispatch an event to {@code AudioSourceFinishedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param audioConnections The {@code AudioConnection}s.
     * @param audioSources The {@code AudioSource}s.
     * @param event The event.
     */
    public void dispatchAudioSourceFinishedEvent(DispatchQueueSelector queueSelector, Collection<AudioConnection> audioConnections, Collection<AudioSource> audioSources, AudioSourceFinishedEvent event) {
        List<AudioSourceFinishedListener> listeners = new ArrayList<>();
        if (audioConnections != null) {
            audioConnections.stream()
                            .map(AudioConnection::getAudioSourceFinishedListeners)
                            .forEach(listeners::addAll);
        }
        if (audioSources != null) {
            audioSources.stream()
                        .map(AudioSource::getAudioSourceFinishedListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getAudioSourceFinishedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onAudioSourceFinished(event));
    }

    /**
     * Dispatch an event to {@code AudioSourceFinishedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param audioConnection The {@code AudioConnection}.
     * @param audioSource The {@code AudioSource}.
     * @param event The event.
     */
    public void dispatchAudioSourceFinishedEvent(DispatchQueueSelector queueSelector, AudioConnection audioConnection, AudioSource audioSource, AudioSourceFinishedEvent event) {
        List<AudioSourceFinishedListener> listeners = new ArrayList<>();
        if (audioConnection != null) {
            listeners.addAll(audioConnection.getAudioSourceFinishedListeners());
        }
        if (audioSource != null) {
            listeners.addAll(audioSource.getAudioSourceFinishedListeners());
        }
        listeners.addAll(getApi().getAudioSourceFinishedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onAudioSourceFinished(event));
    }

    /**
     * Dispatch an event to {@code UserChangeDeafenedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeDeafenedEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeDeafenedEvent event) {
        List<UserChangeDeafenedListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeDeafenedListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeDeafenedListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeDeafenedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeDeafened(event));
    }

    /**
     * Dispatch an event to {@code UserChangeDeafenedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeDeafenedEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeDeafenedEvent event) {
        List<UserChangeDeafenedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeDeafenedListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeDeafenedListeners());
        }
        listeners.addAll(getApi().getUserChangeDeafenedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeDeafened(event));
    }

    /**
     * Dispatch an event to {@code UserChangeDeafenedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeDeafenedEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeDeafenedEvent event) {
        List<UserChangeDeafenedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeDeafenedListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeDeafenedListener.class));
        listeners.addAll(getApi().getUserChangeDeafenedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeDeafened(event));
    }

    /**
     * Dispatch an event to {@code UserChangeNicknameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeNicknameEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeNicknameEvent event) {
        List<UserChangeNicknameListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeNicknameListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeNicknameListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeNicknameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeNickname(event));
    }

    /**
     * Dispatch an event to {@code UserChangeNicknameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeNicknameEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeNicknameEvent event) {
        List<UserChangeNicknameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeNicknameListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeNicknameListeners());
        }
        listeners.addAll(getApi().getUserChangeNicknameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeNickname(event));
    }

    /**
     * Dispatch an event to {@code UserChangeNicknameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeNicknameEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeNicknameEvent event) {
        List<UserChangeNicknameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeNicknameListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeNicknameListener.class));
        listeners.addAll(getApi().getUserChangeNicknameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeNickname(event));
    }

    /**
     * Dispatch an event to {@code UserChangePendingListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangePendingEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangePendingEvent event) {
        List<UserChangePendingListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangePendingListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangePendingListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangePendingListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberChangePending(event));
    }

    /**
     * Dispatch an event to {@code UserChangePendingListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangePendingEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangePendingEvent event) {
        List<UserChangePendingListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangePendingListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangePendingListeners());
        }
        listeners.addAll(getApi().getUserChangePendingListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberChangePending(event));
    }

    /**
     * Dispatch an event to {@code UserChangePendingListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangePendingEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangePendingEvent event) {
        List<UserChangePendingListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangePendingListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangePendingListener.class));
        listeners.addAll(getApi().getUserChangePendingListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onServerMemberChangePending(event));
    }

    /**
     * Dispatch an event to {@code UserStartTypingListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserStartTypingEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, UserStartTypingEvent event) {
        List<UserStartTypingListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserStartTypingListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getUserStartTypingListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserStartTypingListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserStartTypingListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserStartTyping(event));
    }

    /**
     * Dispatch an event to {@code UserStartTypingListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserStartTypingEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, UserStartTypingEvent event) {
        List<UserStartTypingListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserStartTypingListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getUserStartTypingListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserStartTypingListeners());
        }
        listeners.addAll(getApi().getUserStartTypingListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserStartTyping(event));
    }

    /**
     * Dispatch an event to {@code UserStartTypingListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserStartTypingEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, UserStartTypingEvent event) {
        List<UserStartTypingListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserStartTypingListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getUserStartTypingListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserStartTypingListener.class));
        listeners.addAll(getApi().getUserStartTypingListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserStartTyping(event));
    }

    /**
     * Dispatch an event to {@code UserChangeDiscriminatorListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeDiscriminatorEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeDiscriminatorEvent event) {
        List<UserChangeDiscriminatorListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeDiscriminatorListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeDiscriminatorListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeDiscriminatorListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeDiscriminator(event));
    }

    /**
     * Dispatch an event to {@code UserChangeDiscriminatorListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeDiscriminatorEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeDiscriminatorEvent event) {
        List<UserChangeDiscriminatorListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeDiscriminatorListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeDiscriminatorListeners());
        }
        listeners.addAll(getApi().getUserChangeDiscriminatorListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeDiscriminator(event));
    }

    /**
     * Dispatch an event to {@code UserChangeDiscriminatorListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeDiscriminatorEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeDiscriminatorEvent event) {
        List<UserChangeDiscriminatorListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeDiscriminatorListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeDiscriminatorListener.class));
        listeners.addAll(getApi().getUserChangeDiscriminatorListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeDiscriminator(event));
    }

    /**
     * Dispatch an event to {@code UserChangeStatusListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeStatusEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeStatusEvent event) {
        List<UserChangeStatusListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeStatusListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeStatusListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeStatusListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeStatus(event));
    }

    /**
     * Dispatch an event to {@code UserChangeStatusListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeStatusEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeStatusEvent event) {
        List<UserChangeStatusListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeStatusListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeStatusListeners());
        }
        listeners.addAll(getApi().getUserChangeStatusListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeStatus(event));
    }

    /**
     * Dispatch an event to {@code UserChangeStatusListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeStatusEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeStatusEvent event) {
        List<UserChangeStatusListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeStatusListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeStatusListener.class));
        listeners.addAll(getApi().getUserChangeStatusListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeStatus(event));
    }

    /**
     * Dispatch an event to {@code UserChangeServerAvatarListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeServerAvatarEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeServerAvatarEvent event) {
        List<UserChangeServerAvatarListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeServerAvatarListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeServerAvatarListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeServerAvatarListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeServerAvatar(event));
    }

    /**
     * Dispatch an event to {@code UserChangeServerAvatarListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeServerAvatarEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeServerAvatarEvent event) {
        List<UserChangeServerAvatarListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeServerAvatarListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeServerAvatarListeners());
        }
        listeners.addAll(getApi().getUserChangeServerAvatarListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeServerAvatar(event));
    }

    /**
     * Dispatch an event to {@code UserChangeServerAvatarListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeServerAvatarEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeServerAvatarEvent event) {
        List<UserChangeServerAvatarListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeServerAvatarListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeServerAvatarListener.class));
        listeners.addAll(getApi().getUserChangeServerAvatarListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeServerAvatar(event));
    }

    /**
     * Dispatch an event to {@code UserChangeSelfMutedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeSelfMutedEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeSelfMutedEvent event) {
        List<UserChangeSelfMutedListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeSelfMutedListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeSelfMutedListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeSelfMutedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeSelfMuted(event));
    }

    /**
     * Dispatch an event to {@code UserChangeSelfMutedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeSelfMutedEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeSelfMutedEvent event) {
        List<UserChangeSelfMutedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeSelfMutedListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeSelfMutedListeners());
        }
        listeners.addAll(getApi().getUserChangeSelfMutedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeSelfMuted(event));
    }

    /**
     * Dispatch an event to {@code UserChangeSelfMutedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeSelfMutedEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeSelfMutedEvent event) {
        List<UserChangeSelfMutedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeSelfMutedListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeSelfMutedListener.class));
        listeners.addAll(getApi().getUserChangeSelfMutedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeSelfMuted(event));
    }

    /**
     * Dispatch an event to {@code UserChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeNameEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeNameEvent event) {
        List<UserChangeNameListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeNameListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeNameListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeName(event));
    }

    /**
     * Dispatch an event to {@code UserChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeNameEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeNameEvent event) {
        List<UserChangeNameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeNameListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeNameListeners());
        }
        listeners.addAll(getApi().getUserChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeName(event));
    }

    /**
     * Dispatch an event to {@code UserChangeNameListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeNameEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeNameEvent event) {
        List<UserChangeNameListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeNameListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeNameListener.class));
        listeners.addAll(getApi().getUserChangeNameListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeName(event));
    }

    /**
     * Dispatch an event to {@code UserChangeTimeoutListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeTimeoutEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeTimeoutEvent event) {
        List<UserChangeTimeoutListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeTimeoutListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeTimeoutListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeTimeoutListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeTimeout(event));
    }

    /**
     * Dispatch an event to {@code UserChangeTimeoutListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeTimeoutEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeTimeoutEvent event) {
        List<UserChangeTimeoutListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeTimeoutListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeTimeoutListeners());
        }
        listeners.addAll(getApi().getUserChangeTimeoutListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeTimeout(event));
    }

    /**
     * Dispatch an event to {@code UserChangeTimeoutListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeTimeoutEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeTimeoutEvent event) {
        List<UserChangeTimeoutListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeTimeoutListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeTimeoutListener.class));
        listeners.addAll(getApi().getUserChangeTimeoutListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeTimeout(event));
    }

    /**
     * Dispatch an event to {@code UserChangeAvatarListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeAvatarEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeAvatarEvent event) {
        List<UserChangeAvatarListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeAvatarListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeAvatarListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeAvatarListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeAvatar(event));
    }

    /**
     * Dispatch an event to {@code UserChangeAvatarListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeAvatarEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeAvatarEvent event) {
        List<UserChangeAvatarListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeAvatarListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeAvatarListeners());
        }
        listeners.addAll(getApi().getUserChangeAvatarListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeAvatar(event));
    }

    /**
     * Dispatch an event to {@code UserChangeAvatarListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeAvatarEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeAvatarEvent event) {
        List<UserChangeAvatarListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeAvatarListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeAvatarListener.class));
        listeners.addAll(getApi().getUserChangeAvatarListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeAvatar(event));
    }

    /**
     * Dispatch an event to {@code UserChangeSelfDeafenedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeSelfDeafenedEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeSelfDeafenedEvent event) {
        List<UserChangeSelfDeafenedListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeSelfDeafenedListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeSelfDeafenedListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeSelfDeafenedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeSelfDeafened(event));
    }

    /**
     * Dispatch an event to {@code UserChangeSelfDeafenedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeSelfDeafenedEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeSelfDeafenedEvent event) {
        List<UserChangeSelfDeafenedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeSelfDeafenedListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeSelfDeafenedListeners());
        }
        listeners.addAll(getApi().getUserChangeSelfDeafenedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeSelfDeafened(event));
    }

    /**
     * Dispatch an event to {@code UserChangeSelfDeafenedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeSelfDeafenedEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeSelfDeafenedEvent event) {
        List<UserChangeSelfDeafenedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeSelfDeafenedListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeSelfDeafenedListener.class));
        listeners.addAll(getApi().getUserChangeSelfDeafenedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeSelfDeafened(event));
    }

    /**
     * Dispatch an event to {@code UserChangeMutedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeMutedEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeMutedEvent event) {
        List<UserChangeMutedListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeMutedListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeMutedListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeMutedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeMuted(event));
    }

    /**
     * Dispatch an event to {@code UserChangeMutedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeMutedEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeMutedEvent event) {
        List<UserChangeMutedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeMutedListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeMutedListeners());
        }
        listeners.addAll(getApi().getUserChangeMutedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeMuted(event));
    }

    /**
     * Dispatch an event to {@code UserChangeMutedListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeMutedEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeMutedEvent event) {
        List<UserChangeMutedListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeMutedListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeMutedListener.class));
        listeners.addAll(getApi().getUserChangeMutedListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeMuted(event));
    }

    /**
     * Dispatch an event to {@code UserChangeActivityListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchUserChangeActivityEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<User> users, UserChangeActivityEvent event) {
        List<UserChangeActivityListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getUserChangeActivityListeners)
                   .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getUserChangeActivityListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getUserChangeActivityListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeActivity(event));
    }

    /**
     * Dispatch an event to {@code UserChangeActivityListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchUserChangeActivityEvent(DispatchQueueSelector queueSelector, Server server, User user, UserChangeActivityEvent event) {
        List<UserChangeActivityListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeActivityListeners());
        }
        if (user != null) {
            listeners.addAll(user.getUserChangeActivityListeners());
        }
        listeners.addAll(getApi().getUserChangeActivityListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeActivity(event));
    }

    /**
     * Dispatch an event to {@code UserChangeActivityListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchUserChangeActivityEvent(DispatchQueueSelector queueSelector, Server server, long userId, UserChangeActivityEvent event) {
        List<UserChangeActivityListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getUserChangeActivityListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     UserChangeActivityListener.class));
        listeners.addAll(getApi().getUserChangeActivityListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onUserChangeActivity(event));
    }

    /**
     * Dispatch an event to {@code MessageEditListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param event The event.
     */
    public void dispatchMessageEditEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, MessageEditEvent event) {
        List<MessageEditListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getMessageEditListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getMessageEditListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getMessageEditListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getMessageEditListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageEdit(event));
    }

    /**
     * Dispatch an event to {@code MessageEditListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param event The event.
     */
    public void dispatchMessageEditEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, MessageEditEvent event) {
        List<MessageEditListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageEditListeners(getApi(),
                                                                                  messageId));
        if (server != null) {
            listeners.addAll(server.getMessageEditListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageEditListeners());
        }
        listeners.addAll(getApi().getMessageEditListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageEdit(event));
    }

    /**
     * Dispatch an event to {@code ChannelPinsUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param event The event.
     */
    public void dispatchChannelPinsUpdateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, ChannelPinsUpdateEvent event) {
        List<ChannelPinsUpdateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getChannelPinsUpdateListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getChannelPinsUpdateListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getChannelPinsUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onChannelPinsUpdate(event));
    }

    /**
     * Dispatch an event to {@code ChannelPinsUpdateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param event The event.
     */
    public void dispatchChannelPinsUpdateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, ChannelPinsUpdateEvent event) {
        List<ChannelPinsUpdateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getChannelPinsUpdateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getChannelPinsUpdateListeners());
        }
        listeners.addAll(getApi().getChannelPinsUpdateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onChannelPinsUpdate(event));
    }

    /**
     * Dispatch an event to {@code ReactionRemoveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchReactionRemoveEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, ReactionRemoveEvent event) {
        List<ReactionRemoveListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getReactionRemoveListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getReactionRemoveListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getReactionRemoveListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getReactionRemoveListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getReactionRemoveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionRemove(event));
    }

    /**
     * Dispatch an event to {@code ReactionRemoveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchReactionRemoveEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, ReactionRemoveEvent event) {
        List<ReactionRemoveListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getReactionRemoveListeners(getApi(),
                                                                                     messageId));
        if (server != null) {
            listeners.addAll(server.getReactionRemoveListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getReactionRemoveListeners());
        }
        if (user != null) {
            listeners.addAll(user.getReactionRemoveListeners());
        }
        listeners.addAll(getApi().getReactionRemoveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionRemove(event));
    }

    /**
     * Dispatch an event to {@code ReactionRemoveListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchReactionRemoveEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, ReactionRemoveEvent event) {
        List<ReactionRemoveListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getReactionRemoveListeners(getApi(),
                                                                                     messageId));
        if (server != null) {
            listeners.addAll(server.getReactionRemoveListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getReactionRemoveListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ReactionRemoveListener.class));
        listeners.addAll(getApi().getReactionRemoveListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionRemove(event));
    }

    /**
     * Dispatch an event to {@code ReactionAddListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param event The event.
     */
    public void dispatchReactionAddEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, ReactionAddEvent event) {
        List<ReactionAddListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getReactionAddListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getReactionAddListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getReactionAddListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getReactionAddListeners)
                 .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getReactionAddListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionAdd(event));
    }

    /**
     * Dispatch an event to {@code ReactionAddListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param event The event.
     */
    public void dispatchReactionAddEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, ReactionAddEvent event) {
        List<ReactionAddListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getReactionAddListeners(getApi(),
                                                                                  messageId));
        if (server != null) {
            listeners.addAll(server.getReactionAddListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getReactionAddListeners());
        }
        if (user != null) {
            listeners.addAll(user.getReactionAddListeners());
        }
        listeners.addAll(getApi().getReactionAddListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionAdd(event));
    }

    /**
     * Dispatch an event to {@code ReactionAddListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param event The event.
     */
    public void dispatchReactionAddEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, ReactionAddEvent event) {
        List<ReactionAddListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getReactionAddListeners(getApi(),
                                                                                  messageId));
        if (server != null) {
            listeners.addAll(server.getReactionAddListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getReactionAddListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     ReactionAddListener.class));
        listeners.addAll(getApi().getReactionAddListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionAdd(event));
    }

    /**
     * Dispatch an event to {@code ReactionRemoveAllListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param event The event.
     */
    public void dispatchReactionRemoveAllEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, ReactionRemoveAllEvent event) {
        List<ReactionRemoveAllListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getReactionRemoveAllListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getReactionRemoveAllListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getReactionRemoveAllListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getReactionRemoveAllListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionRemoveAll(event));
    }

    /**
     * Dispatch an event to {@code ReactionRemoveAllListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param event The event.
     */
    public void dispatchReactionRemoveAllEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, ReactionRemoveAllEvent event) {
        List<ReactionRemoveAllListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getReactionRemoveAllListeners(getApi(),
                                                                                        messageId));
        if (server != null) {
            listeners.addAll(server.getReactionRemoveAllListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getReactionRemoveAllListeners());
        }
        listeners.addAll(getApi().getReactionRemoveAllListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReactionRemoveAll(event));
    }

    /**
     * Dispatch an event to {@code MessageCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param webhookIds The ids of the {@link Webhook}s.
     * @param event The event.
     */
    public void dispatchMessageCreateEvent(DispatchQueueSelector queueSelector, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, Collection<Long> webhookIds, MessageCreateEvent event) {
        List<MessageCreateListener> listeners = new ArrayList<>();
        if (servers != null) {
            servers.stream()
                   .map(Server::getMessageCreateListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getMessageCreateListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getMessageCreateListeners)
                 .forEach(listeners::addAll);
        }
        if (webhookIds != null) {
            webhookIds.stream()
                      .map(webhookId -> getApi().getObjectListeners(Webhook.class,
                                                                    webhookId,
                                                                    MessageCreateListener.class))
                      .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getMessageCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageCreate(event));
    }

    /**
     * Dispatch an event to {@code MessageCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param webhookId The id of the {@link Webhook}.
     * @param event The event.
     */
    public void dispatchMessageCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, User user, Long webhookId, MessageCreateEvent event) {
        List<MessageCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getMessageCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageCreateListeners());
        }
        if (user != null) {
            listeners.addAll(user.getMessageCreateListeners());
        }
        if (webhookId != null) {
            listeners.addAll(getApi().getObjectListeners(Webhook.class,
                                                         webhookId,
                                                         MessageCreateListener.class));
        }
        listeners.addAll(getApi().getMessageCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageCreate(event));
    }

    /**
     * Dispatch an event to {@code MessageCreateListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param webhookId The id of the {@link Webhook}.
     * @param event The event.
     */
    public void dispatchMessageCreateEvent(DispatchQueueSelector queueSelector, Server server, TextChannel textChannel, long userId, Long webhookId, MessageCreateEvent event) {
        List<MessageCreateListener> listeners = new ArrayList<>();
        if (server != null) {
            listeners.addAll(server.getMessageCreateListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageCreateListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     MessageCreateListener.class));
        if (webhookId != null) {
            listeners.addAll(getApi().getObjectListeners(Webhook.class,
                                                         webhookId,
                                                         MessageCreateListener.class));
        }
        listeners.addAll(getApi().getMessageCreateListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageCreate(event));
    }

    /**
     * Dispatch an event to {@code CachedMessageUnpinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param event The event.
     */
    public void dispatchCachedMessageUnpinEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, CachedMessageUnpinEvent event) {
        List<CachedMessageUnpinListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getCachedMessageUnpinListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getCachedMessageUnpinListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getCachedMessageUnpinListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getCachedMessageUnpinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onCachedMessageUnpin(event));
    }

    /**
     * Dispatch an event to {@code CachedMessageUnpinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param message The {@code Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param event The event.
     */
    public void dispatchCachedMessageUnpinEvent(DispatchQueueSelector queueSelector, Message message, Server server, TextChannel textChannel, CachedMessageUnpinEvent event) {
        List<CachedMessageUnpinListener> listeners = new ArrayList<>();
        if (message != null) {
            listeners.addAll(message.getCachedMessageUnpinListeners());
        }
        if (server != null) {
            listeners.addAll(server.getCachedMessageUnpinListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getCachedMessageUnpinListeners());
        }
        listeners.addAll(getApi().getCachedMessageUnpinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onCachedMessageUnpin(event));
    }

    /**
     * Dispatch an event to {@code CachedMessagePinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param event The event.
     */
    public void dispatchCachedMessagePinEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, CachedMessagePinEvent event) {
        List<CachedMessagePinListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getCachedMessagePinListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getCachedMessagePinListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getCachedMessagePinListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getCachedMessagePinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onCachedMessagePin(event));
    }

    /**
     * Dispatch an event to {@code CachedMessagePinListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param message The {@code Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param event The event.
     */
    public void dispatchCachedMessagePinEvent(DispatchQueueSelector queueSelector, Message message, Server server, TextChannel textChannel, CachedMessagePinEvent event) {
        List<CachedMessagePinListener> listeners = new ArrayList<>();
        if (message != null) {
            listeners.addAll(message.getCachedMessagePinListeners());
        }
        if (server != null) {
            listeners.addAll(server.getCachedMessagePinListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getCachedMessagePinListeners());
        }
        listeners.addAll(getApi().getCachedMessagePinListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onCachedMessagePin(event));
    }

    /**
     * Dispatch an event to {@code MessageReplyListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param users The {@code User}s.
     * @param webhookIds The ids of the {@link Webhook}s.
     * @param event The event.
     */
    public void dispatchMessageReplyEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, Collection<User> users, Collection<Long> webhookIds, MessageReplyEvent event) {
        List<MessageReplyListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getMessageReplyListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getMessageReplyListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getMessageReplyListeners)
                        .forEach(listeners::addAll);
        }
        if (users != null) {
            users.stream()
                 .map(User::getMessageReplyListeners)
                 .forEach(listeners::addAll);
        }
        if (webhookIds != null) {
            webhookIds.stream()
                      .map(webhookId -> getApi().getObjectListeners(Webhook.class,
                                                                    webhookId,
                                                                    MessageReplyListener.class))
                      .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getMessageReplyListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageReply(event));
    }

    /**
     * Dispatch an event to {@code MessageReplyListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param user The {@code User}.
     * @param webhookId The id of the {@link Webhook}.
     * @param event The event.
     */
    public void dispatchMessageReplyEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, User user, Long webhookId, MessageReplyEvent event) {
        List<MessageReplyListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageReplyListeners(getApi(),
                                                                                   messageId));
        if (server != null) {
            listeners.addAll(server.getMessageReplyListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageReplyListeners());
        }
        if (user != null) {
            listeners.addAll(user.getMessageReplyListeners());
        }
        if (webhookId != null) {
            listeners.addAll(getApi().getObjectListeners(Webhook.class,
                                                         webhookId,
                                                         MessageReplyListener.class));
        }
        listeners.addAll(getApi().getMessageReplyListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageReply(event));
    }

    /**
     * Dispatch an event to {@code MessageReplyListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param userId The id of the {@link User}.
     * @param webhookId The id of the {@link Webhook}.
     * @param event The event.
     */
    public void dispatchMessageReplyEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, long userId, Long webhookId, MessageReplyEvent event) {
        List<MessageReplyListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageReplyListeners(getApi(),
                                                                                   messageId));
        if (server != null) {
            listeners.addAll(server.getMessageReplyListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageReplyListeners());
        }
        listeners.addAll(getApi().getObjectListeners(User.class,
                                                     userId,
                                                     MessageReplyListener.class));
        if (webhookId != null) {
            listeners.addAll(getApi().getObjectListeners(Webhook.class,
                                                         webhookId,
                                                         MessageReplyListener.class));
        }
        listeners.addAll(getApi().getMessageReplyListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageReply(event));
    }

    /**
     * Dispatch an event to {@code MessageDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messages The {@code Message}s.
     * @param servers The {@code Server}s.
     * @param textChannels The {@code TextChannel}s.
     * @param event The event.
     */
    public void dispatchMessageDeleteEvent(DispatchQueueSelector queueSelector, Collection<Message> messages, Collection<Server> servers, Collection<TextChannel> textChannels, MessageDeleteEvent event) {
        List<MessageDeleteListener> listeners = new ArrayList<>();
        if (messages != null) {
            messages.stream()
                    .map(Message::getMessageDeleteListeners)
                    .forEach(listeners::addAll);
        }
        if (servers != null) {
            servers.stream()
                   .map(Server::getMessageDeleteListeners)
                   .forEach(listeners::addAll);
        }
        if (textChannels != null) {
            textChannels.stream()
                        .map(TextChannel::getMessageDeleteListeners)
                        .forEach(listeners::addAll);
        }
        listeners.addAll(getApi().getMessageDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageDelete(event));
    }

    /**
     * Dispatch an event to {@code MessageDeleteListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param messageId The id of the {@link Message}.
     * @param server The {@code Server}.
     * @param textChannel The {@code TextChannel}.
     * @param event The event.
     */
    public void dispatchMessageDeleteEvent(DispatchQueueSelector queueSelector, long messageId, Server server, TextChannel textChannel, MessageDeleteEvent event) {
        List<MessageDeleteListener> listeners = new ArrayList<>();
        listeners.addAll(MessageAttachableListenerManager.getMessageDeleteListeners(getApi(),
                                                                                    messageId));
        if (server != null) {
            listeners.addAll(server.getMessageDeleteListeners());
        }
        if (textChannel != null) {
            listeners.addAll(textChannel.getMessageDeleteListeners());
        }
        listeners.addAll(getApi().getMessageDeleteListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onMessageDelete(event));
    }

    /**
     * Dispatch an event to {@code ResumeListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param event The event.
     */
    public void dispatchResumeEvent(DispatchQueueSelector queueSelector, ResumeEvent event) {
        List<ResumeListener> listeners = new ArrayList<>();
        listeners.addAll(getApi().getResumeListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onResume(event));
    }

    /**
     * Dispatch an event to {@code LostConnectionListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param event The event.
     */
    public void dispatchLostConnectionEvent(DispatchQueueSelector queueSelector, LostConnectionEvent event) {
        List<LostConnectionListener> listeners = new ArrayList<>();
        listeners.addAll(getApi().getLostConnectionListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onLostConnection(event));
    }

    /**
     * Dispatch an event to {@code ReconnectListener}s.
     *
     * @param queueSelector The object which is used to determine in which queue the event should be
     *                      dispatched. Usually the object is a server object (for server-dependent
     *                      events), a discord api instance (for server-independent events, like DMs or
     *                      GMs) or {@code null} (for lifecycle events, like connection lost, resume or
     *                      reconnect). Providing {@code null} means, that already started dispatchings
     *                      are going to be finished, then all events with a {@code null} queue
     *                      selector are dispatched and finally other events are dispatched like normal
     *                      again. Events with the same queue selector are dispatched sequentially in
     *                      the correct order of enqueueal, but on arbitrary threads from a thread
     *                      pool. Events with different queue selectors are dispatched in parallel.
     * @param event The event.
     */
    public void dispatchReconnectEvent(DispatchQueueSelector queueSelector, ReconnectEvent event) {
        List<ReconnectListener> listeners = new ArrayList<>();
        listeners.addAll(getApi().getReconnectListeners());
        dispatchEvent(queueSelector,
                      listeners,
                      listener -> listener.onReconnect(event));
    }
}
